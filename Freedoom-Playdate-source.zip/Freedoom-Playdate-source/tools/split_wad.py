#!/usr/bin/env python3
"""Splits the game data (a WAD) into 1 MB pieces for the Playdate.

WHY: the Playdate's file system is slow at moving BACKWARDS inside a big file (a "seek" has to walk the file again from its start, about
60 ms for a file this size). Doom jumps around its 28 MB data file constantly while loading, so the first start took minutes and the system
stopped the app (the "run loop stalled" error). In a 1 MB piece a seek is nearly instant. The game (src/pd_wad.c) joins the pieces again
as it reads. CHUNK must match CHUNK_BYTES there.

Usage:  python3 tools/split_wad.py [path/to/freedoom1.wad]     (default wad/freedoom-0.13.0/freedoom1.wad)
Result: Source/freedoom1.wad.parts/00, 01, 02 ...  and a small Source/freedoom1.wad placeholder (the engine looks for a file of that name
        before it opens anything, so the name has to exist; its content is never read).
"""
import os, shutil, sys

CHUNK = 1024 * 1024          # bytes per piece: keep equal to CHUNK_BYTES in src/pd_wad.c
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(root, "wad", "freedoom-0.13.0", "freedoom1.wad")
out = os.path.join(root, "Source", "freedoom1.wad.parts")

shutil.rmtree(out, ignore_errors=True)
os.makedirs(out)
n = 0
with open(src, "rb") as f:
    while True:
        block = f.read(CHUNK)
        if not block:
            break
        with open(os.path.join(out, "%02d" % n), "wb") as g:
            g.write(block)
        n += 1
with open(os.path.join(root, "Source", "freedoom1.wad"), "w") as g:
    g.write("The game data is split into freedoom1.wad.parts/ (see tools/split_wad.py).\n")
print("wrote %d pieces of %d bytes to %s" % (n, CHUNK, out))
