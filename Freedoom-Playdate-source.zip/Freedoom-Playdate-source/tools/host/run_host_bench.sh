#!/bin/bash
# Runs one of DOOM's benchmarks on the Mac without the Playdate Simulator (see host_bench.c).
#   tools/host/run_host_bench.sh 1|2|3|4|bot      (bot = the bot's recorded E1M1 game, like DOOM Replay)
# Prints benchmark.txt. The FINAL STATE must match the Simulator's and the device's.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SDK="${PLAYDATE_SDK_PATH:-$HOME/Developer/PlaydateSDK}"
DEMO="${1:-4}"; [ "$DEMO" = bot ] && DEMO=9
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
rsync -a --exclude build --exclude '*.pdx' --exclude assets --exclude dist "$ROOT/" "$TMP/"
[ "$DEMO" = 9 ] && cp "$ROOT/demos/botrun.lmp" "$TMP/Source/botrun.lmp"
(cd "$TMP" && make PRODUCT=Host.pdx TESTDEFS="-DTEST_TIMEDEMO=$DEMO" simulator >/dev/null 2>&1)
clang -O2 -w -DTARGET_EXTENSION=1 -DTARGET_SIMULATOR=1 -I "$SDK/C_API" -o "$TMP/host_bench" "$ROOT/tools/host/host_bench.c"
"$TMP/host_bench" "$TMP/Source/pdex.dylib" "$TMP/Source" "$TMP/data" | grep -v "^ *$" | tail -5
cat "$TMP/data/benchmark.txt"
