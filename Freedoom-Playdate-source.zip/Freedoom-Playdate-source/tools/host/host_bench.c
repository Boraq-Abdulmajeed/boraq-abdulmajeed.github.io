// host_bench.c: runs DOOM's Simulator build (pdex.dylib) on the Mac WITHOUT the Playdate Simulator, for benchmarks and logic checks.
//
// WHY: the Simulator only runs while it is the front window, and a benchmark takes minutes. This program loads the same compiled
// game the Simulator would load, hands it a pretend Playdate (a "PlaydateAPI" table of functions written here), and calls its
// update function in a loop as fast as the Mac can. The game logic is exactly the Simulator build's, so a demo's FINAL STATE
// (see src/pd_bench.c) must come out identical to the Simulator's and the device's.
//
// Usage:  host_bench <path to pdex.dylib> <pdx folder (game files)> <data folder (benchmark.txt goes here)> [max frames]
// Build:  tools/host/run_host_bench.sh does everything (builds a TEST_TIMEDEMO dylib, this program, runs it).
#include <dlfcn.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include "pd_api.h"

static const char* pdxDir;
static const char* dataDir;
static uint8_t frame[LCD_ROWSIZE * LCD_ROWS];
static PDCallbackFunction* updateFn;
static void* updateUd;
static int quietLog = 0;

/** A stand-in for every Playdate function the game does not need: does nothing and returns 0 / NULL. */
static void* gstub(void) { return NULL; }

// ---- system
static unsigned int nowMs(void)
{
	struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
	static long long start = -1;
	long long ms = ts.tv_sec * 1000LL + ts.tv_nsec / 1000000;
	if (start < 0) start = ms;
	return (unsigned int)(ms - start);
}
static void* sysRealloc(void* p, size_t n) { if (n == 0) { free(p); return NULL; } return realloc(p, n); }
static void sysLog(const char* fmt, ...) { if (quietLog) return; va_list a; va_start(a, fmt); vprintf(fmt, a); va_end(a); printf("\n"); }
static void sysError(const char* fmt, ...) { va_list a; va_start(a, fmt); printf("ERROR: "); vprintf(fmt, a); va_end(a); printf("\n"); }
static void setUpdate(PDCallbackFunction* f, void* ud) { updateFn = f; updateUd = ud; }
static float crankChange(void) { return 0.0f; }
static void buttons(PDButtons* c, PDButtons* p, PDButtons* r) { if (c) *c = 0; if (p) *p = 0; if (r) *r = 0; }
static int menuVal(PDMenuItem* m) { (void)m; return 0; }

// ---- files: reads look in the data folder first, then the game folder (like the Playdate); writes go to the data folder
static char* pathFor(const char* name, int forWrite)
{
	static char buf[2][1024]; static int w;
	w ^= 1;
	snprintf(buf[w], sizeof buf[w], "%s/%s", dataDir, name);
	if (forWrite) return buf[w];
	struct stat st;
	if (stat(buf[w], &st) == 0) return buf[w];
	snprintf(buf[w], sizeof buf[w], "%s/%s", pdxDir, name);
	return buf[w];
}
static SDFile* fOpen(const char* name, FileOptions mode)
{
	const char* m = (mode & (kFileWrite)) ? "wb" : (mode & kFileAppend) ? "ab" : "rb";
	FILE* f = fopen(pathFor(name, (mode & (kFileWrite | kFileAppend)) != 0), m);
	return (SDFile*)f;
}
static int fClose(SDFile* f) { return fclose((FILE*)f); }
static int fRead(SDFile* f, void* b, unsigned int n) { return (int)fread(b, 1, n, (FILE*)f); }
static int fWrite(SDFile* f, const void* b, unsigned int n) { return (int)fwrite(b, 1, n, (FILE*)f); }
static int fFlush(SDFile* f) { return fflush((FILE*)f); }
static int fTell(SDFile* f) { return (int)ftell((FILE*)f); }
static int fSeek(SDFile* f, int pos, int whence) { return fseek((FILE*)f, pos, whence); }
static int fUnlink(const char* n, int r) { (void)r; return remove(pathFor(n, 1)); }
static int fRename(const char* a, const char* b) { char x[1024]; snprintf(x, sizeof x, "%s", pathFor(a, 1)); return rename(x, pathFor(b, 1)); }
static int fMkdir(const char* n) { return mkdir(pathFor(n, 1), 0755); }

// ---- graphics
static uint8_t* getFrame(void) { return frame; }

/** Fills a struct of function pointers with the do-nothing stand-in. */
static void* stubs(size_t bytes)
{
	void** t = calloc(1, bytes);
	for (size_t i = 0; i < bytes / sizeof(void*); i++) t[i] = (void*)gstub;
	return t;
}

int main(int argc, char** argv)
{
	if (argc < 4) { fprintf(stderr, "usage: host_bench pdex.dylib pdxdir datadir [maxframes]\n"); return 2; }
	pdxDir = argv[2]; dataDir = argv[3];
	long maxFrames = argc > 4 ? atol(argv[4]) : 2000000;
	mkdir(dataDir, 0755);

	void* lib = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
	if (!lib) { fprintf(stderr, "dlopen: %s\n", dlerror()); return 1; }
	int (*handler)(PlaydateAPI*, PDSystemEvent, uint32_t) = dlsym(lib, "eventHandlerShim");
	if (!handler) handler = dlsym(lib, "eventHandler");
	if (!handler) { fprintf(stderr, "no event handler in the dylib\n"); return 1; }

	struct playdate_sys* sys = stubs(sizeof *sys);
	sys->realloc = sysRealloc; sys->logToConsole = sysLog; sys->error = sysError;
	sys->getCurrentTimeMilliseconds = nowMs; sys->setUpdateCallback = setUpdate;
	sys->getCrankChange = crankChange; sys->getButtonState = buttons; sys->getMenuItemValue = menuVal;
	struct playdate_file* file = stubs(sizeof *file);
	file->open = fOpen; file->close = fClose; file->read = fRead; file->write = fWrite; file->flush = fFlush;
	file->tell = fTell; file->seek = fSeek; file->unlink = fUnlink; file->rename = fRename; file->mkdir = fMkdir;
	struct playdate_graphics* gfx = stubs(sizeof *gfx);
	gfx->getFrame = getFrame;
	struct playdate_display* disp = stubs(sizeof *disp);
	struct playdate_sound* snd = stubs(sizeof *snd);
	snd->sampleplayer = stubs(sizeof *snd->sampleplayer);
	snd->sample = stubs(sizeof *snd->sample);
	snd->channel = stubs(sizeof *snd->channel);
	snd->fileplayer = stubs(sizeof *snd->fileplayer);

	PlaydateAPI api = { 0 };
	api.system = sys; api.file = file; api.graphics = gfx; api.display = disp; api.sound = snd;
	api.sprite = stubs(sizeof *api.sprite); api.lua = stubs(sizeof *api.lua); api.json = stubs(sizeof *api.json);

	handler(&api, kEventInit, 0);
	if (!updateFn) { fprintf(stderr, "the game set no update function\n"); return 1; }
	char report[1024]; snprintf(report, sizeof report, "%s/benchmark.txt", dataDir);
	remove(report);
	unsigned int t0 = nowMs();
	for (long i = 0; i < maxFrames; i++) {
		updateFn(updateUd);
		struct stat st;
		if ((i & 63) == 0 && stat(report, &st) == 0 && st.st_size > 0) { printf("benchmark.txt written after %ld frames, %.1f s\n", i, (nowMs() - t0) / 1000.0); return 0; }
	}
	printf("stopped after %ld frames without a report\n", maxFrames);
	return 1;
}
