#!/bin/sh
# Downloads Freedoom (free game data, BSD licence) into wad/ and checks its published SHA-256 checksum.
set -e
cd "$(dirname "$0")/.."
mkdir -p wad && cd wad
V=0.13.0
curl -sL -o freedoom.zip "https://github.com/freedoom/freedoom/releases/download/v$V/freedoom-$V.zip"
echo "3f9b264f3e3ce503b4fb7f6bdcb1f419d93c7b546f4df3e874dd878db9688f59  freedoom.zip" | shasum -a 256 -c -
unzip -oq freedoom.zip
python3 ../tools/split_wad.py "freedoom-$V/freedoom1.wad"   # cut into 1 MB pieces (see that script for why)
echo "Freedoom $V is in Source/freedoom1.wad.parts/"
