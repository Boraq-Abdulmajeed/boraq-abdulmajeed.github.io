#!/usr/bin/env python3
"""Makes the launcher art for the PUBLIC build from Freedoom's own pictures, so nothing in it belongs to id Software.

The private build's card was cut from DOOM's box art (id's), which may not be shared. Freedoom's graphics are free (BSD licence, like the rest of
its data), so this reads them straight out of freedoom1.wad and arranges a 1-bit POSTER: the marine cut out of the title screen (TITLEPIC), two of the
game's monsters beside him, rays of light behind, and the FREEDOOM logo.

Why a poster and not just the title screen: that picture is bright figures on a RED background. Turned into 1-bit, red becomes grey dots all over,
and the figures drown in them. Here the red is removed first, so the background is true black and the figures stand out even when tiny.

Writes Source/launcher/ (or --out DIR):
  card.png         350x155   the marine on the right, the one-eyed monster rising behind the logo on the left
  launchImage.png  400x240   the full poster
  icon.png         32x32     the marine's helmet, in a frame
--cover PATH also saves the itch.io cover (630x500, in the Playdate screen's two colours); --preview PATH saves everything on one sheet.

Usage: /usr/bin/python3 tools/make_public_art.py [--wad PATH] [--out DIR] [--cover PATH] [--preview PATH]
"""
import math
import struct
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE / "tools"))     # (pdart.py, the small 1-bit art helper, sits beside this script)
from pdart import atkinson, system_font  # noqa: E402


def read_wad(path):
    """The lumps of a WAD file, by name: {name: bytes} (the last one wins, as in the engine)."""
    data = Path(path).read_bytes()
    kind, count, offset = struct.unpack_from("<4sii", data, 0)
    assert kind in (b"IWAD", b"PWAD"), "not a WAD file"
    lumps = {}
    for i in range(count):
        pos, size, name = struct.unpack_from("<ii8s", data, offset + i * 16)
        lumps[name.rstrip(b"\0").decode("ascii", "replace")] = data[pos:pos + size]
    return lumps


def picture(lump, palette):
    """A Doom "patch" picture (columns of posts) -> an RGBA image; transparent where the patch has no pixels."""
    w, h, _, _ = struct.unpack_from("<hhhh", lump, 0)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = img.load()
    for x in range(w):
        p = struct.unpack_from("<I", lump, 8 + x * 4)[0]
        while lump[p] != 0xFF:
            top, length = lump[p], lump[p + 1]
            for i in range(length):
                c = lump[p + 3 + i]
                if 0 <= top + i < h:
                    px[x, top + i] = palette[c] + (255,)
            p += length + 4
    return img


TALL = 1.2       # the game shows its 320x200 picture as 320x240, so every game pixel is 1.2 times taller than wide


# ------------------------------------------------------------------------------------------------ small image helpers

def finish(gray):
    """The finished grey picture -> pure black and white (Atkinson dithering, the look of the other cards)."""
    return atkinson(gray).convert("L")


def tone(colour, mask, gamma):
    """Colour -> grey, stretched so the brightest 1.5 % of the figure is white; gamma under 1 lifts the dark parts.

    Plain grey makes blue nearly black, so the blue channel is given a say: that is what makes the marine's visor glow."""
    grey = ImageChops.lighter(colour.convert("L"), colour.split()[2].point(lambda v: int(v * 0.6 if gamma > 0.7 else v)))
    histogram, seen, top = grey.histogram(mask), 0, 255
    for level in range(255, -1, -1):
        seen += histogram[level]
        if seen > sum(histogram) * 0.015:
            top = max(1, level)
            break
    return grey.point(lambda v: min(255, int(255 * (min(v, top) / top) ** gamma)))


def scaled(grey, mask, height):
    """A figure at the given height (with the game's tall pixels undone), sharpened a little; the mask stays hard-edged."""
    size = (round(grey.width * height / (grey.height * TALL)), height)
    grey = grey.resize(size, Image.LANCZOS).filter(ImageFilter.UnsharpMask(2, 90, 0))
    return grey, mask.resize(size, Image.LANCZOS).point(lambda v: 255 if v > 127 else 0)


def crisp(grey, radius, amount, dark, slope):
    """Comic-book contrast: each spot is compared with its neighbourhood (a blurred copy), so armour plates separate, then a steep curve
    pushes it towards black or white. Without it the marine is one flat grey patch of dots."""
    difference = ImageChops.subtract(grey, grey.filter(ImageFilter.GaussianBlur(radius)), 1, 128)
    out = Image.new("L", grey.size)
    a, b, o = grey.load(), difference.load(), out.load()
    for y in range(grey.height):
        for x in range(grey.width):
            o[x, y] = max(0, min(255, int((a[x, y] + (b[x, y] - 128) * amount - dark) * slope)))
    return out


def stamp(poster, grey, mask, x, y, outline):
    """Paste a figure with a black outline (the mask grown by `outline` pixels), so overlapping things stay apart."""
    pad = outline + 1
    grown = Image.new("L", (mask.width + 2 * pad, mask.height + 2 * pad), 0)
    grown.paste(mask, (pad, pad))
    poster.paste(0, (x - pad, y - pad), grown.filter(ImageFilter.MaxFilter(2 * outline + 1)))
    poster.paste(grey, (x, y), mask)


# ------------------------------------------------------------------------------------------------ the parts of the poster

def cut_out_marine(title):
    """The marine from the title screen, helmet to hips (above the words "PHASE 1"): (colour, mask).

    The trick: the red background has almost no green or blue in it, and the marine does, so "green or blue above a little" IS the marine.
    Small gaps are closed, holes inside him filled, only the piece touching his chest kept, and leftover red (between arm and body) dropped."""
    left, top = 70, 64
    colour = title.convert("RGB").crop((left, top, 222, 154))
    red, green, blue = colour.split()
    cool = ImageChops.lighter(green, blue)
    mask = Image.new("L", (colour.width + 8, colour.height + 8), 0)         # (a margin, so the fill below can flow all round him)
    mask.paste(cool.point(lambda v: 255 if v > 30 else 0), (4, 4))
    mask = mask.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.MinFilter(3))
    ImageDraw.floodfill(mask, (0, 0), 128)                                  # everything the outside can reach...
    mask = mask.point(lambda v: 0 if v == 128 else 255)                     # ...is background; the rest, holes included, is figure
    ImageDraw.floodfill(mask, (4 + 152 - left, 4 + 100 - top), 200)         # his chest: only the piece connected to it stays
    mask = mask.point(lambda v: 255 if v == 200 else 0).crop((4, 4, 4 + colour.width, 4 + colour.height))
    leftover = ImageChops.multiply(red.point(lambda v: 255 if v > 55 else 0), cool.point(lambda v: 255 if v < 14 else 0))
    return colour, ImageChops.subtract(mask, leftover)


def rays(w, h, cx, cy, count=22, strength=0.55):
    """Rays of light from (cx, cy), fading to black: they point at the marine's head and lift him off the background."""
    big = Image.new("L", (w * 2, h * 2), 0)                                 # (drawn double size and shrunk, for smooth edges)
    d = ImageDraw.Draw(big)
    reach = 6 * w
    for i in range(count):
        a = 2 * math.pi * (i + 0.15) / count
        b = a + math.pi / count
        d.polygon([(cx * 2, cy * 2), (cx * 2 + reach * math.cos(a), cy * 2 + reach * math.sin(a)), (cx * 2 + reach * math.cos(b), cy * 2 + reach * math.sin(b))], fill=255)
    out = big.resize((w, h), Image.BOX)
    px, fade = out.load(), math.hypot(w, h) * 0.62
    for y in range(h):
        for x in range(w):
            px[x, y] = int(px[x, y] * strength * max(0, 1 - math.hypot(x - cx, y - cy) / fade) ** 0.8)
    return out


def logo_masks(w):
    """The FREEDOOM logo at width w as three clean shapes: (F R E E M, the ring, the D).

    Traced from the game's own M_DOOM picture, in its 157x43 coordinates: its polished-metal shading breaks into crumbs in 1-bit."""
    h, k = round(43 * TALL * w / 157), 8                                    # (k: drawn 8 times too big and shrunk)
    sx, sy = w * k / 157, h * k / 43
    layers = [Image.new("L", (w * k, h * k), 0) for _ in range(3)]
    letters, ring, dee = (ImageDraw.Draw(layer) for layer in layers)

    def poly(*points):
        """One filled shape of a letter."""
        letters.polygon([(x * sx, y * sy) for x, y in points], fill=255)

    def stem(a, b, top=1):
        """An upright stroke from x = a to b with a flared foot."""
        poly((a, top), (b, top), (b, 40.2), (b + 1.6, 42.6), (a - 1.6, 42.6), (a, 40.2))

    stem(3.5, 9.5)                                                                                                                          # F
    poly((1.5, .6), (27, .6), (27.6, 7.4), (24, 4.2), (1.5, 4.2))
    poly((9, 14), (20.5, 14), (19.6, 16.8), (9, 16.8))
    stem(25.5, 30, 14)                                                                                                                      # R
    poly((23.5, 13.6), (38, 13.6), (42, 16), (43.4, 19), (42, 23), (37, 26.6), (34.4, 27.6), (45.5, 42.6), (40.2, 42.6), (30.6, 28), (30.6, 25.6),
         (36, 24.4), (39.4, 21.5), (39.8, 19), (38, 16.4), (36, 15.8), (23.5, 15.8))
    for o in (0, 15.2):                                                                                                                     # E, E
        poly((48 + o, 14), (52.6 + o, 14), (52.6 + o, 42), (48 + o, 42))
        poly((46 + o, 13.6), (58.6 + o, 13.6), (59.4 + o, 18), (57 + o, 15.8), (46 + o, 15.8))
        poly((52 + o, 26.6), (57 + o, 26.6), (58 + o, 25), (58 + o, 30.4), (57 + o, 28.8), (52 + o, 28.8))
        poly((46.4 + o, 42.6), (46.4 + o, 40.4), (56 + o, 40.4), (59.6 + o, 36.4), (59.4 + o, 42.6))
    stem(121.5, 127)                                                                                                                        # M
    stem(146.5, 152.5)
    poly((119.5, .6), (129, .6), (138.6, 34), (138.6, 42), (136.4, 42), (124, 4))
    poly((154.5, .6), (147, .6), (136.4, 37), (136.4, 42), (138, 42), (150, 4))
    dee.pieslice((60 * sx, 13.6 * sy, 95.6 * sx, 42.6 * sy), -90, 90, fill=255)                                                             # D: an outer half-oval...
    dee.pieslice((66 * sx, 16 * sy, 92 * sx, 40.2 * sy), -90, 90, fill=0)                                                                   # ...minus an inner one
    dee.rectangle((0, 0, 75.4 * sx, 43 * sy), fill=0)
    for box in ((75.4, 13.6, 79, 15.9), (75.4, 40.3, 79, 42.6), (77.5, 13.6, 82, 42.6)):
        dee.rectangle((box[0] * sx, box[1] * sy, box[2] * sx, box[3] * sy), fill=255)
    radius = 1.35 * (sx + sy)
    for i in range(1400):                                                                                                                   # the ring: a round brush along a figure eight
        t = 2 * math.pi * i / 1400
        x, y = (109.6 + 23 * math.cos(t) / (1 + 0.1 * math.sin(t) ** 2)) * sx, (28.2 + 11.4 * math.sin(2 * t)) * sy
        ring.ellipse((x - radius, y - radius, x + radius, y + radius), fill=255)
    return [layer.resize((w, h), Image.BOX).point(lambda v: 255 if v > 120 else 0) for layer in layers]


def lettering(poster, w, cx, y):
    """Draws the logo centred on cx: white letters, the ring as a white rim round a grey core (so it reads as another metal), the D over the ring."""
    letters, ring, dee = logo_masks(w)
    x, white = cx - w // 2, Image.new("L", letters.size, 255)
    stamp(poster, white, letters, x, y, 3)
    stamp(poster, white, ring, x, y, 1)
    poster.paste(105, (x, y), ring.filter(ImageFilter.MinFilter(3)))
    stamp(poster, white, dee, x, y, 1)


class Artist:
    """Holds the game's pictures and puts posters together from them."""

    def __init__(self, lumps):
        """Reads the palette and cuts the marine out once; every poster reuses him."""
        self.lumps = lumps
        pal = lumps["PLAYPAL"]
        self.palette = [tuple(pal[i * 3:i * 3 + 3]) for i in range(256)]
        colour, self.mask = cut_out_marine(picture(lumps["TITLEPIC"], self.palette))
        self.grey = tone(colour, self.mask, 0.62)

    def marine(self, height, dark=62, slope=1.2, amount=1.5):
        """The marine at a height, with the comic-book contrast."""
        grey, mask = scaled(self.grey, self.mask, height)
        return crisp(grey, height / 14, amount, dark, slope), mask

    def monster(self, name, height, gamma):
        """One monster sprite (by its name in the WAD), grey, at a height."""
        sprite = picture(self.lumps[name], self.palette)
        mask = sprite.split()[3]
        colour = Image.new("RGB", sprite.size)
        colour.paste(sprite, mask=mask)
        return scaled(tone(colour, mask, gamma), mask, height)

    def poster(self, w, h, light, monsters, marine, logo, fade=None):
        """One poster, still grey. light = (x, y) the rays start from; monsters = [(name, height, centre x, centre y, gamma)];
        marine = (height, centre x, top); logo = (width, centre x, top); fade = (from y, to y) where the picture sinks into black for the logo."""
        out = rays(w, h, *light)
        for name, height, x, y, gamma in monsters:
            grey, mask = self.monster(name, height, gamma)
            stamp(out, grey, mask, x - grey.width // 2, y - height // 2, 2)
        grey, mask = self.marine(marine[0])
        stamp(out, grey, mask, marine[1] - grey.width // 2, marine[2], 3)
        if fade:
            px = out.load()
            for y in range(fade[0], h):
                for x in range(w):
                    px[x, y] = int(px[x, y] * max(0, 1 - (y - fade[0]) / (fade[1] - fade[0])))
        lettering(out, *logo)
        return out


def caption(img, text, x, y):
    """White pixel text on a black plate (x None = centred)."""
    font = system_font()
    if x is None:
        x = (img.width - font.width(text)) // 2
    ImageDraw.Draw(img).rectangle((x - 6, y, x + font.width(text) + 6, img.height), fill=0)
    font.draw(img, text, x, y, fill=255)


def main():
    """Reads the options, makes the pictures and saves them."""
    args = sys.argv[1:]

    def option(name, default=None):
        """The value after an option on the command line."""
        return Path(args[args.index(name) + 1]) if name in args else default

    artist = Artist(read_wad(option("--wad", HERE / "Source" / "freedoom1.wad")))
    out = option("--out", HERE / "Source" / "launcher")

    card = finish(artist.poster(350, 155, (274, 48), [("HEADA1", 118, 104, 46, .75)], (206, 274, 3), (206, 112, 62)))
    caption(card, "for Playdate", 14, 133)
    launch = finish(artist.poster(400, 240, (200, 58), [("HEADA1", 130, 62, 86, .75), ("SARGF1", 150, 340, 100, .8)], (214, 200, 2), (296, 200, 139), (140, 176)))

    grey, mask = artist.marine(78, 66, 1.3, 1.6)                            # the icon: a window round the helmet
    x, y = 92 * grey.width // 152 - 15, 16 * grey.height // 90 - 15
    face = Image.new("L", (30, 30), 0)
    face.paste(grey.crop((x, y, x + 30, y + 30)), (0, 0), mask.crop((x, y, x + 30, y + 30)))
    icon = Image.new("L", (32, 32), 0)
    icon.paste(finish(face), (1, 1))
    ImageDraw.Draw(icon).rectangle((0, 0, 31, 31), outline=255)

    out.mkdir(parents=True, exist_ok=True)
    for name, img in (("card.png", card), ("launchImage.png", launch), ("icon.png", icon)):
        img.convert("1").save(out / name)
        print(out / name)
    cover = finish(artist.poster(315, 250, (152, 54), [("HEADA1", 108, 42, 84, .75), ("SARGF1", 128, 271, 96, .8)], (188, 152, 2), (272, 157, 137), (128, 160)))
    caption(cover, "the crank aims", None, 230)
    cover = ImageOps.colorize(cover.resize((630, 500), Image.NEAREST), (49, 47, 40), (177, 175, 168))     # the Playdate screen's two colours
    if "--cover" in args:
        cover.save(option("--cover"))
        print(option("--cover"))
    if "--preview" in args:
        sheet = Image.new("RGB", (1480, 920), (110, 110, 110))
        sheet.paste(launch.resize((800, 480), Image.NEAREST), (10, 10))
        sheet.paste(card.resize((1050, 465), Image.NEAREST).resize((700, 310), Image.BOX), (10, 510))
        sheet.paste(icon.resize((128, 128), Image.NEAREST), (740, 510))
        sheet.paste(icon, (890, 510))
        sheet.paste(cover, (830, 10))
        sheet.paste(cover.resize((315, 250), Image.BOX), (940, 530))
        sheet.save(option("--preview"))
        print(option("--preview"))


if __name__ == "__main__":
    main()
