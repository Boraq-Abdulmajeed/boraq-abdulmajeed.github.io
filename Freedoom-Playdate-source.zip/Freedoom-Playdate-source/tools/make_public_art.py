#!/usr/bin/env python3
"""Makes the launcher art for the PUBLIC build from Freedoom's own pictures, so nothing in it belongs to id Software.

The private build's card was cut from DOOM's box art (id's), which may not be shared. Freedoom's graphics are free (BSD licence, like the rest of
its data), so this reads two pictures straight out of freedoom1.wad: TITLEPIC (the title screen) and M_DOOM (the FREEDOOM logo of the main menu),
turns them into 1-bit (Atkinson dithering, the same look as the game's other cards), and writes Source/launcher/ (or --out DIR):
  card.png         350x155   a window of the title picture around its logo, "for Playdate" under it
  launchImage.png  400x240   the title picture, stretched to the Playdate's shape as the game itself shows it (320x200 -> 320x240), black bars
  icon.png         32x32     a close-up of the title picture's creature, in a frame
--preview PATH also saves all three side by side, larger.

Usage: /usr/bin/python3 tools/make_public_art.py [--wad PATH] [--out DIR] [--preview PATH]
"""
import struct
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE / "tools"))     # (pdart.py, the small 1-bit art helper, sits beside this script)
from pdart import atkinson, system_font  # noqa: E402


def read_wad(path):
    """The lumps of a WAD file, by name: {name: bytes} (the last one wins, as in the engine)."""
    data = Path(path).read_bytes()
    kind, count, offset = struct.unpack_from("<4sii", data, 0)
    assert kind in (b"IWAD", b"PWAD"), "not a WAD file"
    lumps = {}
    for i in range(count):
        pos, size, name = struct.unpack_from("<ii8s", data, offset + i * 16)
        lumps[name.rstrip(b"\0").decode("ascii", "replace")] = data[pos:pos + size]
    return lumps


def picture(lump, palette):
    """A Doom "patch" picture (columns of posts) -> an RGBA image; transparent where the patch has no pixels."""
    w, h, _, _ = struct.unpack_from("<hhhh", lump, 0)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = img.load()
    for x in range(w):
        p = struct.unpack_from("<I", lump, 8 + x * 4)[0]
        while lump[p] != 0xFF:
            top, length = lump[p], lump[p + 1]
            for i in range(length):
                c = lump[p + 3 + i]
                if 0 <= top + i < h:
                    px[x, top + i] = palette[c] + (255,)
            p += length + 4
    return img


def to_1bit(img, gamma=1.0, contrast=True):
    """An RGB(A) picture -> 1-bit black and white (as L, 0/255), Atkinson-dithered, transparent parts black."""
    g = Image.new("RGB", img.size, (0, 0, 0))
    g.paste(img, mask=img.split()[3] if img.mode == "RGBA" else None)
    g = g.convert("L")
    if contrast:
        g = ImageOps.autocontrast(g, cutoff=1)
    if gamma != 1.0:
        g = g.point(lambda v: int(255 * (v / 255) ** gamma))
    return atkinson(g).convert("L")


def main():
    args = sys.argv[1:]
    wad = Path(args[args.index("--wad") + 1]) if "--wad" in args else HERE / "Source" / "freedoom1.wad"
    out = Path(args[args.index("--out") + 1]) if "--out" in args else HERE / "Source" / "launcher"
    lumps = read_wad(wad)
    pal = lumps["PLAYPAL"]
    palette = [tuple(pal[i * 3:i * 3 + 3]) for i in range(256)]
    title = picture(lumps["TITLEPIC"], palette)          # 320x200
    logo = picture(lumps["M_DOOM"], palette)             # the FREEDOOM lettering
    font = system_font()

    # the launch image: the title screen at the shape the game shows it (taller pixels), centred between black bars
    tall = title.convert("RGB").resize((320, 240), Image.LANCZOS)
    launch = Image.new("L", (400, 240), 0)
    launch.paste(to_1bit(tall, gamma=0.9), (40, 0))

    # the card: a window of the title picture around its FREEDOOM logo (the picture already carries it), with a line of text under it
    wide = title.convert("RGB").resize((350, int(240 * 350 / 320)), Image.LANCZOS)   # (the game's taller pixels, at the card's width)
    top = 6
    card = to_1bit(wide.crop((0, top, 350, top + 155)), gamma=0.9)
    d = ImageDraw.Draw(card)
    text = "for Playdate"
    tw = font.width(text)
    d.rectangle(((350 - tw) // 2 - 10, 124, (350 + tw) // 2 + 10, 150), fill=0)
    font.draw(card, text, (350 - tw) // 2, 127, fill=255)

    # the icon: a close-up of the creature's glaring eye from the title picture, in a white frame
    face = title.convert("RGB").crop((44, 44, 108, 108)).resize((30, 30), Image.LANCZOS)
    icon = Image.new("L", (32, 32), 0)
    icon.paste(to_1bit(face, gamma=0.8), (1, 1))
    ImageDraw.Draw(icon).rectangle((0, 0, 31, 31), outline=255)
    _ = logo

    out.mkdir(parents=True, exist_ok=True)
    for name, img in (("card.png", card), ("launchImage.png", launch), ("icon.png", icon)):
        img.convert("1").save(out / name)
        print(out / name)
    if "--preview" in args:
        p = Path(args[args.index("--preview") + 1])
        sheet = Image.new("L", (1200, 520), 128)
        sheet.paste(launch.resize((800, 480), Image.NEAREST), (10, 20))
        sheet.paste(card.resize((350, 155), Image.NEAREST), (830, 20))
        sheet.paste(icon.resize((128, 128), Image.NEAREST), (830, 200))
        sheet.save(p)
        print(p)


if __name__ == "__main__":
    main()
