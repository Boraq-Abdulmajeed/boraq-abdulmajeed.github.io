# Freedoom for Playdate: source code

The classic Doom engine ([doomgeneric](https://github.com/ozkl/doomgeneric), GPL v2) on the Playdate, with [Freedoom](https://freedoom.github.io/)'s free
game data and the crank to aim. This is the complete source of the published game, as the GPL asks.

## Build

You need the [Playdate SDK](https://play.date/dev/) (3.x) on macOS or Linux, `make`, Python 3 and `curl`.

```sh
sh tools/get_freedoom.sh        # downloads Freedoom 0.13.0 (checksum-checked) and splits its data into Source/freedoom1.wad.parts/
make                            # builds the Simulator and device versions into Freedoom.pdx
```

Open `Freedoom.pdx` in the Playdate Simulator, or copy it to a Playdate. (`make PRODUCT=Name.pdx` builds under another name.)

## What is where

* `src/` is the Playdate layer written for this port:
  * `pd_main.c`: the app and its main loop, run as a coroutine so the engine can pause during long loads (`pd_coro.c`).
  * `pd_video.c`: the 1-bit picture, with dithering and auto exposure.
  * `pd_input.c`: the buttons, and the crank as mouse movement.
  * `pd_sound.c`: sound effects through the Playdate's sample players.
  * `pd_wad.c`: reads the game data in 1 MB pieces, because seeking in one big file is slow on the device.
  * `pd_stdio.*`: the C file functions the engine expects.
  * `pd_bot.c` and `pd_bench.c`: optional test builds (a bot that plays, and a timed demo replay), compiled out by default.
* `third_party/doomgeneric/`: the engine, with the changes in `patches/` already applied.
* `tools/get_freedoom.sh` and `split_wad.py` fetch and prepare the game data. `make_public_art.py` makes the launcher pictures from Freedoom's own title screen.

## Licences

* The engine and this port: GNU GPL version 2 (`LICENSE`, also `Source/LICENSE-GPL.txt`).
* Freedoom's data and the launcher art made from it: Freedoom's BSD-style licence (`Source/FREEDOOM-LICENSE.txt`).
* Doom is a trademark of id Software. This project is not made or endorsed by id Software, Bethesda or Panic.

Made by Boraq Abdulmajeed, with Claude Code.
