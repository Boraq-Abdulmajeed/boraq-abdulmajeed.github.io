// pd_sound.c: Doom's sound effects through the Playdate's audio (a "sound module" the engine plugs in when FEATURE_SOUND is on).
//
// HOW DOOM SOUND WORKS: the game data holds each sound effect as a "lump" named DS<NAME> (DSPISTOL, DSSHOTGN...): an 8-byte header (format 3, the
// sample rate, the length), 16 bytes of padding, the samples (UNSIGNED 8-bit, mostly at 11,025 Hz), and 16 bytes of padding at the end. The engine
// asks the module to play a sound on one of its 8 channels, with a volume (0-127) and a stereo position (0 left, 254 right), and to stop it or say
// whether it is still playing.
//
// WHAT THIS DOES: each channel is a Playdate "sample player". A sound's samples are converted once to signed 16-bit (the format the Playdate is sure to
// read correctly) and kept in a small cache of the 24 most recently used sounds (about 0.5 MB), because playing the same pistol shot again must be
// instant. Music is not played in this version (the original's music is MIDI-like data that needs a synthesiser).
#include "pd_game.h"

#include "doomtype.h"
#include "i_sound.h"
#include "w_wad.h"
#include "z_zone.h"

#define CHANNELS 8
#define CACHE_SIZE 24

static SamplePlayer* players[CHANNELS];
static int playingLump[CHANNELS];     // which sound each channel is playing (so a cached sound is never freed while it plays)
static int useSfxPrefix = 1;

// The engine's sound settings code binds these two (they belong to the SDL sound code this port does not use); they only need to exist.
int use_libsamplerate = 0;
float libsamplerate_scale = 0.65f;

typedef struct {
	int lump;                 // -1 = empty slot
	AudioSample* sample;
	unsigned int used;        // when it was last played (for dropping the least recently used)
} CacheEntry;
static CacheEntry cache[CACHE_SIZE];
static unsigned int clock_;

// Turns a Doom sound lump into a Playdate sample (signed 16-bit). Returns NULL for anything that is not a plain digital sound.
static AudioSample* buildSample(int lump)
{
	int length = W_LumpLength(lump);
	if (length < 8 + 32) return NULL;
	const uint8_t* d = (const uint8_t*)W_CacheLumpNum(lump, PU_CACHE);
	int format = d[0] | (d[1] << 8);
	int rate = d[2] | (d[3] << 8);
	int count = d[4] | (d[5] << 8) | (d[6] << 16) | (d[7] << 24);
	if (format != 3 || rate < 4000 || rate > 48000) return NULL;
	if (count > length - 8) count = length - 8;
	count -= 32;                                    // the 16 bytes of padding at each end are not part of the sound
	if (count <= 0) return NULL;
	int16_t* pcm = (int16_t*)malloc((size_t)count * 2);
	if (pcm == NULL) return NULL;
	for (int i = 0; i < count; i++) pcm[i] = (int16_t)(((int)d[8 + 16 + i] - 128) << 8);   // unsigned 8-bit -> signed 16-bit
	return pd->sound->sample->newSampleFromData((uint8_t*)pcm, kSound16bitMono, (uint32_t)rate, count * 2, 1);   // 1: the sample frees pcm itself
}

// The sample for a lump: from the cache, or built now (dropping the least recently used sound if the cache is full).
static AudioSample* sampleFor(int lump)
{
	int oldest = 0;
	for (int i = 0; i < CACHE_SIZE; i++) {
		if (cache[i].lump == lump) { cache[i].used = ++clock_; return cache[i].sample; }
		if (cache[i].lump < 0) oldest = i;                                   // an empty slot is always the best place
		else if (cache[oldest].lump >= 0 && cache[i].used < cache[oldest].used) oldest = i;
	}
	AudioSample* s = buildSample(lump);
	if (s == NULL) return NULL;
	if (cache[oldest].lump >= 0) {
		for (int c = 0; c < CHANNELS; c++) if (playingLump[c] == cache[oldest].lump) pd->sound->sampleplayer->stop(players[c]);
		pd->sound->sample->freeSample(cache[oldest].sample);
	}
	cache[oldest].lump = lump;
	cache[oldest].sample = s;
	cache[oldest].used = ++clock_;
	return s;
}

static boolean Init(boolean use_sfx_prefix)
{
	useSfxPrefix = use_sfx_prefix;
	for (int i = 0; i < CACHE_SIZE; i++) cache[i].lump = -1;
	for (int c = 0; c < CHANNELS; c++) { players[c] = pd->sound->sampleplayer->newPlayer(); playingLump[c] = -1; }
	return true;
}

static void Shutdown(void) { }

static int GetSfxLumpNum(sfxinfo_t* sfx)
{
	char name[16];
	if (useSfxPrefix) snprintf(name, sizeof name, "ds%s", sfx->name);
	else snprintf(name, sizeof name, "%s", sfx->name);
	return W_CheckNumForName(name);
}

static void Update(void) { }

// Doom's stereo position: 0 = hard left, 127 = centre, 254 = hard right. Volume 0-127.
static void setVolume(int channel, int vol, int sep)
{
	float v = (float)vol / 127.0f;
	pd->sound->sampleplayer->setVolume(players[channel], v * (float)(254 - sep) / 254.0f * 1.6f, v * (float)sep / 254.0f * 1.6f);   // x1.6: the centre would otherwise be quiet
}

static void UpdateSoundParams(int channel, int vol, int sep)
{
	if (channel >= 0 && channel < CHANNELS) setVolume(channel, vol, sep);
}

static int StartSound(sfxinfo_t* sfx, int channel, int vol, int sep)
{
	if (channel < 0 || channel >= CHANNELS || sfx->lumpnum < 0) return -1;
	AudioSample* s = sampleFor(sfx->lumpnum);
	if (s == NULL) return -1;
	pd->sound->sampleplayer->stop(players[channel]);
	pd->sound->sampleplayer->setSample(players[channel], s);
	setVolume(channel, vol, sep);
	playingLump[channel] = sfx->lumpnum;
	pd->sound->sampleplayer->play(players[channel], 1, 1.0f);
	return channel;
}

static void StopSound(int channel)
{
	if (channel >= 0 && channel < CHANNELS) { pd->sound->sampleplayer->stop(players[channel]); playingLump[channel] = -1; }
}

static boolean SoundIsPlaying(int channel)
{
	return channel >= 0 && channel < CHANNELS && pd->sound->sampleplayer->isPlaying(players[channel]);
}

static void CacheSounds(sfxinfo_t* sounds, int num_sounds) { (void)sounds; (void)num_sounds; }

static snddevice_t sfxDevices[] = { SNDDEVICE_SB, SNDDEVICE_PAS, SNDDEVICE_GUS, SNDDEVICE_WAVEBLASTER, SNDDEVICE_SOUNDCANVAS, SNDDEVICE_AWE32 };

sound_module_t DG_sound_module = {
	sfxDevices, sizeof sfxDevices / sizeof sfxDevices[0],
	Init, Shutdown, GetSfxLumpNum, Update, UpdateSoundParams, StartSound, StopSound, SoundIsPlaying, CacheSounds,
};

// Music: not in this version. The engine is started with -nomusic, so this module is never used, but the engine expects it to exist.
static boolean MusicInit(void) { return false; }
static void MusicShutdown(void) { }
static void MusicVolume(int volume) { (void)volume; }
static void MusicPause(void) { }
static void MusicResume(void) { }
static void* MusicRegister(void* data, int len) { (void)data; (void)len; return NULL; }
static void MusicUnregister(void* handle) { (void)handle; }
static void MusicPlay(void* handle, boolean looping) { (void)handle; (void)looping; }
static void MusicStop(void) { }
static boolean MusicIsPlaying(void) { return false; }

music_module_t DG_music_module = {
	NULL, 0, MusicInit, MusicShutdown, MusicVolume, MusicPause, MusicResume, MusicRegister, MusicUnregister, MusicPlay, MusicStop, MusicIsPlaying, NULL,
};
