// pd_coro.h: a tiny coroutine, so the Doom engine can be PAUSED in the middle of its work and continued on the next frame.
//
// WHY: the Playdate stops any app that does not return to its main loop within 10 seconds. Doom's start-up and, much more, loading a level (reading and
// building hundreds of textures) are long jobs that the engine does in one go, written for computers thousands of times faster. A coroutine gives the engine
// its OWN stack: the main loop "resumes" it, it works, and whenever it has used its time slice (at its next file read, which happens all through loading) it
// "yields" back. The main loop draws a loading screen and resumes it on the next frame. To the engine, nothing happened: it simply continues where it was.
#ifndef PD_CORO_H
#define PD_CORO_H

typedef enum { CORO_FRAME = 1, CORO_SLICE = 2, CORO_DEAD = 3 } CoroReason;

// Creates the coroutine with a stack of `stackBytes` bytes that will run `entry`. Returns 0 on success.
int coro_start(void (*entry)(void), unsigned int stackBytes);

// Runs the coroutine until it yields. Returns why it stopped (CoroReason).
int coro_resume(void);

// Called from inside the coroutine: stops it and returns to coro_resume().
void coro_yield(int reason);

// 1 while code is running inside the coroutine.
int coro_inside(void);

// 1 if the coroutine's stack has been overwritten (its guard value at the bottom was changed): the stack was too small.
int coro_overflowed(void);

#endif
