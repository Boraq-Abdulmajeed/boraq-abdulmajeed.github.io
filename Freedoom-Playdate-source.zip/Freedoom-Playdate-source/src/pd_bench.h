// pd_bench.h: the timedemo benchmark's one function (see pd_bench.c). Only used when TEST_TIMEDEMO is 1.
#ifndef PD_BENCH_H
#define PD_BENCH_H
void Bench_Report(const char* message);   // `message` is the engine's last words ("timed N gametics in M realtics (F fps)")
#endif
