// pd_bench.c: the DOOM benchmark ("timedemo") report. Compiled only when TEST_TIMEDEMO is 1 (a number 1-4 = which of Freedoom's built-in demos).
//
// WHAT A DEMO IS
// Freedoom's game data has four recorded games, DEMO1 to DEMO4. A demo is not a video: it is the player's button presses, four bytes per game tic
// (35 a second): forward and sideways speed, turning, and the fire / use buttons. Doom is deterministic, so feeding the same presses to the same
// game always gives the same result. That makes a demo a test (does the game logic work on this machine?) and a benchmark (how fast can it be played?).
//
// HOW THE RUN WORKS
// pd_main.c starts the engine with "-timedemo demoN" and removes the 30 fps limit. Doom then plays the demo one tic per frame, as fast as it can,
// drawing every frame (so the numbers include the drawing and the 1-bit conversion), and at the end "stops with an error" whose text is the timing:
// "timed 7117 gametics in 247 realtics (...)". pd_main.c passes that text here, and Bench_Report() writes it to benchmark.txt together with the
// final STATE of the game.
//
// WHY THE FINAL STATE MATTERS
// A demo that has gone wrong (a bug that makes the player walk into a wall instead of through the door) still plays to its last byte, so the timing line
// alone cannot show a problem. But if the game is the same on the Mac and on the Playdate, every number below comes out IDENTICAL: the player's
// position, health, kills, the random-number position and a hash of every monster and object in the level. If any of them differs between the Simulator
// and the device, the game logic differs, and that is a real bug. This is the standard way people check a Doom port on an unusual machine.
#include "pd_game.h"

#if TEST_TIMEDEMO

#include <stdio.h>
#include <string.h>
#include "doomdef.h"
#include "doomstat.h"
#include "d_player.h"
#include "p_local.h"
#include "pd_bench.h"

extern int prndindex;   // the position in Doom's table of "random" numbers (m_random.c)

#if TARGET_SIMULATOR
#define BENCH_BUILD "Simulator"
#else
#define BENCH_BUILD "Playdate device"
#endif

// A 32-bit fingerprint of every object in the level (players, monsters, items, missiles): where it is, how healthy it is, what it is.
// (FNV-1a: multiply by a prime and xor in each value.)
static unsigned levelHash(int* objects)
{
	unsigned h = 2166136261u;
	int n = 0;
	for (thinker_t* th = thinkercap.next; th != &thinkercap; th = th->next) {
		if (th->function.acp1 != (actionf_p1)P_MobjThinker) continue;
		mobj_t* m = (mobj_t*)th;
		unsigned vals[6] = { (unsigned)m->x, (unsigned)m->y, (unsigned)m->z, (unsigned)m->health, (unsigned)m->type, (unsigned)m->angle };
		for (int i = 0; i < 6; i++) { h ^= vals[i]; h *= 16777619u; }
		n++;
	}
	*objects = n;
	return h;
}

void Bench_Report(const char* message)
{
	char text[1100];
	player_t* pl = &players[consoleplayer];
	int objects = 0;
	unsigned hash = levelHash(&objects);
	snprintf(text, sizeof text,
		"DOOM TIMEDEMO RESULT\n"
		" build:  %s\n"
		" demo:   %s (map E%dM%d)\n"
		" level finished in the replay: %s\n"
		" engine: %s\n"
		"\n"
		" FINAL STATE (compare these between the Simulator and the device: they must be IDENTICAL)\n"
		"   player at (%d, %d), health %d, armor %d\n"
		"   kills %d, items %d, level time %d tics\n"
		"   random-number position %d\n"
		"   %d objects in the level, fingerprint %08X\n",
		BENCH_BUILD, TEST_TIMEDEMO == 9 ? "the bot's recorded game" : "built-in", gameepisode, gamemap,
		// the recording starts on map 1, so being on the score screen or on any later map can only mean map 1 was finished
		// (only the bot's recording is checked: the built-in demos start on later maps and are not meant to finish a level)
		TEST_TIMEDEMO != 9 ? "not checked (built-in demo)" :
		gamestate == GS_INTERMISSION ? "YES (the score screen was reached)" : gamemap > 1 ? "YES (the replay went on to the next map)" : "no", message,
		pl->mo ? pl->mo->x >> FRACBITS : 0, pl->mo ? pl->mo->y >> FRACBITS : 0, pl->health, pl->armorpoints,
		pl->killcount, pl->itemcount, leveltime, prndindex, objects, hash);
	SDFile* f = pd->file->open("benchmark.txt", kFileWrite);
	if (f != NULL) { pd->file->write(f, text, (unsigned int)strlen(text)); pd->file->close(f); }
}

#endif   // TEST_TIMEDEMO
