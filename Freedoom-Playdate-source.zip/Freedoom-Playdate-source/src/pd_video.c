// pd_video.c: Doom's screen on the Playdate's 1-bit display (this file replaces the engine's i_video.c).
//
// THE PICTURE: Doom draws a 320 x 200 picture with 256 colours, as one byte per pixel (I_VideoBuffer). The Playdate's screen is
// 400 x 240 with ONE bit per pixel (black or white). So each frame is turned into black and white dots in two steps:
//   1. every colour becomes a brightness (grayLut, rebuilt whenever Doom changes its palette: damage flashes, pickups, night vision...)
//   2. brightness becomes dots with ORDERED DITHERING: each pixel is compared with a threshold taken from an 8 x 8 repeating pattern
//      (the Bayer matrix). A mid-grey area ends up half black, half white, in a regular fine pattern, which looks like grey from a distance.
//      Ordered dithering is used (not the prettier "error diffusion") because it is fast and, importantly, does not shimmer from frame to frame.
//
// THE SHAPE: Doom's pixels are taller than wide (the original monitors were 4:3, the picture 320:200 = 8:5). Stretching 200 rows to 240
// rows (x 1.2) makes them square again, and leaves 40 black columns on each side of the 320-wide picture: 40 is a whole number of bytes (5), so the dots can be
// written a byte (8 pixels) at a time straight into the display's memory, which is by far the fastest way.
#include "pd_game.h"
#include <math.h>

#include "doomdef.h"
#include "doomtype.h"
#include "i_video.h"
#include "v_video.h"
#include "z_zone.h"
#include "d_event.h"
#include "tables.h"
#include "doomstat.h"

byte* I_VideoBuffer = NULL;
boolean screensaver_mode = false;
boolean screenvisible = true;
float mouse_acceleration = 2.0f;
int mouse_threshold = 10;
int usegamma = 0;
int usemouse = 0;
int fb_scaling = 1;

#define OUT_W 320        // the picture's width on the Playdate screen (Doom's own width)
#define OUT_H 240        // ...and its height (200 x 1.2)
#define MARGIN_BYTES 5   // black bytes on the left: 40 pixels

// TEXT MASK: the engine's patch drawing (v_video.c) marks every pixel it draws on a menu or score screen here, so menu text can be shown as
// solid white shapes with a black edge on a dimmed picture. Without it the dithering turns red letters on a red picture into mush.
byte pdTextMask[SCREENWIDTH * SCREENHEIGHT];
int pdTextMaskCount;      // how many mask pixels were set since the last frame (0 = nothing special to draw)

static uint8_t lastPalette[768];  // the palette as Doom last set it (after gamma), kept for the test dump
static uint8_t grayLut[256];     // palette colour -> brightness 0..255 (already tuned for the 1-bit screen)
static uint8_t brightness[256];  // the tuning curve: darkens nothing, lifts shadows (Doom's dark corners would otherwise be solid black)
static uint8_t thresholds[8][8]; // the dither pattern, spread over 0..255
static uint16_t sourceRow[OUT_H];// which Doom row each Playdate row shows (5 rows become 6)

extern void I_InitInput(void);

void I_InitGraphics(void)
{
	// the dither pattern: the classic 8 x 8 Bayer matrix, built from the 2 x 2 one by repeated doubling
	static const uint8_t bayer2[2][2] = { { 0, 2 }, { 3, 1 } };
	for (int y = 0; y < 8; y++) {
		for (int x = 0; x < 8; x++) {
			int v = bayer2[y & 1][x & 1];
			v = v * 4 + bayer2[(y >> 1) & 1][(x >> 1) & 1];
			v = v * 4 + bayer2[(y >> 2) & 1][(x >> 2) & 1];
			thresholds[y][x] = (uint8_t)(v * 4 + 2);   // 0..63 -> 2..254
		}
	}
	// a strong curve (exponent 0.45) that lifts the shadows, and everything above 230 counts as full white. Doom's lighting is DARK: most of a
	// level is brown and grey at 10 to 30 percent brightness, and on a 1-bit screen dark means solid black, so without this the picture
	// is mush. (Found by trying six tone curves and four dither methods on real game frames: tools/tonetest.py.)
	for (int i = 0; i < 256; i++) {
		float v = powf((float)i / 230.0f > 1.0f ? 1.0f : (float)i / 230.0f, 0.45f);
		brightness[i] = (uint8_t)(255.0f * v + 0.5f);
	}
	for (int y = 0; y < OUT_H; y++) sourceRow[y] = (uint16_t)((y * SCREENHEIGHT) / OUT_H);

	I_VideoBuffer = (byte*)Z_Malloc(SCREENWIDTH * SCREENHEIGHT, PU_STATIC, NULL);
	screenvisible = true;
	memset(pd->graphics->getFrame(), 0, LCD_ROWSIZE * LCD_ROWS);   // the side margins stay black for ever (the dots never touch them)
	I_InitInput();
}

void I_ShutdownGraphics(void) { Z_Free(I_VideoBuffer); }
void I_StartFrame(void) { }
void I_StartTic(void) { extern void I_GetEvent(void); I_GetEvent(); }
void I_UpdateNoBlit(void) { }

// MENU AND SCORE SCREENS (the text mask above): every pixel the engine drew as a patch (the menu's letters, the skull cursor, the score numbers) is
// shown without dithering: the light fill of the letters as WHITE, their dark outline as BLACK. A one-pixel BLACK edge is drawn around the letters so
// they stand out from anything behind them, and the rest of the picture (the title picture, the level behind the menu, the score screen's
// background) is dimmed to about 40 percent and dithered as usual. Before this, red letters on a red picture all dithered to the same mush.
#define MENU_DIM_NUM 2   // the background brightness is multiplied by 2 / 5 (0.4)
#define MENU_DIM_DEN 5

static void drawTextScreen(uint8_t* frame)
{
	const uint8_t* lut = grayLut;
	static uint8_t g[SCREENWIDTH];
	// The font's letters have a light fill, a shaded lower half and a dark outline. Showing every letter pixel as white joins the letters into blobs;
	// showing only the light fill cuts the letters in half. In between: a letter pixel is black only if it is much darker than the average letter pixel.
	int sum = 0, n = 0;
	for (int i = 0; i < SCREENWIDTH * SCREENHEIGHT; i++) if (pdTextMask[i]) { sum += lut[I_VideoBuffer[i]]; n++; }
	const int fillThreshold = n > 0 ? (sum / n) * 45 / 100 : 60;   // 45 percent of the average: only the darkest outline pixels stay black (the full average cut the letters in half)
	for (int y = 0; y < OUT_H; y++) {
		int row = sourceRow[y];
		const byte* src = I_VideoBuffer + row * SCREENWIDTH;
		const byte* m = pdTextMask + row * SCREENWIDTH;
		const byte* mUp = row > 0 ? m - SCREENWIDTH : m;
		const byte* mDown = row < SCREENHEIGHT - 1 ? m + SCREENWIDTH : m;
		for (int x = 0; x < SCREENWIDTH; x++) g[x] = (uint8_t)((lut[src[x]] * MENU_DIM_NUM) / MENU_DIM_DEN);
		uint8_t* dst = frame + y * LCD_ROWSIZE + MARGIN_BYTES;
		const uint8_t* t = thresholds[y & 7];
		for (int b = 0; b < OUT_W / 8; b++) {
			int bits = 0;
			for (int k = 0; k < 8; k++) {
				int x = b * 8 + k;
				int white;
				if (m[x]) {
					white = lut[src[x]] >= fillThreshold;                // text: the light fill is white, the dark outline stays black
				} else {
					int xl = x > 0 ? x - 1 : x, xr = x < SCREENWIDTH - 1 ? x + 1 : x;
					int near = m[xl] | m[xr] | mUp[x] | mDown[x] | mUp[xl] | mUp[xr] | mDown[xl] | mDown[xr];
					white = near ? 0 : (g[x] > t[k]);                    // the black edge, or the dimmed picture
				}
				bits = (bits << 1) | white;
			}
			*dst++ = (uint8_t)bits;
		}
	}
	pd->graphics->markUpdatedRows(0, LCD_ROWS - 1);
}

// Draws the finished Doom frame as black and white dots. Called by the engine once per frame.
//
// EDGE BOOST: before the dither, each pixel is pushed away from the average of its left and right neighbours (an "unsharp mask" in one
// direction). Doom's walls are made of vertical edges (brick joints, door frames, pillars) and a plain dither smears them into the same grey
// speckle as the surfaces; the boost keeps them as crisp lines. It costs three table reads per pixel; the whole frame is still a few milliseconds.
#define EDGE_BOOST 7   // the boost is (2 x pixel - left - right) x 7 / 16, about 0.44

// AUTO EXPOSURE: a dim corridor and a bright courtyard need different treatment, or one comes out as mush and the other as a white wall. Every frame
// the average brightness of a sparse grid of pixels in the 3D view is measured, and a bias is added to every pixel (the dither threshold effectively
// moves) to pull the average toward a middle value. It changes slowly (an eighth of the way each frame) so it never flickers.
#define EXPOSURE_TARGET 100
int pdPictureBias = 0;       // a manual brightness nudge (-30 darker, +30 brighter); its menu item was replaced by "turn" on 2026-11-18, so it stays 0
static int autoBias;

static int measureBias(const uint8_t* lut)
{
	int sum = 0, n = 0;
	for (int y = 14; y < 160; y += 14)
		for (int x = 12; x < SCREENWIDTH - 12; x += 24) { sum += lut[I_VideoBuffer[y * SCREENWIDTH + x]]; n++; }
	int mean = sum / n;
	int want = ((EXPOSURE_TARGET - mean) * 3) / 4;
	if (want > 60) want = 60;
	if (want < -60) want = -60;
	autoBias += (want - autoBias) / 8;
	return autoBias + pdPictureBias;
}

void I_FinishUpdate(void)
{
	uint8_t* frame = pd->graphics->getFrame();
	const uint8_t* lut = grayLut;
	if (pdTextMaskCount > 0 && (menuactive || gamestate != GS_LEVEL)) {   // a menu or score screen with text: draw it so the text can be read
		drawTextScreen(frame);
		memset(pdTextMask, 0, sizeof pdTextMask);
		pdTextMaskCount = 0;
		return;
	}
	if (pdTextMaskCount > 0) { memset(pdTextMask, 0, sizeof pdTextMask); pdTextMaskCount = 0; }   // left over from before (for example a menu that just closed)
	int cachedRow = -1;
	const int bias = measureBias(lut);
	static uint8_t g[SCREENWIDTH + 2];     // one row of brightnesses with a copy of the edge pixels at both ends
	for (int y = 0; y < OUT_H; y++) {
		int row = sourceRow[y];
		if (row != cachedRow) {              // 5 source rows are drawn as 6 output rows, so one in six reuses the previous row's brightnesses
			const byte* src = I_VideoBuffer + row * SCREENWIDTH;
			for (int x = 0; x < SCREENWIDTH; x++) g[x + 1] = lut[src[x]];
			g[0] = g[1];
			g[SCREENWIDTH + 1] = g[SCREENWIDTH];
			cachedRow = row;
		}
		uint8_t* dst = frame + y * LCD_ROWSIZE + MARGIN_BYTES;
		const uint8_t* t = thresholds[y & 7];
		const uint8_t* p = g + 1;
		for (int b = 0; b < OUT_W / 8; b++) {   // 40 bytes = 320 pixels; one byte = 8 pixels, the leftmost is the top bit, a 1 bit is WHITE
			int v0 = p[0] + bias + (((2 * p[0] - p[-1] - p[1]) * EDGE_BOOST) >> 4);
			int v1 = p[1] + bias + (((2 * p[1] - p[0] - p[2]) * EDGE_BOOST) >> 4);
			int v2 = p[2] + bias + (((2 * p[2] - p[1] - p[3]) * EDGE_BOOST) >> 4);
			int v3 = p[3] + bias + (((2 * p[3] - p[2] - p[4]) * EDGE_BOOST) >> 4);
			int v4 = p[4] + bias + (((2 * p[4] - p[3] - p[5]) * EDGE_BOOST) >> 4);
			int v5 = p[5] + bias + (((2 * p[5] - p[4] - p[6]) * EDGE_BOOST) >> 4);
			int v6 = p[6] + bias + (((2 * p[6] - p[5] - p[7]) * EDGE_BOOST) >> 4);
			int v7 = p[7] + bias + (((2 * p[7] - p[6] - p[8]) * EDGE_BOOST) >> 4);
			*dst++ = (uint8_t)(((v0 > t[0]) << 7) | ((v1 > t[1]) << 6) | ((v2 > t[2]) << 5) | ((v3 > t[3]) << 4) |
				((v4 > t[4]) << 3) | ((v5 > t[5]) << 2) | ((v6 > t[6]) << 1) | (v7 > t[7]));
			p += 8;
		}
	}
	pd->graphics->markUpdatedRows(0, LCD_ROWS - 1);
}

void I_ReadScreen(byte* scr) { memcpy(scr, I_VideoBuffer, SCREENWIDTH * SCREENHEIGHT); }

// Doom changes its palette to tint the screen (red when hurt, yellow when picking things up, green with the radiation suit...). Each
// entry becomes a brightness here, with Doom's gamma setting applied first.
void I_SetPalette(byte* palette)
{
	for (int i = 0; i < 256; i++) {
		int r = gammatable[usegamma][*palette++];
		int g = gammatable[usegamma][*palette++];
		int b = gammatable[usegamma][*palette++];
		lastPalette[i * 3] = (uint8_t)r; lastPalette[i * 3 + 1] = (uint8_t)g; lastPalette[i * 3 + 2] = (uint8_t)b;
		int luma = (r * 77 + g * 151 + b * 28) >> 8;   // the usual weights: the eye sees green brightest, blue dimmest
		grayLut[i] = brightness[luma];
	}
}

// Used for translucent effects in other Doom variants; here it just finds the closest grey.
int I_GetPaletteIndex(int r, int g, int b)
{
	int want = (r * 77 + g * 151 + b * 28) >> 8, best = 0, bestDiff = 1 << 30;
	for (int i = 0; i < 256; i++) {
		int d = (int)grayLut[i] - want;
		d = d < 0 ? -d : d;
		if (d < bestDiff) { bestDiff = d; best = i; }
	}
	return best;
}

void I_BeginRead(void) { }
void I_EndRead(void) { }
void I_SetWindowTitle(char* title) { }
void I_GraphicsCheckCommandLine(void) { }
void I_SetGrabMouseCallback(grabmouse_callback_t func) { }
void I_EnableLoadingDisk(void) { }
void I_BindVideoVariables(void) { }
void I_DisplayFPSDots(boolean dots_on) { }
void I_CheckIsScreensaver(void) { }
void I_InitWindowTitle(void) { }
void I_InitWindowIcon(void) { }

// For tests: gives out Doom's raw 8-bit frame and its palette, so the tone mapping can be tried offline on real game frames.
const uint8_t* pdVideoFrame(void) { return I_VideoBuffer; }
const uint8_t* pdVideoPalette(void) { return lastPalette; }

// Blacks out the left and right margins again (after a loading card has been drawn over them: the game's dots never touch the margins).
void pdVideoClearMargins(void)
{
	uint8_t* frame = pd->graphics->getFrame();
	for (int y = 0; y < LCD_ROWS; y++) {
		uint8_t* row = frame + y * LCD_ROWSIZE;
		memset(row, 0, MARGIN_BYTES);
		memset(row + MARGIN_BYTES + OUT_W / 8, 0, LCD_ROWSIZE - MARGIN_BYTES - OUT_W / 8);
	}
}
