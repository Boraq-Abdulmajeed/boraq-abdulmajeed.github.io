// pd_main.c: DOOM on the Playdate. The app's entry point, its main loop, and the controls.
//
// HOW IT FITS TOGETHER
//   The engine (doomgeneric, the real Doom source) does the game. The Playdate layer (this file and its neighbours) does everything the
//   engine expects from the machine it runs on:
//     pd_main.c   starts the engine, calls it once per frame, turns the Playdate's buttons and crank into Doom keys, shows messages
//     pd_video.c  turns Doom's 256-colour picture into the Playdate's black and white dots
//     pd_input.c  hands key and crank events to the engine
//     pd_wad.c    reads the game data (the "WAD" file) from disk without loading all of it into memory
//     pd_stdio.*  gives the engine the C library file functions it was written for
//
// CONTROLS (the crank is the aim: it turns like a mouse, smoothly, instead of the keyboard's fixed turn speed)
//   Crank        turn left and right (one crank turn = two full turns; Doom's menu "Mouse sensitivity" changes it)
//   Ⓐ            fire
//   Ⓑ            use (open doors, press switches). In SOLO controls: a quick tap uses; HOLDING walks forward
//   D-pad        up and down walk, left and right strafe
//   Ⓐ + Ⓑ        a quick tap shows or hides the map; HOLDING both opens Doom's own menu (new game, skill level, save, load, options)
//   Menu button  "weapon" (next weapon), "controls" (solo or classic), "turn" (crank sensitivity 1-5, saved; 3 = normal)
//   In Doom's menus: D-pad moves, Ⓐ chooses, Ⓑ goes back, and the crank also moves the selection.
// SOLO controls exist because the user holds the Playdate with the left hand on Ⓐ/Ⓑ and the right on the crank, where the D-pad is out of reach.
#include "pd_game.h"
#include "pd_coro.h"

#include "doomkeys.h"
#include "doomgeneric.h"
#include "doomstat.h"
#include "d_event.h"
#if TEST_BOT
#include "pd_bot.h"
#endif

// Test switches (Simulator checks): SCREEN_DUMP writes the screen to screen.pbm in the data folder every 2 s; TIMING_LOG writes doom.log with how long
// start-up and each frame take. Both are harmless but should be 0 in a finished build.
#ifndef SCREEN_DUMP
#define SCREEN_DUMP 0
#endif
#ifndef TIMING_LOG
#define TIMING_LOG 1
#endif
#ifndef TEST_PLAY
#define TEST_PLAY 0
#endif    // 1: a scripted player (fires, walks, turns) so the Simulator can be watched without pressing anything. 0 in a finished build.
#ifndef TEST_BOT
#define TEST_BOT 0
#endif
#ifndef TEST_TIMEDEMO
#define TEST_TIMEDEMO 0   // 1-4: play Freedoom's built-in DEMOn as fast as possible, then write benchmark.txt. See pd_bench.c. 0 in a finished build.
#endif
#ifndef BOT_RECORD
#define BOT_RECORD 0      // 1: the bot's game is recorded as a demo, botrun.lmp, in the data folder. The file can then be replayed on the real Playdate: see tools/build_bench.sh.
#endif
#if BOT_RECORD
extern int botStopDemo;   // set by the bot a moment after the score screen appears
boolean G_CheckDemoStatus(void);
#endif
#if TEST_TIMEDEMO
#include "pd_bench.h"
#endif    // 1: a bot plays the game by itself (menus, fighting, walking to the exit), for watching in the Simulator. See pd_bot.c. 0 in a finished build.
#ifndef TEST_WARP
#define TEST_WARP 0
#endif    // 1: start straight in episode 1, map 1 (to look at gameplay without pressing buttons). 0 in a finished build.
// The name on the loading and error cards. The private build says DOOM; the public build (tools/package_public.sh) passes
// -DGAME_TITLE=\"FREEDOOM\", because "DOOM" is id Software's trademark and the public game is Freedoom.
#ifndef GAME_TITLE
#define GAME_TITLE "DOOM"
#endif

PlaydateAPI* pd;
char pdLastMessage[160];
int pdExitCode;
int pdSolo = 1;

extern int detailLevel;       // m_menu.c: 1 = low detail (half as many columns drawn: about twice as fast)
extern int key_nextweapon;    // m_controls.c

// ---------------------------------------------------------------- the engine runs as a coroutine
// The engine has its own stack (see pd_coro.h). The main loop resumes it once per frame; it yields when a frame is finished (CORO_FRAME), or, during
// the long loading jobs, when it has used its time slice (CORO_SLICE): the system stops an app that does not return within 10 seconds, so slices stay well under that.
#define ENGINE_STACK_BYTES (192 * 1024)
#ifndef TEST_SLICE_MS
#define TEST_SLICE_MS 0            // test only: a tiny slice (such as 5) makes the engine pause constantly, to prove that pausing and resuming works
#endif
static unsigned int sliceStart;
static unsigned int sliceMs = 1500;   // the longest the engine runs before pausing at its next file read (the worst gap between two reads must still fit in the system's 10 s)
static unsigned int slicesTaken;

// Called from the file-reading code (pd_wad.c, pd_stdio.c) and the message printer: if this time slice is used up, pause the engine here.
unsigned int pdYieldChecks, pdYieldMaxElapsed;   // counters for the timing log
void pdMaybeYield(void)
{
	if (!coro_inside()) return;
	unsigned int elapsed = pd->system->getCurrentTimeMilliseconds() - sliceStart;
	pdYieldChecks++;
	if (elapsed > pdYieldMaxElapsed) pdYieldMaxElapsed = elapsed;
	if (elapsed >= sliceMs) coro_yield(CORO_SLICE);
}

// The engine "exits" (an error): stop for good. It is never resumed, and the main loop shows the engine's last message.
void pdEscape(void)
{
	coro_yield(CORO_DEAD);
	for (;;) { }
}

typedef enum { ST_BOOT, ST_LOADING, ST_RUNNING, ST_DEAD } State;
static State state = ST_BOOT;

// ---------------------------------------------------------------- the machine, as the engine sees it
void DG_Init(void) { }
void DG_DrawFrame(void) { }                    // pd_video.c draws straight into the display, so there is nothing to copy
void DG_SleepMs(uint32_t ms) { (void)ms; }     // never sleep: the Playdate calls us once per frame by itself
uint32_t DG_GetTicksMs(void) { return pd->system->getCurrentTimeMilliseconds(); }
int DG_GetKey(int* pressed, unsigned char* key) { (void)pressed; (void)key; return 0; }   // keys come in through pd_input.c instead
void DG_SetWindowTitle(const char* title) { (void)title; }

// ---------------------------------------------------------------- keys
static uint8_t keyHeld[256];   // which Doom keys are down right now (so only changes are sent)

// Sets a Doom key down or up. Only a change produces an event.
static void setKey(int key, int down)
{
	if (keyHeld[key] == (uint8_t)down) return;
	keyHeld[key] = (uint8_t)down;
	PDInput_Key(key, down);
}

// "Taps" are a key pressed for exactly one frame and released on the next (for actions like "next weapon").
static int tapNow[4];      // keys to press this frame (0 = none)
static int tapRelease[4];  // keys to release this frame
static void tap(int key)
{
	for (int i = 0; i < 4; i++) if (tapNow[i] == 0) { tapNow[i] = key; return; }
}

static void runTaps(void)
{
	for (int i = 0; i < 4; i++) { if (tapRelease[i] != 0) { setKey(tapRelease[i], 0); tapRelease[i] = 0; } }
	for (int i = 0; i < 4; i++) { if (tapNow[i] != 0) { setKey(tapNow[i], 1); tapRelease[i] = tapNow[i]; tapNow[i] = 0; } }
}

// ---------------------------------------------------------------- the Playdate's system menu
static PDMenuItem* controlsItem;
static PDMenuItem* turnItem;
static void onWeapon(void* ud) { (void)ud; tap(KEY_PGUP); }                // the engine's "next weapon" key (set up in startEngine)
static void onControls(void* ud) { (void)ud; pdSolo = pd->system->getMenuItemValue(controlsItem) == 0; }

// ---- turn speed (crank sensitivity), added 2026-11-18 at the user's request
// The system menu holds at most three items of our own, so "turn" took the place of the old "picture" item (auto, bright, dark).
// The picture still adjusts its own brightness (auto exposure in pd_video.c), which is what "auto" did; only the manual nudge is gone.
// Doom's own Options menu also has a "Mouse sensitivity" slider, but the engine saves it only when it shuts down normally, which a
// Playdate app never does, so the choice would be forgotten. Ours is saved at once to turn.txt in the game's data folder.
static const char* kTurnNames[] = { "1", "2", "3", "4", "5" };
static const float kTurnGear[] = { 0.5f, 0.75f, 1.0f, 1.4f, 1.9f };   // x the normal gear (one crank turn = two turns of the player)
#define TURN_DEFAULT 2                                                  // "3" = the gear the game always had
static int turnIndex = TURN_DEFAULT;

/** Reads the saved turn speed (one digit, 1-5) if there is one; a missing or odd file keeps the default. */
static void loadTurn(void)
{
	SDFile* f = pd->file->open("turn.txt", kFileReadData);
	if (f == NULL) return;
	char c = 0;
	if (pd->file->read(f, &c, 1) == 1 && c >= '1' && c <= '5') turnIndex = c - '1';
	pd->file->close(f);
}

/** Saves the turn speed as one digit, so it is kept the next time the game starts. */
static void saveTurn(void)
{
	SDFile* f = pd->file->open("turn.txt", kFileWrite);
	if (f == NULL) return;
	char c = (char)('1' + turnIndex);
	pd->file->write(f, &c, 1);
	pd->file->close(f);
}

/** Called by the system when the menu closes with a new "turn" value. */
static void onTurn(void* ud)
{
	(void)ud;
	turnIndex = pd->system->getMenuItemValue(turnItem) % 5;
	saveTurn();
}

// ---------------------------------------------------------------- reading the buttons and the crank, once per frame
#define TURN_COUNTS_PER_DEGREE 45.5f   // mouse counts per crank degree: 22.75 counts turn the player one degree, so this is a gear of 2
#define MENU_CRANK_STEP 40.0f          // degrees of crank per menu selection step
#define SOLO_HOLD_MS 220               // in SOLO controls, Ⓑ held this long walks forward (shorter = a "use" tap)
#define CHORD_MS 450                   // Ⓐ and Ⓑ held together this long opens Doom's menu

static float crankLeft;     // turn the crank has made that has not yet become a mouse count (the fraction, kept so slow turns still count)
static float menuCrank;     // crank degrees collected while in a menu
static unsigned int bDownAt;
static int bState;          // 0 = up, 1 = down and undecided (solo), 2 = walking
static unsigned int chordSince;
static int chordDone;      // the long hold (Doom's menu) already happened
static int chordSeen;      // both buttons were down together since they were last both up
static int wasInMenu;      // whether the last frame was a menu (or another screen that is not a level)
static unsigned int heldAcross;   // Ⓐ/Ⓑ held through a menu/level switch: ignored until let go (see readInput)

static void readInput(unsigned int now)
{
	PDButtons cur, pushed, released;
	pd->system->getButtonState(&cur, &pushed, &released);
	float crank = pd->system->getCrankChange();
#if TEST_PLAY
	{   // a scripted player: walk forward for 2 s out of every 5, fire in short bursts, and sweep the crank back and forth
		unsigned int phase = now % 5000;
		cur = (PDButtons)0;
		if (phase < 2000) cur = (PDButtons)(cur | kButtonUp);
		if ((now / 400) % 3 == 0) cur = (PDButtons)(cur | kButtonA);
		crank = (phase < 2500) ? 2.0f : -2.0f;
		pushed = released = (PDButtons)0;
	}
#endif
	int inMenu = menuactive || gamestate != GS_LEVEL;   // Doom's own menu, or a screen between levels (title, scores, finale)

#if TEST_BOT
	{   // the bot replaces the player: it "holds" buttons and turns by mouse counts, like the crank would
		BotOut bo;
		Bot_Think(now, inMenu, &bo);
		cur = (PDButtons)bo.buttons;
		pushed = released = (PDButtons)0;
		crank = 0;
		if (!inMenu && bo.mouse != 0) PDInput_Mouse(bo.mouse);
	}
#endif

#if !TEST_BOT
	// Buttons that are still held when the game switches between a level and a menu are ignored until they are let go.
	// Without this, holding Ⓐ+Ⓑ to open Doom's menu (see CHORD_MS) handed the still-held Ⓐ (choose) and Ⓑ (back) to the
	// menu on its very first frame, so it chose "New Game" and closed again at once (found on the device, 2026-11-14);
	// and choosing a menu item with Ⓐ fired a shot the moment the level came back.
	if (inMenu != wasInMenu) {
		wasInMenu = inMenu;
		heldAcross = (unsigned int)cur & (kButtonA | kButtonB);
	}
	heldAcross &= (unsigned int)cur;   // a button that has been let go counts again
	cur = (PDButtons)((unsigned int)cur & ~heldAcross);
	pushed = (PDButtons)((unsigned int)pushed & ~heldAcross);
#endif

	runTaps();

	if (inMenu) {
		// everything that is not a level: D-pad = arrows, Ⓐ = choose, Ⓑ = back; the crank also steps through choices
		setKey(KEY_UPARROW, (cur & kButtonUp) != 0);
		setKey(KEY_DOWNARROW, (cur & kButtonDown) != 0);
		setKey(KEY_LEFTARROW, (cur & kButtonLeft) != 0);
		setKey(KEY_RIGHTARROW, (cur & kButtonRight) != 0);
		setKey(KEY_ENTER, (cur & kButtonA) != 0);
		setKey(KEY_ESCAPE, (cur & kButtonB) != 0);
		// The score screen and the finale do not listen to Enter: Doom moves them on with the FIRE or USE button, so Ⓐ must also be fire there, or a player can never
		// leave the score screen after a level (the bot found this on 2026-10-30). In a menu fire stays off, so choosing an item never shoots.
		setKey(KEY_FIRE, !menuactive && (gamestate == GS_INTERMISSION || gamestate == GS_FINALE) && (cur & kButtonA) != 0);
		setKey(KEY_USE, 0);
		setKey(KEY_STRAFE_L, 0);
		setKey(KEY_STRAFE_R, 0);
		menuCrank += crank;
		while (menuCrank >= MENU_CRANK_STEP) { menuCrank -= MENU_CRANK_STEP; tap(KEY_DOWNARROW); }
		while (menuCrank <= -MENU_CRANK_STEP) { menuCrank += MENU_CRANK_STEP; tap(KEY_UPARROW); }
		bState = 0;
		chordSince = 0;
		return;
	}
	menuCrank = 0;
	setKey(KEY_ENTER, 0);
	setKey(KEY_ESCAPE, 0);
	setKey(KEY_LEFTARROW, 0);
	setKey(KEY_RIGHTARROW, 0);

	// walking and strafing (the D-pad is optional in SOLO controls)
	int forward = (cur & kButtonUp) != 0;
	setKey(KEY_DOWNARROW, (cur & kButtonDown) != 0);
	setKey(KEY_STRAFE_L, (cur & kButtonLeft) != 0);
	setKey(KEY_STRAFE_R, (cur & kButtonRight) != 0);

	// Ⓐ fires
	setKey(KEY_FIRE, (cur & kButtonA) != 0);

	// Ⓑ: classic = use. Solo = a tap uses, holding walks forward (so the left hand needs only Ⓐ and Ⓑ).
	if (!pdSolo) {
		setKey(KEY_USE, (cur & kButtonB) != 0);
		bState = 0;
	} else {
		if ((pushed & kButtonB) != 0) { bState = 1; bDownAt = now; }
		if (bState == 1 && (cur & kButtonB) != 0 && now - bDownAt >= SOLO_HOLD_MS) bState = 2;   // held long enough: walking
		if ((released & kButtonB) != 0 || (cur & kButtonB) == 0) {
			if (bState == 1 && !chordSeen) tap(KEY_USE);   // let go quickly: it was a tap (but not the end of an A+B chord)
			bState = 0;
		}
		if (bState == 2) forward = 1;
	}
	setKey(KEY_UPARROW, forward);

	// Ⓐ + Ⓑ together: a quick tap shows or hides the map; holding opens Doom's menu
	if ((cur & kButtonA) && (cur & kButtonB)) {
		chordSeen = 1;
		if (chordSince == 0) chordSince = now;
		if (!chordDone && now - chordSince >= CHORD_MS) { chordDone = 1; tap(KEY_ESCAPE); }
	} else if (!(cur & (kButtonA | kButtonB))) {
		if (chordSeen && !chordDone) tap(KEY_TAB);   // both let go before the hold time: the map
		chordSince = 0;
		chordDone = 0;
		chordSeen = 0;
	}

	// the crank turns the player, like a mouse
	crankLeft += crank * TURN_COUNTS_PER_DEGREE * kTurnGear[turnIndex];   // the "turn" setting scales the gear
	int counts = (int)crankLeft;
	crankLeft -= (float)counts;
	if (counts != 0) PDInput_Mouse(counts);
}

// ---------------------------------------------------------------- starting the engine
static char wadName[32] = "freedoom1.wad";
static char* engineArgs[16];

// Fills in the engine's command line and starts it. This is the slow part (a few seconds on the device: it reads the game data's index,
// builds Doom's texture tables and loads the first screens), and it runs inside ONE frame, so it must stay under the system's
// 10-second limit for a frame (the system stops an app that does not return in time).
static void startEngine(void)
{
	int argc = 0;
	static char mb[] = "6";
	// a WAD put in the app's data folder (over USB: Data/com.braq.doom/doom.wad, or com.braq.freedoom in the public build) replaces the built-in Freedoom: that is how you play your
	// own copy of the original game's data
	SDFile* own = pd->file->open("doom.wad", kFileReadData);
	if (own != NULL) { pd->file->close(own); snprintf(wadName, sizeof wadName, "doom.wad"); }
	engineArgs[argc++] = "doom";
	engineArgs[argc++] = "-iwad";
	engineArgs[argc++] = wadName;
	engineArgs[argc++] = "-mb";          // the engine's memory pool, in megabytes (of the Playdate's 16)
	engineArgs[argc++] = mb;
	engineArgs[argc++] = "-nomusic";
#if TEST_TIMEDEMO
	{ static char demoName[8]; snprintf(demoName, sizeof demoName, TEST_TIMEDEMO == 9 ? "botrun" : "demo%d", TEST_TIMEDEMO); engineArgs[argc++] = "-timedemo"; engineArgs[argc++] = demoName; engineArgs[argc++] = "-skill"; engineArgs[argc++] = "3"; }
#endif
#if BOT_RECORD
	engineArgs[argc++] = "-record"; engineArgs[argc++] = "botrun";   // needs a fixed start, so the game is entered directly instead of through the menus
	engineArgs[argc++] = "-warp"; engineArgs[argc++] = "1"; engineArgs[argc++] = "1";
	engineArgs[argc++] = "-skill"; engineArgs[argc++] = "3";
#endif
#if TEST_WARP
	engineArgs[argc++] = "-warp"; engineArgs[argc++] = "1"; engineArgs[argc++] = "1";
	engineArgs[argc++] = "-skill"; engineArgs[argc++] = "3";
#endif
	detailLevel = 1;                     // low detail: Doom draws every second column and doubles it: much faster, slightly chunkier
	key_nextweapon = KEY_PGUP;           // the engine has no default key for "next weapon"; the system menu item presses this one
	doomgeneric_Create(argc, engineArgs);
}

// What runs on the engine's own stack: start-up, then one game frame each time it is resumed.
static void engineMain(void)
{
	startEngine();
	for (;;) {
		doomgeneric_Tick();
#if BOT_RECORD
		// Writing the demo ends the engine with an error message, so it must happen here on the engine's own stack.
		if (botStopDemo) { botStopDemo = 0; G_CheckDemoStatus(); }
#endif
		coro_yield(CORO_FRAME);
	}
}

// ---------------------------------------------------------------- the screens that are not the game
static void drawCard(const char* title, const char* line1, const char* line2)
{
	pd->graphics->clear(kColorWhite);
	pd->graphics->drawText(title, strlen(title), kUTF8Encoding, 12, 20);
	if (line1 != NULL) pd->graphics->drawText(line1, strlen(line1), kUTF8Encoding, 12, 60);
	if (line2 != NULL) pd->graphics->drawText(line2, strlen(line2), kUTF8Encoding, 12, 90);
}

#if TIMING_LOG || SCREEN_DUMP
static SDFile* logFile;

// Appends one line to doom.log in the app's data folder.
static void fileLog(const char* fmt, ...)
{
	char line[200];
	va_list args;
	va_start(args, fmt);
	vsnprintf(line, sizeof line, fmt, args);
	va_end(args);
	if (logFile == NULL) logFile = pd->file->open("doom.log", kFileWrite);
	if (logFile == NULL) return;
	pd->file->write(logFile, line, (unsigned int)strlen(line));
	pd->file->write(logFile, "\n", 1);
	pd->file->flush(logFile);
}
#endif

#if SCREEN_DUMP
// Writes the display as a PBM picture (1 = black in PBM, white in the Playdate's memory, hence the inversion).
static void dumpScreen(unsigned int now)
{
	static unsigned int next;
	if (now < next) return;
	next = now + 2000;
	SDFile* f = pd->file->open("screen.pbm", kFileWrite);
	if (f == NULL) return;
	const char* header = "P4\n400 240\n";
	pd->file->write(f, header, (unsigned int)strlen(header));
	uint8_t* frame = pd->graphics->getFrame();
	uint8_t row[50];
	for (int y = 0; y < 240; y++) {
		for (int i = 0; i < 50; i++) row[i] = (uint8_t)~frame[y * LCD_ROWSIZE + i];
		pd->file->write(f, row, 50);
	}
	pd->file->close(f);
	// the raw 8-bit frame (320 x 200) and palette, for trying tone mappings offline
	extern const uint8_t* pdVideoFrame(void);
	extern const uint8_t* pdVideoPalette(void);
	SDFile* raw = pd->file->open("frame8.raw", kFileWrite);
	if (raw != NULL) {
		pd->file->write(raw, pdVideoPalette(), 768);
		pd->file->write(raw, pdVideoFrame(), 320 * 200);
		pd->file->close(raw);
	}
}
#endif

#if TIMING_LOG
static unsigned int startupT0;
// Every line the engine prints during start-up ("R_Init: ...", "P_Init: ...") is written to doom.log with the time since start-up began. That shows which
// step is slow: on the Playdate every step must finish well inside one frame of the system's 10-second limit.
static void traceLine(const char* line)
{
	if (startupT0 == 0) return;
	char text[100];
	snprintf(text, sizeof text, "%s", line);
	for (char* c = text; *c; c++) if (*c == '\n') *c = ' ';
	fileLog("  +%5u ms  %s", pd->system->getCurrentTimeMilliseconds() - startupT0, text);
}
#endif

extern void pdVideoClearMargins(void);   // pd_video.c
static int cardShown;                    // a loading card is on the display: the black side margins must be redrawn before the game frame returns

// Runs the engine for one slice and reacts to why it stopped.
static void runEngine(unsigned int now)
{
	readInput(now);
	sliceStart = now;
	int why = coro_resume();
#if TIMING_LOG && defined(TEST_SLICE_MS)
	if (TEST_SLICE_MS) { static int n; if (n++ < 40) { extern unsigned int pdWadReads, pdWadBytes; extern unsigned int pdYieldChecks, pdYieldMaxElapsed; fileLog("  resume #%d -> reason %d at +%u ms (reads %u, checks %u, max elapsed in a slice %u ms)", n, why, pd->system->getCurrentTimeMilliseconds() - startupT0, pdWadReads, pdYieldChecks, pdYieldMaxElapsed); pdYieldMaxElapsed = 0; } }
#endif
	if (coro_overflowed()) { snprintf(pdLastMessage, sizeof pdLastMessage, "the engine's stack overflowed (raise ENGINE_STACK_BYTES)"); state = ST_DEAD; return; }
	if (why == CORO_FRAME) {
		if (cardShown) { pdVideoClearMargins(); cardShown = 0; }
		state = ST_RUNNING;
	} else if (why == CORO_SLICE) {
		slicesTaken++;
		static const char* dots[4] = { "loading", "loading.", "loading..", "loading..." };
		drawCard(GAME_TITLE, dots[slicesTaken & 3], "undock the crank to turn");
		cardShown = 1;
	} else {
		state = ST_DEAD;
	}
}

static int update(void* userdata)
{
	(void)userdata;
	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	switch (state) {
	case ST_BOOT:
		// one frame to show the loading card before the engine starts
		drawCard(GAME_TITLE, "loading...", "undock the crank to turn");
		cardShown = 1;
		state = ST_LOADING;
		return 1;
	case ST_LOADING: {
		static int started;
		if (!started) {
			started = 1;
#if TEST_SLICE_MS
			sliceMs = TEST_SLICE_MS;
#endif
#if TIMING_LOG
			startupT0 = now;
			pdLineHook = traceLine;
#endif
			if (coro_start(engineMain, ENGINE_STACK_BYTES) != 0) { snprintf(pdLastMessage, sizeof pdLastMessage, "no memory for the engine's stack"); state = ST_DEAD; return 1; }
		}
		runEngine(now);
#if TEST_BOT
		{ static unsigned botLoadT0; if (!botLoadT0) botLoadT0 = now; if (state == ST_RUNNING) Bot_Loaded(pd->system->getCurrentTimeMilliseconds() - botLoadT0); }
#endif
#if TIMING_LOG
		if (state == ST_RUNNING) { extern unsigned int pdWadReads, pdWadBytes;
			fileLog("loaded after %u ms and %u slices; %u WAD reads, %u bytes", pd->system->getCurrentTimeMilliseconds() - startupT0, slicesTaken, pdWadReads, pdWadBytes); startupT0 = 0; }
#endif
		return 1; }
	case ST_RUNNING:
		runEngine(now);
#if TEST_BOT
		Bot_FrameDone(now, pd->system->getCurrentTimeMilliseconds() - now);
#endif
#if TIMING_LOG
		{   // every 3 s: how many frames were drawn and how long a frame took on average
			static unsigned int windowStart, frames, busyMs;
			unsigned int after = pd->system->getCurrentTimeMilliseconds();
			busyMs += after - now;
			frames++;
			if (after - windowStart >= 3000) {
				fileLog("%u frames in %u ms (%.1f per second), %.1f ms of work per frame, state %d, %u slices so far", frames, after - windowStart,
					1000.0f * (float)frames / (float)(after - windowStart), (float)busyMs / (float)frames, (int)state, slicesTaken);
				windowStart = after; frames = 0; busyMs = 0;
			}
		}
#endif
#if SCREEN_DUMP
		dumpScreen(now);
#endif
		return 1;
	default: {
		char code[40];
		snprintf(code, sizeof code, "(code %d)", pdExitCode);
#if TEST_TIMEDEMO
		{ static int reported; if (!reported) { reported = 1; Bench_Report(pdLastMessage); fileLog("benchmark: %s", pdLastMessage); } }
#endif
		drawCard(GAME_TITLE " stopped", pdLastMessage[0] ? pdLastMessage : "the engine stopped", code);
		return 1;
	}
	}
}

#ifdef _WINDLL
__declspec(dllexport)
#endif
int eventHandler(PlaydateAPI* playdate, PDSystemEvent event, uint32_t arg)
{
	(void)arg;
	if (event == kEventInit) {
		pd = playdate;
		pd->display->setRefreshRate(TEST_TIMEDEMO ? 0 : 30);   // 0 = no limit: a benchmark must not be held back by the 30 fps screen
#if TEST_TIMEDEMO
		pd->system->setAutoLockDisabled(1);                     // nobody presses anything during a benchmark
#endif
#if TEST_BOT
		pdSolo = 0;   // the bot uses the classic layout: the D-pad walks, Ⓑ uses
		pd->system->setAutoLockDisabled(1);   // nobody presses anything during a bot run: without this the Playdate would lock itself after a minute
#endif
		static const char* options[] = { "solo", "classic" };
		pd->system->addMenuItem("weapon", onWeapon, NULL);
		controlsItem = pd->system->addOptionsMenuItem("controls", options, 2, onControls, NULL);
		loadTurn();
		turnItem = pd->system->addOptionsMenuItem("turn", kTurnNames, 5, onTurn, NULL);
		pd->system->setMenuItemValue(turnItem, turnIndex);
		pd->system->setUpdateCallback(update, NULL);
	}
	return 0;
}
