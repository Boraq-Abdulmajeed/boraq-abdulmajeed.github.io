// An empty stand-in: the engine's i_sound.c includes SDL_mixer.h when sound is switched on, but this port plays sound through the Playdate's own
// audio (pd_sound.c) and never uses SDL.
