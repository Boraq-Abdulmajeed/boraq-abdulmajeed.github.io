// pd_stdio.c: the Playdate's versions of the C library functions the Doom engine uses (see pd_stdio.h for why).
//
// A "FILE*" here is really a small struct holding the Playdate's own file handle. The engine never looks inside a FILE, so the cast is safe.
// Messages (printf and friends) go to the Playdate's log. The LAST error line the engine prints is remembered, because when Doom stops
// with an error (I_Error) the app shows that text on the screen instead of closing silently.
#include "pd_api.h"
#include "pd_game.h"

#undef fopen
#undef fclose
#undef fread
#undef fwrite
#undef fseek
#undef ftell
#undef fflush
#undef fprintf
#undef vfprintf
#undef printf
#undef puts
#undef fputs
#undef putchar
#undef exit
#undef mkdir
#undef remove
#undef rename

typedef struct {
	SDFile* file;
	int writing;
} PDFile;

// The standard output and error streams are not files: anything sent to them is logged.
static int isConsole(FILE* f) { return f == stdout || f == stderr; }

// Sends text to the log, and keeps the last non-empty line for the error screen.
void (*pdLineHook)(const char* line);

static void logLine(const char* text)
{
	if (pd == NULL) return;
	if (pdLineHook != NULL) pdLineHook(text);
	pd->system->logToConsole("%s", text);
	const char* p = text;
	while (*p == '\n' || *p == ' ') p++;
	if (*p != '\0') {
		snprintf(pdLastMessage, sizeof pdLastMessage, "%s", p);
		size_t n = strlen(pdLastMessage);
		while (n > 0 && (pdLastMessage[n - 1] == '\n' || pdLastMessage[n - 1] == ' ')) pdLastMessage[--n] = '\0';
	}
	pdMaybeYield();   // start-up prints a line for every step: another natural place to pause
}

// fopen: "r" reads (the game's own files first, then the data folder), "w" and "a" write into the data folder.
FILE* pd_fopen(const char* path, const char* mode)
{
	if (pd == NULL || path == NULL || mode == NULL) return NULL;
	FileOptions options;
	int writing = 0;
	if (mode[0] == 'w') { options = kFileWrite; writing = 1; }
	else if (mode[0] == 'a') { options = kFileAppend; writing = 1; }
	else options = (FileOptions)(kFileRead | kFileReadData);
	SDFile* file = pd->file->open(path, options);
	if (file == NULL) return NULL;
	PDFile* f = malloc(sizeof(PDFile));
	if (f == NULL) { pd->file->close(file); return NULL; }
	f->file = file;
	f->writing = writing;
	return (FILE*)f;
}

int pd_fclose(FILE* stream)
{
	PDFile* f = (PDFile*)stream;
	if (f == NULL) return -1;
	int result = pd->file->close(f->file);
	free(f);
	return result;
}

size_t pd_fread(void* buf, size_t size, size_t count, FILE* stream)
{
	PDFile* f = (PDFile*)stream;
	if (f == NULL || size == 0 || count == 0) return 0;
	int got = pd->file->read(f->file, buf, (unsigned int)(size * count));
	pdMaybeYield();
	return got <= 0 ? 0 : (size_t)got / size;
}

size_t pd_fwrite(const void* buf, size_t size, size_t count, FILE* stream)
{
	PDFile* f = (PDFile*)stream;
	if (f == NULL || size == 0 || count == 0) return 0;
	int put = pd->file->write(f->file, buf, (unsigned int)(size * count));
	return put <= 0 ? 0 : (size_t)put / size;
}

int pd_fseek(FILE* stream, long offset, int whence)
{
	PDFile* f = (PDFile*)stream;
	return f == NULL ? -1 : pd->file->seek(f->file, (int)offset, whence);
}

long pd_ftell(FILE* stream)
{
	PDFile* f = (PDFile*)stream;
	return f == NULL ? -1 : pd->file->tell(f->file);
}

int pd_fflush(FILE* stream)
{
	PDFile* f = (PDFile*)stream;
	if (f == NULL || isConsole(stream)) return 0;
	return f->writing ? pd->file->flush(f->file) : 0;
}

int pd_vfprintf(FILE* stream, const char* fmt, va_list args)
{
	char text[512];
	int n = vsnprintf(text, sizeof text, fmt, args);
	if (n < 0) return n;
	if (isConsole(stream)) { logLine(text); return n; }
	return (int)pd_fwrite(text, 1, strlen(text), stream);
}

int pd_fprintf(FILE* stream, const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	int n = pd_vfprintf(stream, fmt, args);
	va_end(args);
	return n;
}

int pd_printf(const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	int n = pd_vfprintf(stdout, fmt, args);
	va_end(args);
	return n;
}

int pd_puts(const char* text) { logLine(text); return 0; }

int pd_fputs(const char* text, FILE* stream)
{
	if (isConsole(stream)) { logLine(text); return 0; }
	return (int)pd_fwrite(text, 1, strlen(text), stream) > 0 ? 0 : -1;
}

int pd_putchar(int c) { return c; }

// Directories, deleting and renaming: the Playdate's file API has its own calls; the engine only needs them for optional saves, so they are
// simple here.
int pd_mkdir_stub(const char* path) { return pd->file->mkdir(path); }
int pd_remove(const char* path) { return pd->file->unlink(path, 0); }
int pd_rename(const char* from, const char* to) { return pd->file->rename(from, to); }

// exit: never really exit. Jump back to the main loop (pd_main.c), which shows the last message the engine printed.
void pd_exit(int code)
{
	pdExitCode = code;
	pdEscape();
	for (;;) { }   // not reached: pdEscape() jumps away
}
