// pd_wad.c: reads Doom's game data (a "WAD") through the Playdate's file API.
//
// The engine asks for a "wad file class" with three jobs: open a file, close it, and read bytes from a given position. The standard class
// (w_file_stdc.c) uses fopen/fseek/fread; this one talks to pd->file directly and never loads the whole WAD into memory: Freedoom is 28 MB,
// and the Playdate has 16 MB. Only the pieces the game asks for are read.
//
// TWO WAYS TO STORE THE DATA
//  1. In PIECES (the built-in Freedoom): tools/split_wad.py cuts the WAD into 1 MB files, "freedoom1.wad.parts/00", "01" ... This is the
//     fast way, and the reason is measured on the device: a seek BACKWARDS in a big file costs about 60 ms there (the file system walks the
//     file again from its start), and Doom loads by jumping around the file, so a 28 MB file made the first start take minutes and the system
//     stopped the app ("run loop stalled for more than 10 seconds"). Inside a 1 MB piece a seek is nearly instant.
//  2. As ONE file: a WAD the user puts in the app's data folder (doom.wad) is used as it is (slow to load, but it works).
// readWad() hides the difference: the engine asks for "length bytes at offset" and gets them either way.
#include "pd_game.h"
#include "w_file.h"
#include "z_zone.h"

#define CHUNK_BYTES (1024 * 1024)   // the size of each piece: must equal CHUNK in tools/split_wad.py
#define MAX_CHUNKS 64               // room for a WAD up to 64 MB (Freedoom 1 is 28 pieces)

typedef struct {
	wad_file_t wad;                 // the engine's part (must be first)
	SDFile* single;                 // the one big file, in single-file mode (otherwise NULL)
	SDFile* piece[MAX_CHUNKS];      // the pieces, opened the first time they are needed (they stay open)
	int piecePos[MAX_CHUNKS];       // where each open piece's read position is now (so a read that continues needs no seek)
	int pieceCount;                 // how many pieces there are (0 in single-file mode)
	char base[96];                  // the path of the pieces' folder, e.g. "freedoom1.wad.parts"
} pd_wad_file_t;

extern wad_file_class_t stdc_wad_file;   // the engine looks for this name

unsigned int pdWadReads, pdWadBytes;   // counters for the timing log

// Timing of the file system, for the device (doom.log): how long the seeks and the reads take, and how many seeks go backwards.
static unsigned int msSeek, msRead, backSeeks, nextExpected;

// Opens piece number n if it is not open yet. Returns NULL if it does not exist.
static SDFile* pieceFile(pd_wad_file_t* w, int n)
{
	if (w->piece[n] == NULL) {
		char name[128];
		snprintf(name, sizeof name, "%s/%02d", w->base, n);
		w->piece[n] = pd->file->open(name, (FileOptions)(kFileRead | kFileReadData));
		w->piecePos[n] = 0;
	}
	return w->piece[n];
}

// Opens the WAD: the pieces if they exist, otherwise the single file (the data folder wins in both cases).
static wad_file_t* openWad(char* path)
{
	pd_wad_file_t* w = Z_Malloc(sizeof(pd_wad_file_t), PU_STATIC, 0);
	memset(w, 0, sizeof *w);
	w->wad.file_class = &stdc_wad_file;
	w->wad.mapped = NULL;

	snprintf(w->base, sizeof w->base, "%s.parts", path);
	int count = 0;
	while (count < MAX_CHUNKS && pieceFile(w, count) != NULL) count++;
	if (count > 0) {
		// the length is every full piece plus the size of the last one
		pd->file->seek(w->piece[count - 1], 0, SEEK_END);
		unsigned int last = (unsigned int)pd->file->tell(w->piece[count - 1]);
		pd->file->seek(w->piece[count - 1], 0, SEEK_SET);
		w->piecePos[count - 1] = 0;
		w->pieceCount = count;
		w->wad.length = (unsigned int)(count - 1) * CHUNK_BYTES + last;
		printf("WAD in %d pieces, %u bytes\n", count, w->wad.length);
		return &w->wad;
	}

	w->single = pd->file->open(path, (FileOptions)(kFileRead | kFileReadData));   // the data folder wins: a WAD you drop there replaces the built-in one
	if (w->single == NULL) { Z_Free(w); return NULL; }
	pd->file->seek(w->single, 0, SEEK_END);
	w->wad.length = (unsigned int)pd->file->tell(w->single);
	pd->file->seek(w->single, 0, SEEK_SET);
	printf("WAD as one file, %u bytes (slow to load: see pd_wad.c)\n", w->wad.length);
	return &w->wad;
}

static void closeWad(wad_file_t* wad)
{
	pd_wad_file_t* w = (pd_wad_file_t*)wad;
	if (w->single != NULL) pd->file->close(w->single);
	for (int i = 0; i < MAX_CHUNKS; i++) if (w->piece[i] != NULL) pd->file->close(w->piece[i]);
	Z_Free(w);
}

// Reads `length` bytes at `offset` from one open file, seeking only if the read position is not already there. Returns how many bytes it got.
static int readFrom(SDFile* file, int* pos, int at, void* buffer, unsigned int length)
{
	unsigned int t0 = pd->system->getCurrentTimeMilliseconds();
	if (*pos != at) {
		if (pd->file->seek(file, at, SEEK_SET) != 0) return -1;
		*pos = at;
	}
	unsigned int t1 = pd->system->getCurrentTimeMilliseconds();
	int got = pd->file->read(file, buffer, length);
	unsigned int t2 = pd->system->getCurrentTimeMilliseconds();
	if (got > 0) *pos = at + got;
	msSeek += t1 - t0; msRead += t2 - t1;
	if (t2 - t0 >= 150)   // one slow call: say exactly which (the position, the size, and how long the seek and the read took)
		printf("SLOW file access at %d, %u bytes: seek %u ms, read %u ms\n", at, length, t1 - t0, t2 - t1);
	return got;
}

static size_t readWad(wad_file_t* wad, unsigned int offset, void* buffer, size_t length)
{
	pd_wad_file_t* w = (pd_wad_file_t*)wad;
	size_t done = 0;

	if (w->single != NULL) {
		static int singlePos = -1;
		int got = readFrom(w->single, &singlePos, (int)offset, buffer, (unsigned int)length);
		done = got < 0 ? 0 : (size_t)got;
	} else {
		// a read may start in one piece and end in the next: take it piece by piece
		while (done < length) {
			unsigned int at = offset + (unsigned int)done;
			int n = (int)(at / CHUNK_BYTES);
			if (n >= w->pieceCount) break;
			unsigned int inPiece = at % CHUNK_BYTES;
			unsigned int want = (unsigned int)(length - done);
			if (want > CHUNK_BYTES - inPiece) want = CHUNK_BYTES - inPiece;
			int got = readFrom(w->piece[n], &w->piecePos[n], (int)inPiece, (char*)buffer + done, want);
			if (got <= 0) break;
			done += (size_t)got;
			if ((unsigned int)got < want) break;
		}
	}

	pdWadReads++; pdWadBytes += (unsigned int)length;
	if (offset < nextExpected) backSeeks++;
	nextExpected = offset + (unsigned int)length;
	if ((pdWadReads % 200) == 0)
		printf("file totals: %u reads, %u KB, seeking %u ms, reading %u ms, %u backward seeks\n", pdWadReads, pdWadBytes / 1024, msSeek, msRead, backSeeks);
	pdMaybeYield();   // loading reads hundreds of lumps: the natural place to pause the engine when its time slice is used up
	return done;
}

wad_file_class_t stdc_wad_file = { openWad, closeWad, readWad };
