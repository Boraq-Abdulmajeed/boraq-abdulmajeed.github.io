// pd_coro.c: see pd_coro.h. Two implementations of the same thing:
//   * on the Playdate (an ARM Cortex-M7): switching stacks takes a few instructions of assembly: save the registers a function must preserve (r4-r11, lr and
//     the floating point registers s16-s31), swap the stack pointer, and restore the other side's registers
//   * in the Simulator (a Mac program): the C library's ucontext functions do the same
#include "pd_game.h"
#include "pd_coro.h"

#define GUARD 0xC0DEC0DEu
#define GUARD_OFFSET 1024    // the guard word sits this far above the bottom of the stack (the Mac's makecontext clears the very start of the buffer, so the first bytes are not a safe place)

static void (*entryFunction)(void);
static unsigned char* stackMemory;
static unsigned int stackSize;
static int reason;
static int inside;

#if TARGET_PLAYDATE
// ------------------------------------------------------------------ the device
static void* mainSp;
static void* coSp;

// Saves the current registers on the current stack, stores the stack pointer in *saveSp, switches to newSp and restores the registers saved there.
// (Naked: the compiler adds no code of its own, so the stack is exactly what the assembly makes it.)
__attribute__((naked, noinline)) static void switchStack(void** saveSp, void* newSp)
{
	__asm volatile(
		"push {r4-r11, lr}\n"
		"vpush {s16-s31}\n"
		"str sp, [r0]\n"
		"mov sp, r1\n"
		"vpop {s16-s31}\n"
		"pop {r4-r11, pc}\n");
}

static void trampoline(void)
{
	entryFunction();
	for (;;) { reason = CORO_DEAD; inside = 0; switchStack(&coSp, mainSp); }   // the entry function never returns; if it did, stay dead
}

int coro_start(void (*entry)(void), unsigned int stackBytes)
{
	entryFunction = entry;
	stackSize = stackBytes & ~7u;
	stackMemory = (unsigned char*)malloc(stackSize);
	if (stackMemory == NULL) return -1;
	*(uint32_t*)(stackMemory + GUARD_OFFSET) = GUARD;
	uint32_t* top = (uint32_t*)(stackMemory + stackSize);        // 8-byte aligned: the stack grows down from here
	uint32_t* sp = top - (16 + 8 + 1);                           // what switchStack will pop: s16-s31, r4-r11, and pc
	for (int i = 0; i < 24; i++) sp[i] = 0;
	sp[24] = (uint32_t)(uintptr_t)trampoline;                    // the first "return" jumps into trampoline (the address already has the Thumb bit set)
	coSp = sp;
	return 0;
}

int coro_resume(void)
{
	inside = 1;
	switchStack(&mainSp, coSp);
	inside = 0;
	return reason;
}

void coro_yield(int why)
{
	reason = why;
	switchStack(&coSp, mainSp);
}

#else
// ------------------------------------------------------------------ the Simulator
#include <ucontext.h>
static ucontext_t mainContext, coContext;

static void trampoline(void)
{
	entryFunction();
	for (;;) { reason = CORO_DEAD; inside = 0; swapcontext(&coContext, &mainContext); }
}

int coro_start(void (*entry)(void), unsigned int stackBytes)
{
	entryFunction = entry;
	stackSize = stackBytes & ~7u;
	stackMemory = (unsigned char*)malloc(stackSize);
	if (stackMemory == NULL) return -1;
	getcontext(&coContext);
	coContext.uc_stack.ss_sp = stackMemory;
	coContext.uc_stack.ss_size = stackSize;
	coContext.uc_link = NULL;
	makecontext(&coContext, trampoline, 0);
	*(uint32_t*)(stackMemory + GUARD_OFFSET) = GUARD;   // after makecontext, which clears the start of the buffer
	return 0;
}

int coro_resume(void)
{
	inside = 1;
	swapcontext(&mainContext, &coContext);
	inside = 0;
	return reason;
}

void coro_yield(int why)
{
	reason = why;
	swapcontext(&coContext, &mainContext);
}
#endif

int coro_inside(void) { return inside; }
int coro_overflowed(void) { return stackMemory != NULL && *(uint32_t*)(stackMemory + GUARD_OFFSET) != GUARD; }
