// pd_game.h: the few things the Playdate layer's files share.
#ifndef PD_GAME_H
#define PD_GAME_H

#include "pd_api.h"

extern PlaydateAPI* pd;           // the Playdate's API, set at start-up (pd_main.c)
extern char pdLastMessage[160];   // the last line the engine printed (shown on the error screen)
extern int pdExitCode;            // (below)
extern void (*pdLineHook)(const char* line);   // if set, every line the engine prints is also passed here (the timing log uses it)            // the code the engine passed to exit()
void pdEscape(void) __attribute__((noreturn));   // stops the engine for good after it "exits" (pd_main.c)
void pdMaybeYield(void);                         // pauses the engine if its time slice is used up (pd_main.c); called at file reads

// input (pd_input.c): the main loop pushes key presses and crank turns in; the engine takes them out each frame
void PDInput_Key(int doomKey, int pressed);
void PDInput_Mouse(int dx);

// settings the main loop and the menu share
extern int pdSolo;                // 1 = one-hand controls (A fire, B use/walk), 0 = classic (D-pad moves)

#endif
