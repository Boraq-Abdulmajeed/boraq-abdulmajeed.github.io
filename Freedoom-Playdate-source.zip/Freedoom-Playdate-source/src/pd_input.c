// pd_input.c: gets the Playdate's buttons and crank into the Doom engine (this file replaces the engine's i_input.c).
//
// The main loop (pd_main.c) decides WHAT a button press means (a key, or a menu action) and calls PDInput_Key / PDInput_Mouse. This file only
// keeps them in a small queue until the engine asks for events, once per frame, in I_GetEvent.
//
// THE CRANK AS A MOUSE: Doom already knows how to turn with a mouse: a "mouse event" carries how far the mouse moved sideways, and the engine
// turns the player by that much (angleturn -= dx * 8). The crank is turned into exactly that: each frame, the degrees the crank moved become
// a mouse movement. Because it is the real mouse path, turning is smooth and analog (a slow turn gives a slow turn, a fast spin a fast one)
// instead of the stiff "turn left/right at a fixed speed" of the keyboard.
#include "pd_game.h"

#include "doomkeys.h"
#include "d_event.h"
#include "doomtype.h"

int vanilla_keyboard_mapping = 1;

#define QUEUE_SIZE 64

typedef struct { uint8_t key; uint8_t pressed; } KeyEvent;
static KeyEvent queue[QUEUE_SIZE];
static int head, tail;
static int pendingMouse;

void PDInput_Key(int doomKey, int pressed)
{
	int next = (tail + 1) % QUEUE_SIZE;
	if (next == head) return;   // full: drop (never happens at one frame's worth of buttons)
	queue[tail].key = (uint8_t)doomKey;
	queue[tail].pressed = (uint8_t)pressed;
	tail = next;
}

void PDInput_Mouse(int dx) { pendingMouse += dx; }

void I_InitInput(void) { head = tail = 0; pendingMouse = 0; }

// Hands everything queued to the engine. Called by the engine once per frame (I_StartTic).
void I_GetEvent(void)
{
	event_t event;
	while (head != tail) {
		KeyEvent k = queue[head];
		head = (head + 1) % QUEUE_SIZE;
		event.type = k.pressed ? ev_keydown : ev_keyup;
		event.data1 = k.key;
		event.data2 = k.pressed ? k.key : 0;   // the typed character: only the save-game name screen cares
		event.data3 = 0;
		D_PostEvent(&event);
	}
	if (pendingMouse != 0) {
		event.type = ev_mouse;
		event.data1 = 0;                // no mouse buttons
		event.data2 = pendingMouse;     // sideways movement: the crank
		event.data3 = 0;
		pendingMouse = 0;
		D_PostEvent(&event);
	}
}
