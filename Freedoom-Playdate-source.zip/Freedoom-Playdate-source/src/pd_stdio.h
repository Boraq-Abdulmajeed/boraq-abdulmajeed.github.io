// pd_stdio.h: makes the unmodified Doom engine run on the Playdate.
//
// WHY THIS FILE EXISTS
// The Doom engine (doomgeneric, GPL) was written for computers: it reads its game data and writes its saves with the C library's
// file functions (fopen, fread ...), and prints messages with printf. The Playdate has no such file system or console: it has its own
// file API (pd->file) and a log (pd->system->logToConsole). Rather than edit hundreds of lines of the engine, this header is
// FORCE-INCLUDED into every source file (the Makefile passes -include pd_stdio.h). It first includes the real system headers, so their
// declarations stay untouched, and only then renames the functions the engine calls, so each call lands in pd_stdio.c instead.
//
// exit() is renamed too: a Playdate app must never really exit, so pd_exit() jumps back to the main loop and shows the engine's error.
#ifndef PD_STDIO_H
#define PD_STDIO_H

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

void pdMaybeYield(void);   // pd_main.c: pauses the engine if its time slice is used up (see the long loading loops in the engine)
FILE* pd_fopen(const char* path, const char* mode);
int pd_fclose(FILE* f);
size_t pd_fread(void* buf, size_t size, size_t count, FILE* f);
size_t pd_fwrite(const void* buf, size_t size, size_t count, FILE* f);
int pd_fseek(FILE* f, long offset, int whence);
long pd_ftell(FILE* f);
int pd_fflush(FILE* f);
int pd_fprintf(FILE* f, const char* fmt, ...);
int pd_vfprintf(FILE* f, const char* fmt, va_list args);
int pd_printf(const char* fmt, ...);
int pd_puts(const char* text);
int pd_fputs(const char* text, FILE* f);
int pd_putchar(int c);
int pd_mkdir_stub(const char* path);
int pd_remove(const char* path);
int pd_rename(const char* from, const char* to);
void pd_exit(int code) __attribute__((noreturn));

#define fopen pd_fopen
#define fclose pd_fclose
#define fread pd_fread
#define fwrite pd_fwrite
#define fseek pd_fseek
#define ftell pd_ftell
#define fflush pd_fflush
#define fprintf pd_fprintf
#define vfprintf pd_vfprintf
#define printf pd_printf
#define puts pd_puts
#define fputs pd_fputs
#define putchar pd_putchar
#define mkdir(path, mode) pd_mkdir_stub(path)
#define remove(path) pd_remove(path)          // (function-like, so that the SDK's struct members named "rename" etc. are not renamed)
#define rename(from, to) pd_rename(from, to)
#define exit(code) pd_exit(code)

#endif
