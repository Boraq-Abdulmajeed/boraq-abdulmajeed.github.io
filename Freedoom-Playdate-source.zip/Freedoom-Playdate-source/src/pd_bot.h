// pd_bot.h: the test bot's interface (see pd_bot.c). Only used when TEST_BOT is 1.
#ifndef PD_BOT_H
#define PD_BOT_H

#include "pd_api.h"

// What the bot wants to do this frame: the buttons it "holds" (in the classic layout: D-pad moves, Ⓐ fires, Ⓑ uses) and how far to turn,
// in mouse counts (the same unit the crank is turned into).
typedef struct { int buttons; int mouse; } BotOut;

void Bot_Think(unsigned now, int inMenu, BotOut* out);
void Bot_Loaded(unsigned loadTimeMs);                   // the engine finished loading, after this many ms
void Bot_FrameDone(unsigned now, unsigned workMs);      // a frame of the running engine was produced (for the frame-rate measurements)

#endif
