// pd_bot.c: a bot that plays DOOM by itself and TESTS how playable the port is. It writes report.txt (pass / warn / fail for each check) in the
// app's data folder. Run it in the Simulator for a quick check, and ON THE REAL PLAYDATE for the numbers that matter (the Simulator is far faster
// than the device, so its frame rate says nothing about the device's). See "the playability report" below for exactly what is checked.
//
// It is compiled only when TEST_BOT is 1 (make TESTDEFS="-DTEST_BOT=1"). It never ships: like the CRANKBLADE demo bot it CHEATS on purpose,
// reading the engine's own data (where the player is, where the monsters are, the level's map) instead of looking at the screen.
//
// What it does, each frame, in order of importance:
//   1. Not in a level (title, menus, the end-of-level screen)? Press Ⓐ every so often, which is "Enter" in Doom's menus. That walks through
//      New Game -> Episode -> Skill (the default, "Hurt me plenty") and past the score screens.
//   2. Dead? Press "use", which restarts the level.
//   3. A monster in plain sight (P_CheckSight, the engine's own line-of-sight test)? Turn toward the nearest one, fire when the aim is close,
//      and strafe from side to side so it is harder to hit.
//   4. Something worth having in plain sight (a key, a weapon, ammunition, health when hurt)? Walk over and pick it up, as a person would.
//   5. Otherwise EXPLORE, as a person does: the bot may only use what has actually been on the screen (see "exploring" below). It walks to the nearest room it
//      has not finished looking at, and heads for the exit once it has SEEN the exit. Only if it runs out of ideas does it "peek" at the whole map for a while,
//      and every peek is counted in the report. The route itself comes from the map: every sector (a room or corridor) is a node, every two-sided line
//      that can be walked through (a small step, a tall enough opening, or a plain door) joins two sectors, and a breadth-first search finds the
//      fewest-rooms path from where the player stands to the room that holds the exit switch. The bot walks to a point on each doorway in turn,
//      presses "use" near doors, and presses "use" on the exit switch when it gets there.
//   6. Stuck against a wall (hardly moved for half a second)? Back up and turn a random amount, then try again.
//
// The crank is not simulated: turning is done by feeding "mouse counts" straight into the engine, which is exactly what the crank does on the
// real device (see pd_input.c), so the turning code is exercised too.
#include "pd_game.h"

#if TEST_BOT

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <limits.h>

#include "doomdef.h"
#include "doomstat.h"
#include "d_player.h"
#include "p_local.h"
#include "r_main.h"
#include "r_state.h"
#include "d_items.h"
#include "pd_bot.h"

// ---------------------------------------------------------------- tuning
#define MOUSE_COUNTS_PER_DEGREE 22.76f   // how many mouse counts turn the player one degree (8192 counts = 360 degrees; see the notes in pd_main.c)
#define TURN_GAIN 0.55f                  // the share of the angle error corrected per frame (less than 1 so the aim settles without overshooting)
#define MAX_TURN_COUNTS 700              // never turn faster than this in one frame
#define FIRE_ANGLE_DEG 3.5f              // fire when the aim is within this many degrees of the monster
#define SIGHT_RANGE (1400 * FRACUNIT)    // ignore monsters farther than this (the pistol is hopeless at long range)
#define PLAYER_HEIGHT (56 * FRACUNIT)    // an opening must be at least this tall to walk through
#define STEP_HEIGHT (24 * FRACUNIT)      // the tallest step the player climbs without a lift
#define STUCK_MS 600                     // hardly moving for this long counts as stuck
#define STUCK_DISTANCE (24 * FRACUNIT)   // "hardly moving" means less than this far in that time
#define COMBAT_GIVE_UP_MS 9000           // fighting one monster this long without killing it means something is wrong (see below)
#define USE_EVERY_MS 650                 // how often "use" is pressed when stuck or at the exit switch
// IMPORTANT (found on the real device, 2026-10-30): in Doom a door that is ALREADY MOVING reverses when "use" is pressed again (opening -> closing,
// closing -> opening). A door needs about 0.8 s to open far enough to walk through, so pressing every 0.65 s kept pushing it shut again: the bot stood in
// front of the door for over two minutes. A person presses once and waits. So at a DOOR the bot waits this long between presses:
#ifndef USE_DOOR_MS
#define USE_DOOR_MS 2500
#endif

// ---------------------------------------------------------------- the log
// Appends one line to bot.log in the app's data folder (the Simulator's Disk/Data/com.braq.doom/).
static SDFile* logFile;
static void botLog(const char* fmt, ...)
{
	char line[240];
	va_list args;
	va_start(args, fmt);
	vsnprintf(line, sizeof line, fmt, args);
	va_end(args);
	if (logFile == NULL) logFile = pd->file->open("bot.log", kFileWrite);
	if (logFile == NULL) return;
	pd->file->write(logFile, line, (unsigned int)strlen(line));
	pd->file->write(logFile, "\n", 1);
	pd->file->flush(logFile);
}

// ---------------------------------------------------------------- the level's map as a graph
typedef struct { int from, to, line; unsigned bannedUntil; int strikes; int walkable, next; } Edge;   // bannedUntil: a doorway that trapped the bot is skipped until this time (ms); strikes: how often it did
#define MAX_EXITS 6
static Edge* edges;
static int numEdges;
static int builtForLevel = -1;   // which run of the level the graph was built for (it is rebuilt when the level restarts)
static int* edgeFirst;           // per sector, its first doorway (then Edge.next): a search then touches each doorway once, which matters at the device's speed
static unsigned char* thinRoom;  // per sector: too narrow for a player to stand in (see buildGraph)
static unsigned char* linePressed;   // per line: a switch that has been tried
static int* parentEdge;          // per sector, the edge the search arrived by (-1 = not reached)
static int* queue;
static int goalSector = -1;
static int goalLine = -1;        // the exit's line
static int frontierTarget = -1; static unsigned frontierUntil; static unsigned* frontierRest;   // the committed frontier; per sector, when it may be tried again
static int exitLines[MAX_EXITS]; static int numExits;   // every exit in the level (the goal becomes the first one the bot has seen)
static unsigned char* visited; static int visitedCount; static unsigned lastNewRoomAt;   // the rooms the player has stood in

// Which key a door needs: 0 blue, 1 yellow, 2 red, -1 none. (Doom has a keycard and a skull key of each colour, and either one opens the door.)
static int doorKey(int special)
{
	if (special == 26 || special == 32) return 0;
	if (special == 27 || special == 34) return 1;
	if (special == 28 || special == 33) return 2;
	return -1;
}

// True for the doors a player opens by pressing "use": DR door (1), blazing DR (117), the open-stay types, and the key doors (which also need the key: see edgeUsable).
static int isPlainDoor(int special)
{
	return special == 1 || special == 31 || special == 117 || special == 118 || doorKey(special) >= 0;
}

// Does the line end the level? 11 and 51 are switches (normal and secret exit), 52 and 124 are lines you walk across.
static int isSwitchExit(int special) { return special == 11 || special == 51; }
static int isWalkExit(int special) { return special == 52 || special == 124; }

// ---------------------------------------------------------------- lifts
// A lift is a block of floor that rests at the height of the upper room. Pressing its face lowers it for about 3 seconds, a person steps on, and it carries them up.
// Seen from below, a raised lift looks like a wall: a 64-unit step. Treating it as one was why the bot could not finish E1M2, where the first lift stands beside the start.
// So the map is read for lifts when a level starts. Each lift sector keeps the two heights it moves between, and the route is planned with those instead of where the floor
// happens to be: you may board at its lowest height and step off at its highest. Only lifts with a "use" line on the doorway itself can be boarded from below, because
// that is the line a person would walk up to and press.
static unsigned char* liftSector;  // per sector: 1 if a lift line moves this sector
static fixed_t* liftLow;           // per sector, for lifts: the lowest height the floor reaches
static fixed_t* liftHigh;          // ...and the height it rests at

static int isLiftSpecial(int sp) { return sp == 10 || sp == 21 || sp == 62 || sp == 88 || sp == 120 || sp == 121 || sp == 122 || sp == 123; }
static int isUseLift(int sp) { return sp == 21 || sp == 62 || sp == 122 || sp == 123; }   // pressed, not walked over

// Finds every sector that a lift line moves, and the two heights of each. It must run before the doorways are worked out. Called once per level start.
static void findLifts(void)
{
	free(liftSector); free(liftLow); free(liftHigh);
	liftSector = (unsigned char*)calloc((size_t)numsectors, 1);
	liftLow = (fixed_t*)calloc((size_t)numsectors, sizeof(fixed_t));
	liftHigh = (fixed_t*)calloc((size_t)numsectors, sizeof(fixed_t));
	for (int i = 0; i < numlines; i++) {
		if (!isLiftSpecial(lines[i].special) || lines[i].tag == 0) continue;
		for (int s = 0; s < numsectors; s++) {
			if (sectors[s].tag != lines[i].tag || liftSector[s]) continue;
			fixed_t low = sectors[s].floorheight;
			for (int j = 0; j < sectors[s].linecount; j++) {               // like the engine, it goes down to the lowest floor beside it
				const line_t* l = sectors[s].lines[j];
				const sector_t* other = (l->frontsector == &sectors[s]) ? l->backsector : l->frontsector;
				if (other != NULL && other->floorheight < low) low = other->floorheight;
			}
			liftSector[s] = 1; liftLow[s] = low; liftHigh[s] = sectors[s].floorheight;
		}
	}
}

// Can the player walk from sector `from` to sector `to` across `line`? A door counts; otherwise the opening must be tall enough and the step small.
// A lift counts at the height that helps: its lowest when boarding by its own "use" line, its highest when stepping off.
static int canCross(const sector_t* from, const sector_t* to, const line_t* line)
{
	if (isPlainDoor(line->special)) return 1;
	fixed_t fromFloor = from->floorheight, toFloor = to->floorheight;
	if (liftSector != NULL) {
		if (liftSector[from - sectors]) fromFloor = liftHigh[from - sectors];
		if (liftSector[to - sectors] && isUseLift(line->special) && line->tag == to->tag) toFloor = liftLow[to - sectors];
	}
	fixed_t top = from->ceilingheight < to->ceilingheight ? from->ceilingheight : to->ceilingheight;
	fixed_t bottom = fromFloor > toFloor ? fromFloor : toFloor;
	if (top - bottom < PLAYER_HEIGHT) return 0;
	if (toFloor - fromFloor > STEP_HEIGHT) return 0;
	return 1;
}

// Is this plain door still too low to walk under? The door is the one of the two sectors whose ceiling is lower; it is open once that gap is player-sized.
static int doorIsClosed(const line_t* l)
{
	const sector_t* a = l->frontsector;
	const sector_t* b = l->backsector;
	const sector_t* door = (a->ceilingheight < b->ceilingheight) ? a : b;
	return door->ceilingheight - door->floorheight < PLAYER_HEIGHT;
}

#define THIN_ROOM (40 * FRACUNIT)
// Builds the sector graph and finds the exit. Called once per level start.
static void buildGraph(void)
{
	free(edges); free(parentEdge); free(queue);
	numExits = 0;
	free(frontierRest); frontierRest = (unsigned*)calloc((size_t)numsectors, sizeof(unsigned)); frontierTarget = -1;
	edges = (Edge*)malloc(sizeof(Edge) * (size_t)numlines * 2);
	parentEdge = (int*)malloc(sizeof(int) * (size_t)numsectors);
	queue = (int*)malloc(sizeof(int) * (size_t)numsectors);
	free(edgeFirst); edgeFirst = (int*)malloc(sizeof(int) * (size_t)numsectors);
	for (int i = 0; i < numsectors; i++) edgeFirst[i] = -1;
	free(thinRoom); thinRoom = (unsigned char*)calloc((size_t)numsectors, 1);
	free(linePressed); linePressed = (unsigned char*)calloc((size_t)numlines, 1);
	numEdges = 0;
	goalSector = goalLine = -1;
	findLifts();
	for (int i = 0; i < numlines; i++) {
		line_t* l = &lines[i];
		if ((isSwitchExit(l->special) || isWalkExit(l->special)) && numExits < MAX_EXITS) {
			exitLines[numExits++] = i;
			if (goalLine < 0) { goalLine = i; goalSector = (int)(l->frontsector - sectors); }
		}
		if (!(l->flags & ML_TWOSIDED) || l->backsector == NULL || l->frontsector == l->backsector) continue;
		int f = (int)(l->frontsector - sectors), b = (int)(l->backsector - sectors);
		for (int dir = 0; dir < 2; dir++) {                     // one edge for each way across
			Edge* e = &edges[numEdges];
			e->from = dir ? b : f; e->to = dir ? f : b; e->line = i; e->bannedUntil = 0; e->strikes = 0;
			e->walkable = canCross(&sectors[e->from], &sectors[e->to], l);
			e->next = edgeFirst[e->from]; edgeFirst[e->from] = numEdges;
			numEdges++;
		}
	}
	// the size of each room, from the corners of its walls. A player is 32 units wide, so a sector thinner than THIN_ROOM cannot be stood in: it is wall trim or a light strip
	for (int i = 0; i < numsectors; i++) {
		fixed_t x0 = INT_MAX, x1 = INT_MIN, y0 = INT_MAX, y1 = INT_MIN;
		for (int j = 0; j < sectors[i].linecount; j++) {
			const line_t* l = sectors[i].lines[j];
			const vertex_t* v[2] = { l->v1, l->v2 };
			for (int k = 0; k < 2; k++) {
				if (v[k]->x < x0) x0 = v[k]->x;
				if (v[k]->x > x1) x1 = v[k]->x;
				if (v[k]->y < y0) y0 = v[k]->y;
				if (v[k]->y > y1) y1 = v[k]->y;
			}
		}
		thinRoom[i] = (x1 - x0 < THIN_ROOM) || (y1 - y0 < THIN_ROOM);
	}
	botLog("map %d-%d: %d sectors, %d lines, %d walkable doorways; exit switch %s (line %d, sector %d)", gameepisode, gamemap, numsectors, numlines, numEdges,
		goalLine >= 0 ? "found" : "NOT FOUND", goalLine, goalSector);
}

// Floors and ceilings move (a lift comes down, a switch lowers a wall), so which doorways can be walked is worked out again every few seconds.
static void refreshEdges(void)
{
	for (int e = 0; e < numEdges; e++)
		edges[e].walkable = canCross(&sectors[edges[e].from], &sectors[edges[e].to], &lines[edges[e].line]);
}

// ---------------------------------------------------------------- exploring
// A bot that knows the whole map proves that a level CAN be finished, not that a person could find the way. So by default this bot only uses what has been on the
// screen. The engine already records that: when the renderer draws a wall it sets ML_MAPPED on the line (that is how the automap fills in), so "has the player seen
// this?" is one flag, and it cannot be fooled, because it is set by the real drawing code.
//
//   a doorway is KNOWN       if its line has been seen. (Doom never draws a line with the same floor, ceiling, textures and light on both sides, so such a line can
//                            never be flagged: it counts as known once the player stands in a room it belongs to.)
//   a room is a FRONTIER     if nobody has stood in it AND some of its walls have not been seen: there is something left to look at there.
//   the exit is KNOWN        if its line has been seen.
//
// The bot picks the nearest frontier (fewest rooms away) and COMMITS to it until it is reached, it is no longer a frontier, or FRONTIER_MS has passed (then that room is
// left alone for a while). Without the commitment the bot paced between two rooms for 45 s in the first test: from room A the nearest frontier lay through B, and from B
// the nearest one lay through A. It travels through known doorways only, until it has seen the exit, then goes there. If there is no frontier left, or
// it finds no new room for EXPLORE_STALL_MS, it PEEKS: for PEEK_MS it uses the whole map. Every peek goes in the report, because a level finished without one is the
// claim worth making. Build with -DBOT_EXPLORE=0 for the old all-knowing bot.
#ifndef BOT_EXPLORE
#define BOT_EXPLORE 1
#endif
#define EXPLORE_STALL_MS 45000
#define PEEK_MS 20000
#define FRONTIER_MS 15000           // give up on reaching one frontier after this long
#define FRONTIER_REST_MS 60000      // ...and leave it alone for this long
#define ROUTE_EVERY_MS 500          // the search runs this often (and whenever the room changes): on the device every millisecond of the frame counts
static unsigned peekUntil, peekEndedAt;
static int lvPeeks, lvItems; static unsigned lvExitSeenAt; static int totalItems, totalPeeks;
static const char* navMode = "";   // what the route is for, for the log
static unsigned lastThinkAt;       // the time of this frame, for checks deep inside the search
static int searchFound = -1;       // the room the last search ended at

// Can this doorway be used right now? (Not if it is banned, or it is a key door and the player has neither key of that colour.)
static int edgeUsable(const Edge* e, unsigned now, const player_t* pl)
{
	if (!e->walkable || e->bannedUntil > now) return 0;
	int key = doorKey(lines[e->line].special);
	return key < 0 || pl->cards[key] || pl->cards[key + 3];
}

// True for a line the renderer skips, so it can never be flagged as seen (see r_bsp.c, "Reject empty lines"). These are invisible triggers in the middle of a floor.
static int isEmptyLine(const line_t* l)
{
	const sector_t* f = l->frontsector; const sector_t* b = l->backsector;
	return b != NULL && f->floorheight == b->floorheight && f->ceilingheight == b->ceilingheight && f->floorpic == b->floorpic && f->ceilingpic == b->ceilingpic
		&& f->lightlevel == b->lightlevel && sides[l->sidenum[0]].midtexture == 0;
}

static int edgeKnown(const Edge* e)
{
	const line_t* l = &lines[e->line];
	return (l->flags & ML_MAPPED) || (isEmptyLine(l) && visited != NULL && visited[e->from]);
}

// Is there still something to look at in this room? (Nobody has stood in it, and part of its outline has not been seen.)
static int isFrontier(int s)
{
	if (visited == NULL || visited[s]) return 0;
	if (frontierRest != NULL && frontierRest[s] > lastThinkAt) return 0;
	const sector_t* sec = &sectors[s];
	if (thinRoom[s] && sec->ceilingheight - sec->floorheight >= PLAYER_HEIGHT) return 0;   // trim nobody can stand in. (A closed door is thin too, but it must stay a target: the room behind it can only be found by opening it.)
	for (int i = 0; i < sec->linecount; i++) {
		const line_t* l = sec->lines[i];
		if (!(l->flags & ML_MAPPED) && !isEmptyLine(l)) return 1;
	}
	return 0;
}

// A wall switch that does something other than end the level (S1 = works once, SR = again and again; the numbers are Doom's line types). A person presses every switch they find.
static int isSwitch(int sp)
{
	static const unsigned char list[] = { 7,9,18,20,21,23,29,41,42,43,45,49,50,55,60,61,62,63,64,65,66,67,68,69,70,71,99,101,102,103,111,112,113,114,115,116,122,123,127,131,132,133,134,135,136,137,138,139,140 };
	for (size_t i = 0; i < sizeof list; i++) if (list[i] == sp) return 1;
	return 0;
}

// The first untried switch in this room, or -1. knownOnly: only one the player has seen.
static int switchInRoom(int s, int knownOnly)
{
	const sector_t* sec = &sectors[s];
	for (int i = 0; i < sec->linecount; i++) {
		const line_t* l = sec->lines[i];
		int n = (int)(l - lines);
		if (isSwitch(l->special) && !linePressed[n] && l->frontsector == sec && (!knownOnly || (l->flags & ML_MAPPED))) return n;
	}
	return -1;
}

// Breadth-first search from the player's sector, over every doorway (knownOnly 0) or the seen ones only (knownOnly 1), to the goal (wantFrontier 0), to the nearest
// frontier (wantFrontier 1) or to the nearest room with an untried switch (wantFrontier 2, which can be the room the player is in). Fills parentEdge[]; returns the first edge to take, or -1 if there is no way.
static int searchRoute(int start, unsigned now, const player_t* pl, int knownOnly, int wantFrontier)
{
	searchFound = -1;
	if (!wantFrontier && goalSector < 0) return -1;
	for (int i = 0; i < numsectors; i++) parentEdge[i] = -1;
	int head = 0, tail = 0, found = -1;
	queue[tail++] = start;
	parentEdge[start] = -2;   // the start itself
	while (head < tail) {
		int s = queue[head++];
		if (wantFrontier == 2 ? (switchInRoom(s, knownOnly) >= 0) : wantFrontier ? (s != start && isFrontier(s)) : (s == goalSector)) { found = s; break; }
		for (int e = edgeFirst[s]; e >= 0; e = edges[e].next) {
			if (parentEdge[edges[e].to] != -1 || !edgeUsable(&edges[e], now, pl)) continue;
			if (knownOnly && !edgeKnown(&edges[e])) continue;
			parentEdge[edges[e].to] = e;
			queue[tail++] = edges[e].to;
		}
	}
	searchFound = found;
	if (found < 0 || found == start) return -1;   // (searchFound still says so when a switch is in this very room)
	// walk back from the goal to find the first step
	int s = found, first = -1;
	while (s != start) { first = parentEdge[s]; s = edges[first].from; }
	return first;
}

// The route to one given room, over seen doorways only. (searchRoute's goal mode, aimed at the committed frontier: the goal is put back afterwards.)
static int routeToRoom(int start, int room, unsigned now, const player_t* pl)
{
	int saved = goalSector;
	goalSector = room;
	int e = searchRoute(start, now, pl, 1, 0);
	goalSector = saved;
	return e;
}

// Makes the first exit the player has seen the goal. A walk-across exit is often an invisible line, so it counts as seen once the player has stood next to it.
static int exitIsKnown(unsigned now)
{
	for (int i = 0; i < numExits; i++) {
		const line_t* l = &lines[exitLines[i]];
		int seen = (l->flags & ML_MAPPED) != 0;
		if (!seen && isWalkExit(l->special) && visited != NULL)
			seen = visited[l->frontsector - sectors] || (l->backsector != NULL && visited[l->backsector - sectors]);
		if (seen) {
			goalLine = exitLines[i]; goalSector = (int)(l->frontsector - sectors);
			if (!lvExitSeenAt) { lvExitSeenAt = now; botLog("[%6u ms] the exit has been SEEN (line %d, sector %d), %d rooms in, %d map peeks", now, goalLine, goalSector, visitedCount, lvPeeks); }
			return 1;
		}
	}
	return 0;
}

static void startPeek(unsigned now, const char* why)
{
	peekUntil = now + PEEK_MS; lvPeeks++; totalPeeks++;
	botLog("[%6u ms] PEEK %d at the full map: %s (%d rooms seen)", now, lvPeeks, why, visitedCount);
}

// Starts or continues the walk to the nearest untried switch. Returns 1 if there is one, and sets *e to the doorway to take (-1 = it is in this room).
#define SWITCH_MS 15000
static int pressTarget = -1; static unsigned pressUntil;
static int lvSwitches;
static int headForSwitch(int start, unsigned now, const player_t* pl, int knownOnly, int* e)
{
	if (pressTarget >= 0 && now >= pressUntil) { botLog("[%6u ms] could not reach the switch on line %d", now, pressTarget); linePressed[pressTarget] = 1; pressTarget = -1; }
	if (pressTarget < 0) {
		searchRoute(start, now, pl, knownOnly, 2);
		if (searchFound < 0) return 0;
		pressTarget = switchInRoom(searchFound, knownOnly);
		pressUntil = now + SWITCH_MS;
		botLog("[%6u ms] going to press the switch on line %d (special %d) in room %d", now, pressTarget, lines[pressTarget].special, searchFound);
	}
	int room = (int)(lines[pressTarget].frontsector - sectors);
	*e = -1;
	if (room != start) {
		int saved = goalSector;
		goalSector = room; *e = searchRoute(start, now, pl, knownOnly, 0); goalSector = saved;
		if (*e < 0) { linePressed[pressTarget] = 1; pressTarget = -1; return 0; }
	}
	navMode = "to a switch";
	return 1;
}

// The doorway to head for next. Sets navMode. Returns -1 if there is nothing to do but look around.
static int chooseRoute(int start, unsigned now, const player_t* pl)
{
#if BOT_EXPLORE
	if (now >= peekUntil) {
		if (peekUntil) { peekEndedAt = now; peekUntil = 0; }
		int e;
		if (pressTarget >= 0 && headForSwitch(start, now, pl, 1, &e)) return e;   // finish what was started
		if (exitIsKnown(now)) {
			if (start == goalSector) { navMode = "at the exit"; return -1; }
			e = searchRoute(start, now, pl, 1, 0);
			if (e >= 0) { navMode = "to the exit"; return e; }
		}
		lastThinkAt = now;
		// stay with the committed frontier while it is still worth reaching
		e = -1;
		if (frontierTarget >= 0 && isFrontier(frontierTarget)) {
			if (now >= frontierUntil) { frontierRest[frontierTarget] = now + FRONTIER_REST_MS; botLog("[%6u ms] giving up on reaching room %d for now", now, frontierTarget); }
			else e = routeToRoom(start, frontierTarget, now, pl);
		}
		if (e < 0) {
			e = searchRoute(start, now, pl, 1, 1);
			frontierTarget = e >= 0 ? searchFound : -1;
			frontierUntil = now + FRONTIER_MS;
		}
		unsigned sinceProgress = now - (lastNewRoomAt > peekEndedAt ? lastNewRoomAt : peekEndedAt);
		if (e >= 0 && sinceProgress < EXPLORE_STALL_MS) { navMode = "exploring"; return e; }
		int se;
		if (headForSwitch(start, now, pl, 1, &se)) return se;                     // nothing left to walk to: try the switches that have been seen
		startPeek(now, e >= 0 ? "no new room for a long time" : "nothing left to explore");
	}
	navMode = "peeking";
#else
	navMode = "all-knowing";
#endif
	int e = searchRoute(start, now, pl, 0, 0);
	if (e < 0 && start != goalSector) {   // nothing reachable: forgive all the banned doorways and look again
		for (int i = 0; i < numEdges; i++) edges[i].bannedUntil = 0;
		e = searchRoute(start, now, pl, 0, 0);
	}
	if (e < 0 && start != goalSector) {   // even the whole map shows no way: the way must be opened by a switch somewhere
		int se;
		if (headForSwitch(start, now, pl, 0, &se)) return se;
	}
	return e;
}

// A doorway did not work: skip it for a while, longer each time, so one bad doorway cannot hold the bot for long.
static void banEdge(int e, unsigned now, unsigned baseMs)
{
	int n = edges[e].strikes < 5 ? edges[e].strikes : 5;
	edges[e].bannedUntil = now + (baseMs << n);
	edges[e].strikes++;
}

// ---------------------------------------------------------------- picking things up
// A person sees a key, or a shotgun, and goes for it. This is also what makes key doors work: nothing in the route tells the bot to fetch a key. Items are looked for a
// few times a second; pointers to items are only ever COMPARED, never read, once the scan is over (an item that was picked up no longer exists).
#define ITEM_SCAN_MS 250
#define ITEM_RANGE (500 * FRACUNIT)     // walk this far for an ordinary item...
#define KEY_RANGE (1500 * FRACUNIT)     // ...and much further for a key
#define ITEM_GIVE_UP_MS 5000            // an item not reached in this time is out of reach (on a ledge, behind glass): forget it
#define SKIPPED_ITEMS 24
static const mobj_t* itemTarget; static fixed_t itemX, itemY; static unsigned itemSince, itemScanAt;
static const mobj_t* skippedItems[SKIPPED_ITEMS]; static int skippedNext;

static int isKeyItem(const mobj_t* m) { return m->type >= MT_MISC4 && m->type <= MT_MISC9; }

// Would a sensible player bother? Health and armor are left alone when not needed (the game would refuse to pick them up anyway).
static int wantsItem(const mobj_t* m, const player_t* pl)
{
	for (int i = 0; i < SKIPPED_ITEMS; i++) if (skippedItems[i] == m) return 0;
	if (m->type == MT_MISC2 || m->type == MT_MISC10 || m->type == MT_MISC11) return pl->health < 100;
	if (m->type == MT_MISC0 || m->type == MT_MISC1) return pl->armorpoints < 100;
	return 1;
}

// Looks for the nearest wanted item in view. Sets itemTarget / itemX / itemY (itemTarget NULL = none).
static void scanForItems(mobj_t* me, const player_t* pl, unsigned now, int fovDeg)
{
	const mobj_t* best = NULL; fixed_t bestDist = KEY_RANGE;
	for (thinker_t* th = thinkercap.next; th != &thinkercap; th = th->next) {
		if (th->function.acp1 != (actionf_p1)P_MobjThinker) continue;
		mobj_t* m = (mobj_t*)th;
		if (!(m->flags & MF_SPECIAL) || !wantsItem(m, pl)) continue;
		fixed_t d = P_AproxDistance(m->x - me->x, m->y - me->y);
		if (d >= bestDist || (d > ITEM_RANGE && !isKeyItem(m))) continue;
		float off = (float)(me->angle >> 16) - (float)(R_PointToAngle2(me->x, me->y, m->x, m->y) >> 16);
		off = fabsf(off) * 360.0f / 65536.0f; if (off > 180.0f) off = 360.0f - off;
		if (off > (float)fovDeg * 0.5f || !P_CheckSight(me, m)) continue;
		best = m; bestDist = d; itemX = m->x; itemY = m->y;
	}
	if (best != itemTarget) { itemTarget = best; itemSince = now; }
}

// ---------------------------------------------------------------- small helpers
// Degrees between two angles, positive when `target` is to the left of `cur` (Doom's angles grow counter-clockwise).
static float angleErrorDeg(angle_t target, angle_t cur)
{
	return (float)((int32_t)(target - cur)) * (360.0f / 4294967296.0f);
}

// Mouse counts to turn by `errDeg` (positive = turn left). In Doom a positive mouse movement turns RIGHT, hence the minus sign.
static int countsToTurn(float errDeg)
{
	float c = -errDeg * MOUSE_COUNTS_PER_DEGREE * TURN_GAIN;
	if (c > MAX_TURN_COUNTS) c = MAX_TURN_COUNTS;
	if (c < -MAX_TURN_COUNTS) c = -MAX_TURN_COUNTS;
	return (int)c;
}

// ---------------------------------------------------------------- the player's personality
// What makes a bot feel human is mostly what it gets WRONG. Each personality sets how late it reacts, how wide its field of view is, how far off its
// aim is (the error grows with distance), how it fires (short bursts, with pauses), and when it backs off to survive.
//   rookie    slow to react, shaky aim, short bursts, runs away early
//   veteran   decent reactions, steady aim
//   fanatic   fast reactions, tight aim, long bursts, stands and fights
typedef struct {
	const char* name;
	unsigned reactMs;      // a monster must have been in view this long before the bot reacts (it freezes for a moment, "startled")
	float aimSigmaDeg;     // typical aiming error in degrees at close range (it grows with distance)
	float fireAngleDeg;    // fires when the believed aim is within this many degrees
	int burstShots;        // shots per burst
	unsigned pauseMs;      // the pause between bursts
	int retreatHealth;     // below this health the bot backs away from a fight (still firing)
	float fovDeg;          // how wide it sees (monsters outside are not noticed)
} Personality;
static const Personality PERSONALITIES[] = {
	{ "rookie",  450, 6.0f, 6.0f, 2, 520, 45, 70.0f },
	{ "veteran", 280, 3.0f, 4.5f, 4, 260, 35, 85.0f },
	{ "fanatic", 170, 1.6f, 3.5f, 9, 110, 28, 95.0f },
};
#ifndef BOT_PERSONALITY
#define BOT_PERSONALITY 2                 // 0 rookie, 1 veteran, 2 fanatic (make TESTDEFS="-DTEST_BOT=1 -DBOT_PERSONALITY=0")
#endif
#define ME (PERSONALITIES[BOT_PERSONALITY])
// the "human" parts of fighting
static unsigned seenSince;                // when the current target first came into view
static float aimNoiseDeg; static unsigned aimNoiseAt;   // the current aiming error, and when it was last re-rolled
static int burstShotsFired; static unsigned burstPauseUntil; static int lastAmmoSeen = -1;
static int shotsFiredTotal, burstsTotal;

// A bell-shaped random number (the sum of several uniform ones): most values near zero, a few far away, like a human's errors.
static float gauss(void)
{
	float sum = 0.0f;
	for (int i = 0; i < 6; i++) sum += (float)(rand() % 10001) / 10000.0f;
	return (sum - 3.0f) / 0.7071f;        // mean 0, standard deviation about 1
}

// Finds the nearest living monster the player can see; returns NULL if there is none.
static mobj_t* nearestVisibleMonster(mobj_t* me)
{
	mobj_t* best = NULL;
	fixed_t bestDist = SIGHT_RANGE;
	for (thinker_t* th = thinkercap.next; th != &thinkercap; th = th->next) {
		if (th->function.acp1 != (actionf_p1)P_MobjThinker) continue;   // not a map object
		mobj_t* m = (mobj_t*)th;
		if (m == me || !(m->flags & MF_COUNTKILL) || !(m->flags & MF_SHOOTABLE) || m->health <= 0) continue;
		fixed_t d = P_AproxDistance(m->x - me->x, m->y - me->y);
		if (d >= bestDist || !P_CheckSight(me, m)) continue;
		if (fabsf(angleErrorDeg(R_PointToAngle2(me->x, me->y, m->x, m->y), me->angle)) > ME.fovDeg * 0.5f) continue;   // outside the field of view: not noticed
		best = m;
		bestDist = d;
	}
	return best;
}

// ---------------------------------------------------------------- the playability report
//
// WHAT IS CHECKED (each becomes a PASS, WARN or FAIL line in report.txt):
//   boot        the engine finished loading, and how long that took
//   menus       the bot got from the title through New Game into a level, and how long that took
//   controls    four probes at the start of the first level, using the same input paths the real controls use:
//                 turn right  2048 mouse counts must turn the view about 90 degrees to the right (the crank's own mechanism)
//                 turn left   the same, to the left
//                 walk        holding "up" for one second must move the player a good distance
//                 fire        holding Ⓐ must use up ammunition
//   frame rate  frames per second while in a level: the average, the slowest 3-second window, and the worst "hitches" (long gaps between frames)
//   levels      each level the bot was asked to play: finished (reached the score screen) or not, how long, kills, deaths, times stuck
//   stability   deaths, stuck events and stretches with no progress (a long time without reaching a new room)
//
// WHAT IT CANNOT CHECK: the crank itself (the Simulator has no crank, and the bot feeds mouse counts, which is what the crank is turned into),
// the sound, how the picture looks, or a watchdog stop (the system kills the app: look for it in the Playdate's errorlog.txt after a run).
// The bot also CHEATS (it reads the engine's data to aim and to find the exit), so "finished the level" proves the level can be finished and the
// controls work, not that a person would find the way.
#ifndef BOT_LEVELS
#define BOT_LEVELS 1                      // how many levels to play before the run ends (make TESTDEFS="-DTEST_BOT=1 -DBOT_LEVELS=1" to change it)
#endif
// (BOT_LEVELS is 1 because from E1M2 on the way forward needs things this bot cannot work out yet, such as lifts: it wanders until the time runs out, which says nothing about the port.)
#define LEVEL_TIMEOUT_MS (12 * 60 * 1000) // a level not finished in this time counts as failed (exploring takes much longer than walking straight to the exit)
#define MAX_LEVEL_DEATHS 8                // dying this many times on one level counts as failed
#define NO_PROGRESS_WARN_MS (60 * 1000)   // no new room for this long: WARN
#define NO_PROGRESS_FAIL_MS (150 * 1000)  // ...for this long: FAIL (a softlock, or the bot is stuck for good)
#define PROBE_TURN_COUNTS 2048            // 2048 of the 8192 counts of a full circle = 90 degrees
#define REPORT_EVERY_MS 60000             // the report is rewritten every minute, so a run cut short still leaves one

extern boolean menuactive;

#if TARGET_SIMULATOR
#define BUILD_NAME "Simulator"
#else
#define BUILD_NAME "Playdate device"
#endif

// ---- measurements
static unsigned loadMs;  static int loaded;            // how long the engine took to load
static unsigned firstThinkAt;                          // when the bot first ran (the title screen)
static unsigned menuMs;  static int menuDone;          // from the first menu frame until a level began
static unsigned runStartAt;                            // when the run began (first level frame)
static int finished;                                   // the run is over (the report says why)
static const char* finishReason = "running";

// frame timing, counted only while a level is on screen (menus and score screens are cheap and would flatter the numbers)
static unsigned lvFrames, lvWallMs, lvWorkMs, worstGap, gaps100, gaps250, gaps1000;
static unsigned lastFrameNow; static int lastFrameInLevel;
static unsigned winStart, winFrames; static float minWinFps = 1000.0f; static int windows;

// control probes
enum { PR_WAIT, PR_RIGHT, PR_LEFT, PR_WALK, PR_FIRE, PR_DONE };
static int probeStep = PR_WAIT;
static int probeSent, probeStartTic;
static angle_t probeAngle; static fixed_t probeX, probeY; static int probeAmmo;
static float turnedRight, turnedLeft, walkedUnits; static int ammoUsed = -999;   // -999 = not measured yet

// levels
typedef struct { int ep, map, completed; unsigned ms; int kills, total, deaths, stuck; const char* why; int peeks, items, rooms; unsigned exitSeenMs; } LevelResult;
static LevelResult results[BOT_LEVELS + 2];
static int numResults;
static int curMapKey = -1; static unsigned curMapSince;
static int lvDeaths, lvStuck, lvNoRoute;               // for the level being played
static int lastTotalKills, lastKillsNow;
static int totalDeaths, totalStuck, noProgressWarns, noProgressFails;
static unsigned lastFullReportAt;

static int leaveWait, leavePassed, lastMapDone; static unsigned leaveSince;
// ---- the report text
static char rep[5000];
static int repLen, nPass, nWarn, nFail;

static void repAdd(const char* fmt, ...)
{
	if (repLen >= (int)sizeof rep - 200) return;
	va_list args;
	va_start(args, fmt);
	repLen += vsnprintf(rep + repLen, sizeof rep - (size_t)repLen, fmt, args);
	va_end(args);
}

// One check line: the status counts toward the verdict.
static void repCheck(const char* status, const char* name, const char* fmt, ...)
{
	char detail[200];
	va_list args;
	va_start(args, fmt);
	vsnprintf(detail, sizeof detail, fmt, args);
	va_end(args);
	if (status[0] == 'P') nPass++; else if (status[0] == 'W') nWarn++; else nFail++;
	repAdd(" %-4s  %-11s %s\n", status, name, detail);
}

// PASS / WARN / FAIL for a number where bigger is better.
static const char* rateHigh(float v, float passAt, float warnAt) { return v >= passAt ? "PASS" : (v >= warnAt ? "WARN" : "FAIL"); }
// ...and where smaller is better.
static const char* rateLow(float v, float passAt, float warnAt) { return v <= passAt ? "PASS" : (v <= warnAt ? "WARN" : "FAIL"); }

// Builds the whole report from what has been measured so far and writes it to report.txt (replacing the old one).
static void writeReport(unsigned now, const char* reason)
{
	repLen = 0; nPass = nWarn = nFail = 0;
	rep[0] = '\0';
	unsigned runSec = runStartAt ? (now - runStartAt) / 1000 : 0;
	repAdd("DOOM PLAYABILITY REPORT\n build: %s    run time: %um%02us    status: %s\n player: %s (reacts after %u ms, aim error %.1f deg, bursts of %d)\n\n",
		BUILD_NAME, runSec / 60, runSec % 60, reason, ME.name, ME.reactMs, ME.aimSigmaDeg, ME.burstShots);

	// boot and menus
	if (loaded) repCheck(rateLow((float)loadMs / 1000.0f, 15.0f, 30.0f), "boot", "engine loaded in %.1f s", (float)loadMs / 1000.0f);
	else repCheck("FAIL", "boot", "the engine had not finished loading");
	if (menuDone) repCheck(rateLow((float)menuMs / 1000.0f, 25.0f, 60.0f), "menus", "title -> New Game -> in a level after %.1f s", (float)menuMs / 1000.0f);
	else repCheck("FAIL", "menus", "never reached a level (stuck in the menus)");

	// controls
	if (probeStep == PR_DONE || turnedRight != 0.0f) {
		float e = 90.0f;
		repCheck((turnedRight > e * 0.8f && turnedRight < e * 1.2f) ? "PASS" : "FAIL", "turn right", "%d counts turned %.1f deg to the right (expected %.0f +-20%%)", PROBE_TURN_COUNTS, turnedRight, e);
		repCheck((turnedLeft > e * 0.8f && turnedLeft < e * 1.2f) ? "PASS" : "FAIL", "turn left", "%d counts turned %.1f deg to the left (expected %.0f +-20%%)", PROBE_TURN_COUNTS, turnedLeft, e);
		repCheck(walkedUnits >= 100.0f ? "PASS" : (walkedUnits >= 20.0f ? "WARN" : "FAIL"), "walk", "1 s of 'up' moved the player %.0f units (a wall in the way would also show here)", walkedUnits);
		repCheck(ammoUsed >= 1 ? "PASS" : "FAIL", "fire", ammoUsed >= 1 ? "Ⓐ fired: %d ammo used" : "Ⓐ did not use any ammo (%d)", ammoUsed);
	} else {
		repCheck("WARN", "controls", "the control probes did not run yet");
	}

	// frame rate
	if (lvFrames > 30 && lvWallMs > 0) {
		float avg = 1000.0f * (float)lvFrames / (float)lvWallMs;
		repCheck(rateHigh(avg, 15.0f, 10.0f), "frame rate", "%.1f fps on average in levels (%u frames); slowest 3 s window %.1f fps; CPU %.1f ms of work per frame",
			avg, lvFrames, windows ? minWinFps : avg, (float)lvWorkMs / (float)lvFrames);
		repCheck(worstGap < 500 ? "PASS" : (worstGap < 1500 ? "WARN" : "FAIL"), "hitches", "worst gap between frames %u ms; %u gaps over 100 ms, %u over 250 ms, %u over 1 s", worstGap, gaps100, gaps250, gaps1000);
	} else {
		repCheck("WARN", "frame rate", "not enough frames in a level to measure (%u)", lvFrames);
	}

	// levels
	for (int i = 0; i < numResults; i++) {
		LevelResult* r = &results[i];
		repCheck(r->completed ? "PASS" : "FAIL", "level", "E%dM%d %s in %um%02us: kills %d/%d, deaths %d, stuck %d%s%s", r->ep, r->map, r->completed ? "FINISHED" : "NOT finished",
			r->ms / 60000, (r->ms / 1000) % 60, r->kills, r->total, r->deaths, r->stuck, r->why ? " -- " : "", r->why ? r->why : "");
	}
	if (numResults == 0) repCheck("WARN", "level", "no level has ended yet");

	if (leaveWait) repCheck(leavePassed ? "PASS" : (finished ? "FAIL" : "WARN"), "score scr.", leavePassed ? "Ⓐ closed the score screen and the next level loaded" : "the score screen has not closed yet");

	// exploring: did the bot find its own way, using only what had been on the screen?
#if BOT_EXPLORE
	for (int i = 0; i < numResults; i++) {
		LevelResult* r = &results[i];
		if (!r->completed) continue;
		repCheck(r->peeks == 0 ? "PASS" : "WARN", "exploring", "E%dM%d %s: %d rooms visited, %d items picked up, %d peeks at the full map", r->ep, r->map,
			r->peeks == 0 ? "found its own way out" : "needed help", r->rooms, r->items, r->peeks);
	}
#else
	repAdd(" info  %-11s off: this run knew the whole map from the start\n", "exploring");
#endif

	// stability
	// Getting stuck says how well the BOT walks, not whether the game can be played, so this can only ever warn. It is measured per minute, because a long run bumps into more things.
	{
		float minutes = (float)(now - runStartAt) / 60000.0f;
		float perMinute = minutes > 0.5f ? (float)totalStuck / minutes : 0.0f;
		repCheck(perMinute <= 12.0f ? "PASS" : "WARN", "stuck", "%d times the bot got stuck against something and backed out (%.0f a minute)", totalStuck, (double)perMinute);
	}
	repCheck(noProgressFails ? "FAIL" : (noProgressWarns ? "WARN" : "PASS"), "progress", "%d stretches over %d s without reaching a new room, %d over %d s",
		noProgressWarns, NO_PROGRESS_WARN_MS / 1000, noProgressFails, NO_PROGRESS_FAIL_MS / 1000);
	repCheck(totalDeaths <= 3 * BOT_LEVELS ? "PASS" : "WARN", "deaths", "%d deaths in total", totalDeaths);
	repAdd(" info  %-11s %d shots fired in %d bursts (a person-like player: it reacts late, aims with some error and pauses between bursts)\n", "fighting", shotsFiredTotal, burstsTotal);

	const char* verdict = nFail ? "NOT PLAYABLE (a check failed)" : (nWarn ? "PLAYABLE, with warnings" : "PLAYABLE");
	repAdd("\n RESULT: %s   (%d pass, %d warn, %d fail)\n", verdict, nPass, nWarn, nFail);
	if (!finished) repAdd(" (the run is still going: this is a snapshot)\n");
	repAdd("\n Not checked: the crank itself, sound, how the picture looks, a watchdog stop (see the Playdate's errorlog.txt).\n");

	SDFile* f = pd->file->open("report.txt", kFileWrite);
	if (f != NULL) { pd->file->write(f, rep, (unsigned int)strlen(rep)); pd->file->close(f); }
	botLog("[%6u ms] report written: %s", now, verdict);
	lastFullReportAt = now;
}

// Ends the run: the report is written once more and the bot stops pressing anything.
static void finishRun(unsigned now, const char* reason)
{
	finished = 1;
	finishReason = reason;
	writeReport(now, reason);
}

// ---- hooks called from pd_main.c
void Bot_Loaded(unsigned loadTimeMs) { loadMs = loadTimeMs; loaded = 1; }

// Called after every frame of the running engine. `workMs` is how long the engine took to produce it.
void Bot_FrameDone(unsigned now, unsigned workMs)
{
	int inLevel = (gamestate == GS_LEVEL) && !menuactive && !finished;
	if (!inLevel) { lastFrameInLevel = 0; return; }
	if (!lastFrameInLevel) { lastFrameInLevel = 1; lastFrameNow = now; winStart = now; winFrames = 0; return; }
	unsigned gap = now - lastFrameNow;
	lastFrameNow = now;
	lvFrames++; lvWallMs += gap; lvWorkMs += workMs; winFrames++;
	if (gap > worstGap) worstGap = gap;
	if (gap > 100) gaps100++;
	if (gap > 250) gaps250++;
	if (gap > 1000) gaps1000++;
	if (now - winStart >= 3000) {
		float fps = 1000.0f * (float)winFrames / (float)(now - winStart);
		if (windows == 0 || fps < minWinFps) minWinFps = fps;
		windows++;
		winStart = now; winFrames = 0;
	}
}

// ---------------------------------------------------------------- the brain
static unsigned lastMenuPress;
static unsigned lastUse;
static unsigned stuckSince, backUpUntil;
static fixed_t stuckX, stuckY;
static int backUpTurn;
static mobj_t* combatTarget;     // the monster being fought, and since when (to give up on one that cannot be killed)
static unsigned combatSince, ignoreFoesUntil;
static int stuckStrikes;         // how many times in a row the same route trapped the bot
static int strafeDir = 1;
static unsigned strafeFlipAt;
static unsigned lastReport;
static int lastGameState = -1;
static int deaths, restarts;
static int lastKills = -1;
static int wasDead;              // the death was already logged (so a long death screen logs once)
static unsigned levelStartedAt;
static int lastLevelTime;        // leveltime last frame: if it goes down, the level restarted

// ---- the control probes (the first level only; see "the playability report")
// Each probe sends input the way the real controls do and measures what the engine did with it. Times are in game tics (35 a second), so the
// probes mean the same thing at any frame rate.
static void runProbe(unsigned now, player_t* pl, mobj_t* me, BotOut* out)
{
	switch (probeStep) {
	case PR_WAIT:                               // one second for the player to settle after the level starts
		if (leveltime >= 35) { probeStep = PR_RIGHT; probeSent = 0; probeAngle = me->angle; probeStartTic = leveltime; }
		break;
	case PR_RIGHT:                              // 2048 counts, a sixteenth per frame, then wait a third of a second for the turn to finish
		if (probeSent < PROBE_TURN_COUNTS) { out->mouse = PROBE_TURN_COUNTS / 16; probeSent += out->mouse; probeStartTic = leveltime; }
		else if (leveltime - probeStartTic >= 12) {
			turnedRight = -angleErrorDeg(me->angle, probeAngle);          // Doom angles grow counter-clockwise: a right turn makes the angle smaller
			probeStep = PR_LEFT; probeSent = 0; probeAngle = me->angle; probeStartTic = leveltime;
		}
		break;
	case PR_LEFT:
		if (probeSent < PROBE_TURN_COUNTS) { out->mouse = -(PROBE_TURN_COUNTS / 16); probeSent += PROBE_TURN_COUNTS / 16; probeStartTic = leveltime; }
		else if (leveltime - probeStartTic >= 12) {
			turnedLeft = angleErrorDeg(me->angle, probeAngle);
			probeStep = PR_WALK; probeSent = 0;
		}
		break;
	case PR_WALK:                               // one second of "up" (the classic layout's forward)
		if (!probeSent) { probeSent = 1; probeStartTic = leveltime; probeX = me->x; probeY = me->y; }
		out->buttons |= kButtonUp;
		if (leveltime - probeStartTic >= 35) {
			walkedUnits = (float)P_AproxDistance(me->x - probeX, me->y - probeY) / (float)FRACUNIT;
			probeStep = PR_FIRE; probeSent = 0;
		}
		break;
	case PR_FIRE: {                             // hold Ⓐ for a third of a second and count the ammunition
		int ammoType = weaponinfo[pl->readyweapon].ammo;
		int have = (ammoType >= 0 && ammoType < NUMAMMO) ? pl->ammo[ammoType] : 0;
		if (!probeSent) { probeSent = 1; probeStartTic = leveltime; probeAmmo = have; }
		out->buttons |= kButtonA;
		if (leveltime - probeStartTic >= 12) {
			ammoUsed = probeAmmo - have;
			probeStep = PR_DONE;
			botLog("[%6u ms] control probes done: right %.1f, left %.1f, walked %.0f units, ammo used %d", now, turnedRight, turnedLeft, walkedUnits, ammoUsed);
#ifdef BOT_TEST_TELEPORT
			P_TeleportMove(me, 840 * FRACUNIT, 497 * FRACUNIT);        // test only: put the player in front of E1M1's door at line 577 (sector 93), facing it
			me->angle = ANG90;
#endif
#ifdef BOT_TEST_NOFOES
			ignoreFoesUntil = now + 600000;                         // test only: ignore every monster, so only the door can stop the bot
#endif
#ifdef BOT_TEST_HEALTH
			pl->health = me->health = BOT_TEST_HEALTH;                       // test only: start the real run hurt (the device run was hurt: health 23)
#endif
			writeReport(now, "controls tested");
		}
		break; }
	default:
		break;
	}
}

// After the last level the run is not over yet: the bot must also get past the score screen into the next level. (A bug the bot found on 2026-10-30: Ⓐ did not work on the
// score screen, so a real player could never leave it. This check keeps that from coming back.)
#define LEAVE_SCORE_MS 60000

// The level that was being played ended (completed, or given up on): store its result, then continue or finish the run.
static void recordLevel(unsigned now, int completed, const char* why)
{
	if (numResults < BOT_LEVELS + 2 && curMapKey >= 0) {
		LevelResult* r = &results[numResults++];
		r->ep = curMapKey / 100; r->map = curMapKey % 100; r->completed = completed; r->ms = now - curMapSince;
		r->kills = lastKillsNow; r->total = lastTotalKills; r->deaths = lvDeaths; r->stuck = lvStuck; r->why = why;
		r->peeks = lvPeeks; r->items = lvItems; r->rooms = visitedCount; r->exitSeenMs = lvExitSeenAt ? lvExitSeenAt - curMapSince : 0;
		botLog("[%6u ms] level E%dM%d %s in %u s (kills %d/%d, deaths %d, stuck %d)", now, r->ep, r->map, completed ? "FINISHED" : "FAILED", r->ms / 1000, r->kills, r->total, r->deaths, r->stuck);
	}
	lastMapDone = curMapKey;
	curMapKey = -1;
	int done = 0;
	for (int i = 0; i < numResults; i++) if (results[i].completed) done++;
	if (!completed) finishRun(now, "a level was not finished");
	else if (done >= BOT_LEVELS) { leaveWait = 1; leaveSince = now; writeReport(now, "leaving the score screen"); }
	else writeReport(now, "running");
}

// ---- the stationary watchdog
// The device run of 2026-10-30 showed the bot standing at one spot for over two minutes with "route ok" and no "stuck" event: both of the bot's own stuck
// checks can be switched off by what it is doing (fighting, or waiting at a door), and the player simply stood there. This watchdog does not care what the
// bot thinks it is doing: if the player has not moved 24 units in STATIONARY_MS it writes down EVERYTHING it knows, then forces a recovery.
#define STATIONARY_MS 6000
#ifndef BOT_RECORD
#define BOT_RECORD 0
#endif
int botStopDemo;                  // tells pd_main.c to write the recording (see BOT_RECORD there)
static unsigned recordStopAt;     // when to do that: a moment after the score screen appears, so the recording shows the level really ended
static unsigned recoverUntil; static int recoverTurn;
static float navTx, navTy; static int navEdge = -1, navWaitAtDoor, navAtExit, navHadFoe, navRiding; static float navErr;   // what the navigation / combat code was doing in the last frame

// Decides this frame's buttons and turning. `inMenu` is true on the title, in Doom's menu and on the screens between levels.
void Bot_Think(unsigned now, int inMenu, BotOut* out)
{
	out->buttons = 0;
	out->mouse = 0;
	if (firstThinkAt == 0) firstThinkAt = now;

	if (gamestate != lastGameState) {
		botLog("[%6u ms] game state %d -> %d%s", now, lastGameState, (int)gamestate, gamestate == GS_INTERMISSION ? "  (LEVEL COMPLETE)" : "");
		int wasLevel = lastGameState == GS_LEVEL;
		lastGameState = gamestate;
		if (gamestate == GS_INTERMISSION && wasLevel && !finished) {
			recordLevel(now, 1, NULL);   // reached the score screen: the level was finished
			if (BOT_RECORD) recordStopAt = now + 1500;
		}
	}
	if (recordStopAt && now >= recordStopAt) { recordStopAt = 0; writeReport(now, "recorded"); botStopDemo = 1; }
	if (finished) return;                          // the run is over: press nothing
	if (leaveWait) {
		if (!inMenu && gameepisode * 100 + gamemap != lastMapDone) { leavePassed = 1; finishRun(now, "finished: all levels played"); return; }
		if (now - leaveSince > LEAVE_SCORE_MS) { finishRun(now, "the score screen did not close"); return; }
	}

	// 1. menus and score screens: tap Enter (the Playdate's Ⓐ) a few times a second
	if (inMenu) {
		unsigned phase = now % 600;
		if (phase < 140) out->buttons |= kButtonA;
		builtForLevel = -1;
		return;
	}

	player_t* pl = &players[consoleplayer];
	mobj_t* me = pl->mo;
	if (me == NULL) return;

	// a new map: reset the per-level counters and the list of rooms visited; the first one also ends the "menus" check
	int mapKey = gameepisode * 100 + gamemap;
	if (mapKey != curMapKey) {
		curMapKey = mapKey; curMapSince = now;
		lvDeaths = lvStuck = lvNoRoute = lvPeeks = lvItems = 0; lvExitSeenAt = 0; peekUntil = peekEndedAt = 0;
		free(visited); visited = (unsigned char*)calloc((size_t)numsectors, 1); visitedCount = 0; lastNewRoomAt = now;
		if (!runStartAt) { runStartAt = now; lastFullReportAt = now; }
		if (!menuDone) { menuDone = 1; menuMs = now - firstThinkAt; }
	}
	lastKillsNow = pl->killcount; lastTotalKills = totalkills;
	if (now - lastFullReportAt > REPORT_EVERY_MS) writeReport(now, "running");
	if (now - curMapSince > LEVEL_TIMEOUT_MS) { recordLevel(now, 0, "not finished within 12 minutes"); return; }

	// the graph is rebuilt whenever a level (re)starts: leveltime counts up from 0 there
	if (builtForLevel < 0 || leveltime < lastLevelTime) {
		levelStartedAt = now;
		buildGraph();
		builtForLevel = 1;
		// a restart after a death reloads the map, so everything seen is forgotten: the walls' flags are gone, and the rooms visited go with them
		if (visited != NULL) memset(visited, 0, (size_t)numsectors);
		pressTarget = -1; visitedCount = 0; lastNewRoomAt = now; lvExitSeenAt = 0; itemTarget = NULL; itemScanAt = 0; skippedNext = 0; memset(skippedItems, 0, sizeof skippedItems);
		stuckSince = 0;
		lastKills = -1;
	}
	lastLevelTime = leveltime;

	// 2. dead: "use" restarts the level
	if (pl->playerstate == PST_DEAD) {
		if (!wasDead) {
			deaths++; totalDeaths++; lvDeaths++;
			botLog("[%6u ms] DIED (death %d) at %d kills", now, deaths, pl->killcount); wasDead = 1;
			if (lvDeaths >= MAX_LEVEL_DEATHS) { recordLevel(now, 0, "died too many times"); return; }
		}
		if (now % 600 < 140) out->buttons |= kButtonB;
		return;
	}
	wasDead = 0;

	// the control probes run first, once, in the first level
	if (probeStep != PR_DONE) { runProbe(now, pl, me, out); return; }

	// progress: has the player reached a new room lately? (a long stretch without one means the bot, or the level, is stuck)
	{
		static int npWarned, npFailed;
		int room = (int)(me->subsector->sector - sectors);
		if (visited != NULL && room >= 0 && room < numsectors && !visited[room]) {
			visited[room] = 1; visitedCount++; lastNewRoomAt = now; npWarned = npFailed = 0;
		}
		unsigned idle = now - lastNewRoomAt;
		if (idle > NO_PROGRESS_WARN_MS && !npWarned) { npWarned = 1; noProgressWarns++; botLog("[%6u ms] WARN: no new room for %u s (%d rooms seen)", now, idle / 1000, visitedCount); }
		if (idle > NO_PROGRESS_FAIL_MS && !npFailed) {
			npFailed = 1; noProgressFails++;
			botLog("[%6u ms] FAIL: no new room for %u s", now, idle / 1000);
			recordLevel(now, 0, "no progress (softlock or the bot is stuck)");
			return;
		}
	}

	if (pl->killcount != lastKills) {
		if (lastKills >= 0) botLog("[%6u ms] kills %d  (health %d, armor %d)", now, pl->killcount, pl->health, pl->armorpoints);
		lastKills = pl->killcount;
	}

	// the stationary watchdog (see above)
	{
		static fixed_t wx, wy; static unsigned wt;
		if (wt == 0 || navRiding || P_AproxDistance(me->x - wx, me->y - wy) > 24 * FRACUNIT) { wx = me->x; wy = me->y; wt = now; }   // (standing still on a moving lift is the right thing to do)
		else if (now - wt > STATIONARY_MS) {
			botLog("[%6u ms] WATCHDOG: not moved for %u s at (%d, %d) sector %d, health %d: foe %s, waiting at a door %s, at the exit %s, doorway %d%s",
				now, (now - wt) / 1000, me->x >> FRACBITS, me->y >> FRACBITS, (int)(me->subsector->sector - sectors), pl->health,
				navHadFoe ? "yes" : "no", navWaitAtDoor ? "yes" : "no", navAtExit ? "yes" : "no", navEdge >= 0 ? edges[navEdge].line : -1,
				(navEdge >= 0 && isPlainDoor(lines[edges[navEdge].line].special)) ? " (a plain door)" : "");
			if (navEdge >= 0 && navEdge < numEdges) {   // the doorway it was working on, as it is RIGHT NOW (to find out why a door does not open)
				line_t* dl = &lines[edges[navEdge].line];
				botLog("            line %d special %d: front sector %d floor %d ceiling %d; back sector %d floor %d ceiling %d; player angle %.0f deg, error to the target %.0f deg; target (%d, %d)",
					edges[navEdge].line, dl->special,
					(int)(dl->frontsector - sectors), dl->frontsector->floorheight >> FRACBITS, dl->frontsector->ceilingheight >> FRACBITS,
					(int)(dl->backsector - sectors), dl->backsector->floorheight >> FRACBITS, dl->backsector->ceilingheight >> FRACBITS,
					(double)me->angle * (360.0 / 4294967296.0), navErr, (int)navTx, (int)navTy);
			}
			totalStuck++; lvStuck++;
			recoverUntil = now + 1100; recoverTurn = (rand() % 2 ? 1 : -1) * (250 + rand() % 300);
			ignoreFoesUntil = now + 8000;                               // stop trading shots with whatever it was facing
			if (navEdge >= 0 && navEdge < numEdges) banEdge(navEdge, now, 15000);   // and try a different way for a while
			stuckSince = 0; wt = now;
		}
	}
	if (now < recoverUntil) { out->buttons |= kButtonDown; out->mouse = recoverTurn; return; }   // back up while turning
#ifdef BOT_TEST_FREEZE
	if (now - runStartAt > 20000 && now - runStartAt < 33000) return;   // test only: stand perfectly still for 13 s, to see the watchdog catch it
#endif

	{   // floors move: see refreshEdges
		static unsigned edgesAt;
		if (now - edgesAt > 3000) { edgesAt = now; refreshEdges(); }
	}

	// 3. combat
	mobj_t* foe = (now < ignoreFoesUntil) ? NULL : nearestVisibleMonster(me);
	if (foe != NULL && foe != combatTarget) { combatTarget = foe; combatSince = now; seenSince = now; burstShotsFired = 0; aimNoiseAt = 0; }
	if (foe != NULL && now - combatSince > COMBAT_GIVE_UP_MS) {
		// a monster that will not die (behind glass, across a pit, out of reach of the pistol): stop wasting ammo on it and move on for a while
		botLog("[%6u ms] giving up on a monster that has not died in %d s; walking on", now, COMBAT_GIVE_UP_MS / 1000);
		ignoreFoesUntil = now + 12000;
		foe = NULL;
	}
	navHadFoe = (foe != NULL);
	if (foe != NULL) {
		stuckSince = 0;
		fixed_t d = P_AproxDistance(foe->x - me->x, foe->y - me->y);
		// startled: for a moment after the monster comes into view the player just stops and stares (a human takes time to react)
		if (now - seenSince < ME.reactMs) return;
		angle_t want = R_PointToAngle2(me->x, me->y, foe->x, foe->y);
		float err = angleErrorDeg(want, me->angle);
		// the aiming error: re-rolled a few times a second, bigger with distance. The bot steers by what it BELIEVES (err + noise), so a
		// big error really does mean a miss.
		if (now - aimNoiseAt > 260) { aimNoiseAt = now; aimNoiseDeg = gauss() * ME.aimSigmaDeg * (1.0f + (float)(d >> FRACBITS) / 700.0f); }
		float believed = err + aimNoiseDeg;
		out->mouse = countsToTurn(believed);
		// fire in bursts: a few shots, then a pause (counted by the ammunition going down)
		int ammoType = weaponinfo[pl->readyweapon].ammo;
		int ammoNow = (ammoType >= 0 && ammoType < NUMAMMO) ? pl->ammo[ammoType] : 0;
		if (lastAmmoSeen >= 0 && ammoNow < lastAmmoSeen) {
			shotsFiredTotal += lastAmmoSeen - ammoNow; burstShotsFired += lastAmmoSeen - ammoNow;
			if (burstShotsFired >= ME.burstShots) { burstShotsFired = 0; burstsTotal++; burstPauseUntil = now + ME.pauseMs; }
		}
		lastAmmoSeen = ammoNow;
		if (fabsf(believed) < ME.fireAngleDeg && now >= burstPauseUntil) out->buttons |= kButtonA;
		// movement: back away when hurt, otherwise strafe from side to side, and walk up to far targets
		if (pl->health < ME.retreatHealth) out->buttons |= kButtonDown;
		else if (d > 500 * FRACUNIT && fabsf(err) < 12.0f) out->buttons |= kButtonUp;
		if (now > strafeFlipAt) { strafeDir = -strafeDir; strafeFlipAt = now + 500 + (unsigned)(rand() % 700); }
		out->buttons |= (strafeDir > 0) ? kButtonRight : kButtonLeft;
		return;
	}
	lastAmmoSeen = -1;

	// 4. navigation
	int mySector = (int)(me->subsector->sector - sectors);
	float tx, ty;           // where to walk, in map units
	int doorNear = 0;
	int atExit = 0;
	// the route is only worked out when the room changes or every ROUTE_EVERY_MS: between searches the bot simply keeps walking to the same doorway
	static int cachedEdge = -1, cachedRoom = -1; static unsigned cachedAt;
	if (mySector != cachedRoom || now - cachedAt >= ROUTE_EVERY_MS || now < cachedAt || (cachedEdge >= 0 && cachedEdge < numEdges && edges[cachedEdge].bannedUntil > now)) {
		cachedEdge = chooseRoute(mySector, now, pl); cachedRoom = mySector; cachedAt = now;
	}
	int firstEdge = cachedEdge;
	int atGoalRoom = (mySector == goalSector && goalLine >= 0 && (!BOT_EXPLORE || navMode[0] != 'e'));   // "exploring" means the exit has not been seen, so it does not count
	int actionLine = goalLine;                                     // the line to walk up to and press
	if (pressTarget >= 0) { actionLine = pressTarget; atGoalRoom = (lines[pressTarget].frontsector - sectors) == mySector; }
	int waitAtDoor = 0;   // standing in front of a door that is still opening, or a lift that has not come down
	int riding = 0;       // standing on a lift, waiting to reach the height of the next room
	navEdge = firstEdge;

	// a wanted item in view takes priority over the route (see "picking things up")
	if (now - itemScanAt >= ITEM_SCAN_MS) { itemScanAt = now; scanForItems(me, pl, now, (int)ME.fovDeg); }
	if (itemTarget != NULL && now - itemSince > ITEM_GIVE_UP_MS) {
		skippedItems[skippedNext] = itemTarget; skippedNext = (skippedNext + 1) % SKIPPED_ITEMS;
		itemTarget = NULL;
	}
	{
		static int itemsWere = -1;                                  // the game's own count of items picked up, for the report
		if (itemsWere >= 0 && pl->itemcount > itemsWere) { lvItems += pl->itemcount - itemsWere; totalItems += pl->itemcount - itemsWere; }
		itemsWere = pl->itemcount;
	}

	if (itemTarget != NULL) {
		tx = (float)itemX / FRACUNIT; ty = (float)itemY / FRACUNIT;
		firstEdge = -1; navEdge = -1;                               // a stuck moment here says nothing about the doorway
	} else if (atGoalRoom && isWalkExit(lines[actionLine].special)) {
		// a walk-across exit: head for its middle and keep going, past it
		line_t* l = &lines[goalLine];
		float mx = (float)(l->v1->x + l->v2->x) / 2.0f / FRACUNIT, my = (float)(l->v1->y + l->v2->y) / 2.0f / FRACUNIT;
		float len = sqrtf((float)l->dx * (float)l->dx + (float)l->dy * (float)l->dy) / FRACUNIT;
		tx = mx - (float)l->dy / FRACUNIT / len * 40.0f;
		ty = my + (float)l->dx / FRACUNIT / len * 40.0f;
	} else if (atGoalRoom) {
		// in the exit room (or a switch's room): walk up to the switch, face it and press "use"
		line_t* l = &lines[actionLine];
		float mx = (float)(l->v1->x + l->v2->x) / 2.0f / FRACUNIT, my = (float)(l->v1->y + l->v2->y) / 2.0f / FRACUNIT;
		float len = sqrtf((float)l->dx * (float)l->dx + (float)l->dy * (float)l->dy) / FRACUNIT;
		float nx = (float)l->dy / FRACUNIT / len, ny = -(float)l->dx / FRACUNIT / len;   // the normal toward the front side
		tx = mx + nx * 20.0f;
		ty = my + ny * 20.0f;
		float dx = (float)me->x / FRACUNIT - mx, dy = (float)me->y / FRACUNIT - my;
		if (sqrtf(dx * dx + dy * dy) < 60.0f) { atExit = 1; tx = mx; ty = my; }
	} else if (firstEdge >= 0) {
		line_t* l = &lines[edges[firstEdge].line];
		// aim at the point of the doorway closest to the player (but away from its ends), pushed a little into the next room
		float ax = (float)l->v1->x / FRACUNIT, ay = (float)l->v1->y / FRACUNIT, bx = (float)l->v2->x / FRACUNIT, by = (float)l->v2->y / FRACUNIT;
		float ex = bx - ax, ey = by - ay, len2 = ex * ex + ey * ey, len = sqrtf(len2);
		float px = (float)me->x / FRACUNIT, py = (float)me->y / FRACUNIT;
		float t = ((px - ax) * ex + (py - ay) * ey) / len2;
		float margin = 28.0f / len;
		if (margin > 0.45f) margin = 0.45f;
		if (t < margin) t = margin;
		if (t > 1.0f - margin) t = 1.0f - margin;
		float cx = ax + ex * t, cy = ay + ey * t;
		float nx = ey / len, ny = -ex / len;   // the normal toward the front side
		if (lines[edges[firstEdge].line].backsector - sectors == edges[firstEdge].to) { nx = -nx; ny = -ny; }   // heading into the back sector: flip
		tx = cx + nx * 36.0f;
		ty = cy + ny * 36.0f;
		float dx = px - cx, dy = py - cy;
		doorNear = (l->special != 0) && sqrtf(dx * dx + dy * dy) < 90.0f;
		// a plain door that is still closed: stand in front of it pressing "use" until it has opened (opening takes about a second)
		if (isPlainDoor(l->special) && doorIsClosed(l) && sqrtf(dx * dx + dy * dy) < 70.0f) waitAtDoor = 1;
		// a lift that is still up: the same, press its face and wait. Once the floor is low enough this is false, and the bot simply walks on board
		int to = edges[firstEdge].to;
		if (liftSector[to] && isUseLift(l->special) && sectors[to].floorheight - sectors[mySector].floorheight > STEP_HEIGHT && sqrtf(dx * dx + dy * dy) < 70.0f) waitAtDoor = 1;
		// on a lift that has not reached the next room yet: stay on it. Walking into the wall here would look like being stuck
		if (liftSector[mySector] && sectors[to].floorheight - sectors[mySector].floorheight > STEP_HEIGHT) riding = 1;
	} else {
		// no route known (a locked door, or no exit switch): wander ahead and rely on the stuck handling to turn
		tx = (float)me->x / FRACUNIT + cosf((float)me->angle * (6.2831853f / 4294967296.0f)) * 200.0f;
		ty = (float)me->y / FRACUNIT + sinf((float)me->angle * (6.2831853f / 4294967296.0f)) * 200.0f;
	}

	navWaitAtDoor = waitAtDoor; navAtExit = atExit; navRiding = riding;
	angle_t want = R_PointToAngle2(me->x, me->y, (fixed_t)(tx * FRACUNIT), (fixed_t)(ty * FRACUNIT));
	float err = angleErrorDeg(want, me->angle);
	navErr = err; navTx = tx; navTy = ty;
	out->mouse = countsToTurn(err);

	// stuck handling: if the player has hardly moved for a while, back up while turning a random amount
	if (stuckSince == 0 || P_AproxDistance(me->x - stuckX, me->y - stuckY) > STUCK_DISTANCE) { stuckSince = now; stuckX = me->x; stuckY = me->y; }
	if (riding) {
		stuckSince = now;
		stuckX = me->x; stuckY = me->y;
	} else if (waitAtDoor) {
		stuckSince = now;   // waiting for a door is not being stuck
		stuckX = me->x; stuckY = me->y;
		if (fabsf(err) >= 25.0f) { /* turn toward the door first */ }
		else if (P_AproxDistance(me->x - (fixed_t)(tx * FRACUNIT), me->y - (fixed_t)(ty * FRACUNIT)) > 80 * FRACUNIT) out->buttons |= kButtonUp;
	} else if (now < backUpUntil) {
		out->buttons |= kButtonDown;
		out->mouse = backUpTurn;
	} else if (now - stuckSince > STUCK_MS && !atExit) {
		backUpUntil = now + 450;
		backUpTurn = (rand() % 2 ? 1 : -1) * (150 + rand() % 250);
		stuckSince = now;
		totalStuck++; lvStuck++;
		botLog("[%6u ms] stuck at (%d, %d) in sector %d: backing up", now, me->x >> FRACBITS, me->y >> FRACBITS, mySector);
		if (frontierTarget >= 0 && firstEdge >= 0 && edges[firstEdge].to == frontierTarget) {   // the frontier is right there and cannot be entered: it is not a place
			frontierRest[frontierTarget] = now + FRONTIER_REST_MS; frontierTarget = -1;
		}
		if (firstEdge >= 0) {   // this doorway is not working: describe it and route around it for a while
			line_t* sl = &lines[edges[firstEdge].line];
			botLog("            doorway: line %d special %d flags %d, sector %d (floor %d ceil %d) -> sector %d (floor %d ceil %d)", edges[firstEdge].line, sl->special, sl->flags,
				edges[firstEdge].from, sectors[edges[firstEdge].from].floorheight >> FRACBITS, sectors[edges[firstEdge].from].ceilingheight >> FRACBITS,
				edges[firstEdge].to, sectors[edges[firstEdge].to].floorheight >> FRACBITS, sectors[edges[firstEdge].to].ceilingheight >> FRACBITS);
			if (!isPlainDoor(sl->special) && ++stuckStrikes >= 2) { banEdge(firstEdge, now, 6000); stuckStrikes = 0; }
		}
	} else if (fabsf(err) < 40.0f && !atExit) {
		out->buttons |= kButtonUp;
	} else if (atExit && fabsf(err) < 8.0f) {
		/* standing at the switch and facing it: nothing to walk */
	} else if (atExit) {
		/* still turning toward the switch */
	}

	// "use": near a door or the exit switch, and now and then when stuck
	if (riding) doorNear = 0;                                       // nothing to press while riding
	unsigned useGap = (doorNear || waitAtDoor) ? USE_DOOR_MS : USE_EVERY_MS;   // doors need a long gap between presses (see USE_DOOR_MS)
	if ((doorNear || waitAtDoor || atExit || (now - stuckSince > 300)) && now - lastUse >= useGap) {
		lastUse = now;
		out->buttons |= kButtonB;
		if (atExit) botLog("[%6u ms] pressing use on line %d", now, actionLine);
		if (atExit && pressTarget >= 0) { linePressed[pressTarget] = 1; pressTarget = -1; lvSwitches++; cachedAt = 0; }
	}

	if (now - lastReport > 3000) {
		lastReport = now;
		botLog("[%6u ms] map %d-%d  health %d  armor %d  kills %d/%d  items %d  pos (%d, %d)  sector %d  rooms %d  %s%s", now, gameepisode, gamemap, pl->health, pl->armorpoints,
			pl->killcount, totalkills, lvItems, me->x >> FRACBITS, me->y >> FRACBITS, mySector, visitedCount, itemTarget != NULL ? "fetching an item" : navMode, (firstEdge >= 0 || itemTarget != NULL) ? "" : " (no route)");
	}
}

#endif   // TEST_BOT
