#include <stdarg.h>
#include <stdlib.h>
#include <strings.h>
#include <stdio.h>
#include <string.h>
#include "stream.h"
#include "decoder.h"
#include "audio.h"
#include "icy.h"

// Adaptive buffer. Normally we keep BASE_TARGET seconds decoded ahead, which keeps
// tuning snappy. When the Wi-Fi struggles (the buffer runs low or dries up), the
// target grows in steps up to MAX_TARGET so the next hiccup is absorbed instead of
// heard; after a long calm spell it shrinks back. (The ring in main.c must hold
// MAX_TARGET seconds.)
#define START_SECONDS 1.0f      // buffered audio needed before playback starts (normal case)
#define BASE_TARGET 3.0f        // seconds to keep decoded ahead when the network is fine
#define MAX_TARGET 10.0f        // ...and the most we will ever ask for
#define TARGET_STEP 3.0f        // growth per trouble event
#define LOW_WATER 0.4f          // buffered seconds below which we call it "running low"
#define ESCALATE_GAP_MS 8000    // at most one growth step per this long (one dip isn't a trend)
#define CALM_MS 180000          // this long without trouble: shrink the target by 1s
#define FRAMES_PER_UPDATE 8     // decode budget per frame (~0.2s of audio)
#define RETRY_MS 3000
#define CONNECT_GIVEUP_TLS_MS 12000  // https needs a handshake first: ~4 s on the device when it works (2026-11-13), and
                                    // several https stations failed at the 7 s limit, so they get longer
#define CONNECT_GIVEUP_MS 7000  // a server that has not even accepted the connection by now is not going to
// (the SDK's own connect timeout was not honoured in the Simulator: a dead server sat "connecting" for over a minute)
#define UNREACHABLE_TRIES 2      // this many silent attempts in a row and the station is reported dead (dropped from its band).
                                 // (It was 1, which was fine in the Simulator; on the device a working station sometimes fails
                                 // once, e.g. K-Dot timed out at 64 s and played fine at 370 s in the log of 2026-11-13.)
#define QUICK_FAIL_MS 1500       // a connection refused faster than this never reached the server: the Playdate itself said
                                 // no (errors -2 "busy" and -21, seen in bursts on the device while switching fast or while the
                                 // directory search ran). That says nothing about the station, so it is not counted against it.
#define BUSY_RETRY_MS 2500       // ...and we wait this long before trying again, to let the Playdate's network settle
// One, because a second attempt usually lands on the same dead server, and in the Simulator a hanging connection holds
// up every other connection for about a minute (some hosts, e.g. infomaniak's pool, have servers that never answer).
#define NO_AUDIO_MS 12000       // connected but nothing decodable for this long: not an MP3 stream we can play, try again later
#define MAX_REDIRECTS 3         // a station's address may forward us (say, to a load-balanced server) this many times
#define HEAD_MAX 4096           // the longest response header we accept (Shoutcast notices make some 1-2 KB)

// Why raw TCP and not the SDK's HTTP client: testing the directory edition against dozens of servers found three problems in
// the HTTP client (see CLAUDE.md, 2026-11-11): it drops the first character of every header value when a server writes
// "Key:value" without a space (common on Shoutcast), it does not follow redirects, and closing a connection that answered
// with a redirect left the network layer unable to connect anywhere for a minute or more. Speaking HTTP ourselves over a
// TCP connection is a few dozen lines and removes all three: we parse the headers, follow redirects, and accept the
// "ICY 200 OK" status line old Shoutcast servers send. We ask in HTTP/1.0 so no server answers in "chunked" pieces.

static PlaydateAPI* pd;
static const struct playdate_tcp* tcp;
static Mp3Stream* dec;
static TCPConnection* conn;
static StreamState state = STREAM_NEED_ACCESS;
static const Station* current;    // station being streamed
static const Station* wanted;     // station the dial is on
static unsigned int retryAt;
static unsigned int generation;   // ignores callbacks from connections we've dropped
static int pendingOpen;           // set by the open callback: 1 = connected, <0 = a PDNetErr
static int pendingClosed;         // set by the closed callback
static int requestSent;           // our GET has been written
static int headerDone;            // the response header has been read and handled
static char head[HEAD_MAX + 1];   // the response header as it arrives
static int headLen;
static IcyParser icy;
static float targetSeconds = BASE_TARGET;   // current buffer target (grows on Wi-Fi trouble)
static unsigned int lastEscalateAt, lastTroubleAt;
static int rebuffering;           // ran dry after playing: show "buffering" and refill deeper
static SDFile* logFile;
static int bytesRead, framesDecoded;
static unsigned int statsAt;
static unsigned int openedAt;     // when the current connection was opened (for NO_AUDIO_MS)
static int redirects;             // hops followed for the current station
static char hopHost[64], hopPath[512];   // where the current connection really goes (the station's own address or a hop)
static int hopPort;
static int hopSecure;   // 1 = this hop is https (the Playdate's TCP API does the encryption)
static const Station* deadStation;   // reported once through stream_take_dead()
static char lastTitle[ICY_TITLE_MAX];  // the song playing now, as last announced
static char prevTitle[ICY_TITLE_MAX];  // the song before it on this station ("" until the first change)
static const Station* silentStation; // the station whose last attempts got no answer at all
static int silentTries;              // how many attempts in a row that was

// Log to the console and to radio.log in the game's data folder
// (Simulator: ~/Developer/PlaydateSDK/Disk/Data/<bundle id>/radio.log).
void dlog(const char* fmt, ...)
{
	char buf[256];
	va_list ap;
	va_start(ap, fmt);
	int n = vsnprintf(buf, sizeof buf - 1, fmt, ap);
	va_end(ap);
	if (n < 0) return;
	if (n > (int)sizeof buf - 2) n = (int)sizeof buf - 2;
	pd->system->logToConsole("radio: %s", buf);
	if (logFile != NULL) {
		char line[280];
		int m = snprintf(line, sizeof line, "%u %s\n", pd->system->getCurrentTimeMilliseconds(), buf);
		pd->file->write(logFile, line, (unsigned int)m);
		pd->file->flush(logFile);
	}
}

/**
 * Drops the current connection and everything buffered from it. The userdata is cleared first so a callback still on its
 * way is ignored. Only close(): it also frees the connection. Calling release() after it crashed the Simulator on the next
 * station (2026-11-11), exactly like the HTTP client's double free of 2026-09-27, even though the SDK documentation says a
 * closed TCP connection "may be used again".
 */
// ---- the parking lot: connections that are still connecting are never closed, only parked ----
//
// On the device, closing a connection whose open() had not answered yet (a server that never replies) seems to leave it
// holding one of the Playdate's few network slots: after a few of those, EVERY new connection was refused at once
// ("could not connect (-21)") for minutes, and only restarting the app cleared it (seen on 2026-11-13 after two silent
// stations in a row; the earlier "45 s jams" started the same way). So such a connection is parked: its userdata becomes a
// PARK_TAG marker, and it is closed only once its open callback has arrived (success or failure), or after PARK_LIMIT_MS.
#define PARK_MAX 8
#define PARK_TAG 0x40000000u          // userdata of a parked connection: PARK_TAG | slot
#define PARK_LIMIT_MS 20000           // safety: close it anyway after this long
static TCPConnection* parked[PARK_MAX];
static unsigned int parkedAt[PARK_MAX];
static volatile char parkDone[PARK_MAX];

/** Parks `c` (still connecting). Returns 0 if the lot is full; then the caller just closes it. */
int net_park(TCPConnection* c)
{
	for (int i = 0; i < PARK_MAX; i++)
		if (parked[i] == NULL) {
			parked[i] = c;
			parkedAt[i] = pd->system->getCurrentTimeMilliseconds();
			parkDone[i] = 0;
			tcp->setUserdata(c, (void*)(uintptr_t)(PARK_TAG | (unsigned)i));
			dlog("parked a connection that is still connecting (slot %d)", i);
			return 1;
		}
	return 0;
}

/** For open callbacks: if `c` is parked, notes that its open finished and returns 1 (the callback should do nothing else). */
int net_park_opened(TCPConnection* c)
{
	uintptr_t ud = (uintptr_t)tcp->getUserdata(c);
	if ((ud & PARK_TAG) == 0 || (ud & 0xFF) >= PARK_MAX || parked[ud & 0xFF] != c) return 0;
	parkDone[ud & 0xFF] = 1;
	return 1;
}

/** Closes parked connections whose open has finished (or that waited too long). Called every frame. */
static void tendParking(void)
{
	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	for (int i = 0; i < PARK_MAX; i++)
		if (parked[i] != NULL && (parkDone[i] || now - parkedAt[i] > PARK_LIMIT_MS)) {
			dlog("closing parked connection %d (%s)", i, parkDone[i] ? "its open finished" : "waited too long");
			tcp->setUserdata(parked[i], NULL);
			tcp->close(parked[i]);
			parked[i] = NULL;
		}
}

static void closeConnection(void)
{
	if (conn != NULL) {
		if (pendingOpen != 0 || !net_park(conn)) {   // still connecting: park it instead (see above)
			tcp->setUserdata(conn, NULL);
			tcp->close(conn);
		}
		conn = NULL;
	}
	gAudio.playing = 0;           // callback stops reading before we clear
	rebuffering = 0;
	ring_clear(&gAudio.ring);
	decoder_reset(dec);
	icy_init(&icy, 0);
	current = NULL;
}

static void fail(void)
{
	closeConnection();
	state = STREAM_ERROR;
	retryAt = pd->system->getCurrentTimeMilliseconds() + RETRY_MS;
}

/**
 * The current attempt got no answer at all (no connection, or not a single byte). Some radio servers sit behind a pool of
 * addresses where one machine is dead; a station that lands on it keeps failing, and in the Simulator a connection that
 * hangs also holds up every other connection (even the station search). So after UNREACHABLE_TRIES silent attempts in a
 * row the station is reported dead, and main.c removes it from the dial instead of retrying it for ever.
 * Call it BEFORE fail(), which forgets the current station.
 */
static void noteSilence(void)
{
	if (current == NULL) return;
	if (current == silentStation) silentTries++;
	else { silentStation = current; silentTries = 1; }
	if (silentTries >= UNREACHABLE_TRIES) {
		dlog("giving up on %s: no answer %d times", current->title, silentTries);
		deadStation = current;
		silentStation = NULL;
		silentTries = 0;
	}
}

static int isLive(TCPConnection* c)
{
	return c != NULL && c == conn && tcp->getUserdata(c) == (void*)(uintptr_t)generation;
}

// Callbacks only record what happened; closing a connection from inside its own callback isn't safe, so stream_update
// acts on these flags.
static void onOpen(TCPConnection* c, PDNetErr err, void* ud)
{
	(void)ud;
	if (net_park_opened(c)) return;
	if (isLive(c)) pendingOpen = err == NET_OK ? 1 : (int)err;
}

static void onClosed(TCPConnection* c, PDNetErr err)
{
	(void)err;
	if (isLive(c)) pendingClosed = 1;
}

/**
 * Opens the connection for the current station at hopHost:hopPort/hopPath (the station's own address, or where it
 * redirected us). `current` must already be set; closeConnection() clears it, so it is set again here.
 * Nothing is sent yet: the request goes out in stream_update once the open callback says we are connected.
 */
static void openHop(const Station* station)
{
	closeConnection();
	generation++;
	pendingOpen = pendingClosed = requestSent = headerDone = 0;
	headLen = 0;
	bytesRead = framesDecoded = 0;
	// Every station names its own server, port and path (stations.h), so one app can play stations from many servers.
	dlog("open %s%s:%d%s", hopSecure ? "https://" : "", hopHost, hopPort, hopPath);
	current = station;
	openedAt = pd->system->getCurrentTimeMilliseconds();
	state = STREAM_CONNECTING;
	conn = tcp->newConnection(hopHost, hopPort, hopSecure != 0);
	if (conn == NULL) { dlog("newConnection failed"); fail(); return; }
	tcp->setUserdata(conn, (void*)(uintptr_t)generation);
	tcp->setConnectTimeout(conn, hopSecure ? 13000 : 8000);   // a little past our own give-up time
	tcp->setReadTimeout(conn, 50);         // we only ever read what is already there, so this should never be waited out
	tcp->setReadBufferSize(conn, 64 * 1024);
	tcp->setConnectionClosedCallback(conn, onClosed);
	PDNetErr err = tcp->open(conn, onOpen, NULL);
	if (err != NET_OK) { dlog("open() failed %d", err); fail(); }
}

/** Starts a station from its own address (no redirects followed yet). */
static void openStation(const Station* station)
{
	lastTitle[0] = prevTitle[0] = '\0';   // a new station: its song history starts empty
	redirects = 0;
	snprintf(hopHost, sizeof hopHost, "%s", station->host);
	hopPort = station->port;
	hopSecure = station->secure;
	snprintf(hopPath, sizeof hopPath, "%s", station->path);
	openHop(station);
}

/** Writes our request: HTTP/1.0 (no chunked answers), our name, and a request for in-stream song titles. */
static int sendRequest(void)
{
	char req[900];
	int n;
	if (hopPort == (hopSecure ? 443 : 80))
		n = snprintf(req, sizeof req, "GET %s HTTP/1.0\r\nHost: %s\r\n", hopPath, hopHost);
	else
		n = snprintf(req, sizeof req, "GET %s HTTP/1.0\r\nHost: %s:%d\r\n", hopPath, hopHost, hopPort);
	n += snprintf(req + n, sizeof req - (size_t)n,
		"User-Agent: " APP_AGENT "\r\nAccept: */*\r\nIcy-MetaData: 1\r\nConnection: close\r\n\r\n");
	if (n >= (int)sizeof req) return 0;
	int sent = tcp->write(conn, req, (size_t)n);
	if (sent != n) { dlog("write sent %d of %d", sent, n); return 0; }
	return 1;
}

/**
 * Finds `key` (case does not matter) in the header block and copies its value, without the spaces around it, into out.
 * Works whether or not the server put a space after the colon. Returns 0 if the header is not there.
 */
static int headerValue(const char* key, char* out, int cap)
{
	size_t klen = strlen(key);
	const char* line = strchr(head, '\n');            // skip the status line
	while (line != NULL) {
		line++;
		if (strncasecmp(line, key, klen) == 0 && line[klen] == ':') {
			const char* v = line + klen + 1;
			while (*v == ' ' || *v == '\t') v++;
			int n = 0;
			while (v[n] != '\0' && v[n] != '\r' && v[n] != '\n' && n < cap - 1) n++;
			while (n > 0 && v[n - 1] == ' ') n--;
			memcpy(out, v, (size_t)n);
			out[n] = '\0';
			return 1;
		}
		line = strchr(line, '\n');
	}
	return 0;
}

/**
 * Follows a redirect to `location` if it is plain http and we have not hopped too often. Returns 0 when it cannot be
 * followed (https, or a loop); an https target also marks the station as unplayable for good (main.c drops it).
 */
static int followRedirect(const char* location)
{
	if (redirects >= MAX_REDIRECTS || current == NULL) return 0;
	char host[64], path[512];
	int port, secure = 0;
	if (!url_split(location, host, (int)sizeof host, &port, path, (int)sizeof path, &secure)) {
		dlog("redirect not followed: %.80s", location);
		if (strncasecmp(location, "https://", 8) == 0) deadStation = current;
		return 0;
	}
	redirects++;
	snprintf(hopHost, sizeof hopHost, "%s", host);
	hopPort = port;
	hopSecure = secure;
	snprintf(hopPath, sizeof hopPath, "%s", path);
	dlog("redirect %d -> %s%s:%d", redirects, hopSecure ? "https://" : "", hopHost, hopPort);
	openHop(current);
	return 1;
}

/**
 * Reads the response header as it arrives. Once it is complete, acts on it: 200 starts the stream (the bytes after the
 * header are already audio), a 3xx is followed, anything else fails. Returns -1 if the connection was replaced or dropped
 * (stop working with it this frame), 0 if the header is still incomplete, 1 when audio can flow.
 */
static int readHeader(void)
{
	size_t avail = tcp->getBytesAvailable(conn);
	if (avail > 0 && headLen < HEAD_MAX) {
		int want = (int)avail < HEAD_MAX - headLen ? (int)avail : HEAD_MAX - headLen;
		int got = tcp->read(conn, head + headLen, (size_t)want);
		if (got > 0) headLen += got;
	} else if (pendingClosed && headLen < HEAD_MAX) {
		// The server sent its whole (short) answer and closed at once (redirects do this), and nothing shows as
		// available any more: ask for it anyway, read() then waits at most the 50 ms read timeout.
		int got = tcp->read(conn, head + headLen, (size_t)(HEAD_MAX - headLen));
		dlog("read after close: %d", got);
		if (got > 0) headLen += got;
	}
	head[headLen] = '\0';
	char* end = strstr(head, "\r\n\r\n");
	int sepLen = 4;
	if (end == NULL) { end = strstr(head, "\n\n"); sepLen = 2; }
	if (end == NULL) {
		if (headLen >= HEAD_MAX) { dlog("response header too long"); fail(); return -1; }
		return 0;
	}
	int bodyStart = (int)(end - head) + sepLen;
	int extra = headLen - bodyStart;               // audio that came in the same read as the header
	char body0[HEAD_MAX];
	memcpy(body0, head + bodyStart, (size_t)extra);
	end[2] = '\0';                                 // keep the header's last line ending, cut the rest
	headerDone = 1;

	// "HTTP/1.1 200 OK" or Shoutcast's "ICY 200 OK"
	int status = 0;
	const char* sp = strchr(head, ' ');
	if (sp != NULL) status = atoi(sp + 1);
	char value[512];
	if (status >= 300 && status < 400 && headerValue("location", value, (int)sizeof value)) {
		if (!followRedirect(value)) fail();
		return -1;
	}
	if (status != 200) {
		dlog("status %d", status);
		// An error answer (404 "not found", 403, 5xx: the stream is offline or gone) counts like silence, so after
		// UNREACHABLE_TRIES the station is dropped instead of retried every 3 s for ever (Alicia radio, 2026-11-13).
		if (status >= 400) noteSilence();
		fail();
		return -1;
	}
	if (headerValue("transfer-encoding", value, (int)sizeof value) && strncasecmp(value, "chunked", 7) == 0) {
		dlog("chunked answer: not supported");   // (should not happen: we ask in HTTP/1.0)
		fail();
		return -1;
	}
	dlog("status 200");
	int metaint = headerValue("icy-metaint", value, (int)sizeof value) ? atoi(value) : 0;
	icy_init(&icy, metaint);                       // must be set before the first audio byte is parsed
	state = STREAM_BUFFERING;
	if (extra > 0) {                               // hand the audio that came with the header to the decoder
		int space;
		uint8_t* dst = decoder_input(dec, &space);
		if (extra > space) extra = space;
		memcpy(dst, body0, (size_t)extra);
		bytesRead += extra;
		decoder_commit(dec, icy_filter(&icy, dst, extra));
	}
	return 1;
}

// Opens radio.log as early as possible so startup problems on the device leave a trail.
void dlog_init(PlaydateAPI* playdate)
{
	pd = playdate;
	if (logFile == NULL) logFile = pd->file->open("radio.log", kFileWrite);
}

static void onWifi(PDNetErr err)
{
	dlog("wifi enable callback: err %d", err);
}

void stream_init(PlaydateAPI* playdate)
{
	pd = playdate;
	tcp = pd->network->tcp;
	dec = decoder_new(pd->system->realloc);
	dlog_init(playdate);
	dlog("init, wifi status %d", pd->network->getStatus());
	dlog("stream_init: decoder %p, tcp %p", (void*)dec, (void*)tcp);
	pd->network->setEnabled(true, onWifi);   // start joining Wi-Fi now; it can take ~10s
	dlog("stream_init: setEnabled returned");
}

// The access dialog is requested from the update loop rather than at init.
//
// The streams use raw TCP and (in the directory edition) the station search uses HTTP, so both kinds of access are asked
// for, one after the other: TCP first, then HTTP once TCP is allowed. The SDK may remember both from a single answer;
// if not, the player sees two prompts the first time (checked in the Simulator: see CLAUDE.md).
static int asking;   // 0 nothing asked yet, 1 waiting for the TCP answer, 2 waiting for the HTTP answer, 3 done

static void onHttpAccess(bool allowed, void* ud)
{
	(void)ud;
	dlog("http access callback: %s", allowed ? "allowed" : "denied");
	state = allowed ? STREAM_IDLE : STREAM_DENIED;
	asking = 3;
}

static void askHttp(void)
{
	asking = 2;
	enum accessReply r = pd->network->http->requestAccess(NULL, 0, false, "to find radio stations", onHttpAccess, NULL);
	dlog("http requestAccess -> %d (0 ask, 1 deny, 2 allow)", r);
	if (r == kAccessAllow) { state = STREAM_IDLE; asking = 3; }
	else if (r == kAccessDeny) { state = STREAM_DENIED; asking = 3; }
}

static void onAccess(bool allowed, void* ud)
{
	(void)ud;
	dlog("tcp access callback: %s", allowed ? "allowed" : "denied");
	if (!allowed) { state = STREAM_DENIED; asking = 3; return; }
	askHttp();
}

static void requestAccess(void)
{
	if (asking != 0) return;
	asking = 1;
	// NULL server + port 0 = permission for any server and port, asked once. The stations come from many servers, so
	// asking per server would mean a new prompt on almost every station.
	enum accessReply r = tcp->requestAccess(NULL, 0, false, "to play internet radio stations", onAccess, NULL);
	dlog("tcp requestAccess -> %d (0 ask, 1 deny, 2 allow)", r);
	if (r == kAccessAllow) askHttp();
	else if (r == kAccessDeny) { state = STREAM_DENIED; asking = 3; }
}

void stream_tune(const Station* station)
{
	if (station == wanted) return;   // same station: stream_update handles retries
	wanted = station;
	if (state == STREAM_NEED_ACCESS || state == STREAM_DENIED) return;
	if (station == NULL) {
		closeConnection();
		state = STREAM_IDLE;
	} else {
		openStation(station);
	}
}

/**
 * Called when the audio ran low or dry while playing, i.e. the Wi-Fi isn't keeping
 * up. Grows the buffer target one step (at most once per ESCALATE_GAP_MS, so a
 * single dip doesn't jump straight to the maximum).
 */
static void wifiTrouble(unsigned int now, const char* why)
{
	lastTroubleAt = now;
	if (targetSeconds >= MAX_TARGET || now - lastEscalateAt < ESCALATE_GAP_MS) return;
	lastEscalateAt = now;
	targetSeconds += TARGET_STEP;
	if (targetSeconds > MAX_TARGET) targetSeconds = MAX_TARGET;
	dlog("wi-fi trouble (%s): buffer target now %.0fs", why, (double)targetSeconds);
}

void stream_update(void)
{
	tendParking();
	if (state == STREAM_NEED_ACCESS) requestAccess();
	if (state == STREAM_NEED_ACCESS || state == STREAM_DENIED) return;

	if (state == STREAM_ERROR || state == STREAM_IDLE) {
		if (wanted != NULL && (state == STREAM_IDLE
			|| pd->system->getCurrentTimeMilliseconds() >= retryAt))
			openStation(wanted);
		return;
	}
	if (conn == NULL) return;

	if (pendingOpen < 0) {
		unsigned int took = pd->system->getCurrentTimeMilliseconds() - openedAt;
		dlog("could not connect (%d) after %u ms", pendingOpen, took);
		if (took < QUICK_FAIL_MS) {
			// The Playdate refused before the server was ever asked: not the station's fault (see QUICK_FAIL_MS).
			// On 2026-11-13 counting these dropped KEXP, 181.FM and K-Dot, all of which had just played fine.
			fail();
			retryAt = pd->system->getCurrentTimeMilliseconds() + BUSY_RETRY_MS;
			return;
		}
		noteSilence();
		fail();
		return;
	}
	if (pendingOpen == 0 && pd->system->getCurrentTimeMilliseconds() - openedAt > (hopSecure ? CONNECT_GIVEUP_TLS_MS : CONNECT_GIVEUP_MS)) {
		dlog("no answer from %s:%d", hopHost, hopPort);
		noteSilence();
		fail();
		return;
	}
	if (pendingOpen == 1 && !requestSent) {
		if (!sendRequest()) { fail(); return; }
		requestSent = 1;
	}
	if (requestSent && !headerDone) {
		if (readHeader() < 0) return;
	}

	// Network -> decoder input (ICY metadata blocks stripped in place)
	if (headerDone) {
		size_t avail = tcp->getBytesAvailable(conn);
		while (avail > 0) {
			int space;
			uint8_t* dst = decoder_input(dec, &space);
			if (space <= 0) break;
			int n = tcp->read(conn, dst, avail < (size_t)space ? avail : (size_t)space);
			if (n <= 0) break;
			bytesRead += n;
			decoder_commit(dec, icy_filter(&icy, dst, n));
			avail = tcp->getBytesAvailable(conn);
		}
	}

	static int loggedTitle;
	if (icy.titleVersion != loggedTitle) {
		loggedTitle = icy.titleVersion;
		if (icy.title[0] != '\0') {
			dlog("title: %s", icy.title);
			// Remember the song before this one for the info panel ("earlier: ..."). Stations repeat the same title
			// now and then, so only a real change counts.
			if (strcmp(icy.title, lastTitle) != 0) {
				if (lastTitle[0] != '\0') snprintf(prevTitle, sizeof prevTitle, "%s", lastTitle);
				snprintf(lastTitle, sizeof lastTitle, "%s", icy.title);
			}
		}
	}

	// Decoder -> PCM ring, up to the target buffer
	int rate = decoder_sample_rate(dec);
	if (rate == 0 || stream_buffered_seconds() < targetSeconds)
		framesDecoded += decoder_run(dec, &gAudio.ring, FRAMES_PER_UPDATE);
	rate = decoder_sample_rate(dec);
	gAudio.srcRate = rate;

	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	if (now >= statsAt) {
		statsAt = now + 1000;
		dlog("state %d bytes %d frames %d buffered %.2fs target %.0fs underruns %d",
			state, bytesRead, framesDecoded, (double)stream_buffered_seconds(),
			(double)targetSeconds, gAudio.underruns);
	}

	if (pendingClosed && tcp->getBytesAvailable(conn) == 0) {
		dlog("connection closed by the server (err %d, bytes %d)", tcp->getError(conn), bytesRead);
		fail();
		return;
	}

	// A server that answers 200 but sends nothing we can decode (another format, a web page) would otherwise sit at
	// "tuning" forever; give up and let the 3 s retry timer try again.
	if ((state == STREAM_CONNECTING || state == STREAM_BUFFERING) && framesDecoded == 0 && now - openedAt > NO_AUDIO_MS) {
		dlog("no decodable audio after %d bytes", bytesRead);
		if (bytesRead == 0) noteSilence();
		fail();
		return;
	}

	if (framesDecoded > 0 && current == silentStation) { silentStation = NULL; silentTries = 0; }

	float buffered = stream_buffered_seconds();
	// How much to have before (re)starting playback: a little more once the buffer
	// has been boosted, and after a dry-out a good part of the target, so the
	// stream doesn't stutter straight back into silence.
	float startNeeded = rebuffering ? 0.6f * targetSeconds
		: START_SECONDS + 0.4f * (targetSeconds - BASE_TARGET);
	if (state == STREAM_BUFFERING && rate > 0 && buffered >= startNeeded) {
		state = STREAM_PLAYING;
		rebuffering = 0;
		gAudio.playing = 1;
	} else if (state == STREAM_PLAYING && buffered < 0.05f) {
		state = STREAM_BUFFERING;   // ran dry: static covers it until we refill
		gAudio.playing = 0;
		rebuffering = 1;
		wifiTrouble(now, "ran dry");
	} else if (state == STREAM_PLAYING) {
		if (buffered < LOW_WATER) wifiTrouble(now, "running low");
		else if (targetSeconds > BASE_TARGET && now - lastTroubleAt > CALM_MS) {
			targetSeconds -= 1.0f;               // calm for a long while: ease back
			if (targetSeconds < BASE_TARGET) targetSeconds = BASE_TARGET;
			lastTroubleAt = now;
			dlog("wi-fi calm: buffer target back to %.0fs", (double)targetSeconds);
		}
	}
}

StreamState stream_state(void) { return state; }

/** 1 once the player has allowed network access (the directory waits for this before fetching). */
int stream_has_access(void) { return state != STREAM_NEED_ACCESS && state != STREAM_DENIED; }

const Station* stream_take_dead(void)
{
	const Station* s = deadStation;
	deadStation = NULL;
	return s;
}

int stream_rebuffering(void) { return rebuffering; }

float stream_buffered_seconds(void)
{
	int rate = decoder_sample_rate(dec);
	return rate > 0 ? (float)ring_count(&gAudio.ring) / (float)rate : 0.0f;
}

int stream_bitrate(void) { return decoder_bitrate(dec); }

const char* stream_title(void) { return icy.title; }
/** The song that played before the current one on this station ("" if none yet since tuning in). */
const char* stream_previous_title(void) { return prevTitle; }
