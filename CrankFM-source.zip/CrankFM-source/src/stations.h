// Stations and bands, held in memory at run time.
//
// The first Crank FM had one fixed list (six bands of six SomaFM channels on one server). The directory edition fills its
// bands from the internet instead, so a station now carries its own server, port and path, and a band can hold from zero to
// MAX_PER_BAND stations. Both editions use these same types: stations_soma.c fills them from a fixed table, directory.c from
// Radio Browser.
#ifndef STATIONS_H
#define STATIONS_H

#include "edition.h"

#define MAX_BANDS 8          // seven genre bands, plus your saved stations (saved.c) when you have any
#define MAX_PER_BAND 6       // six names fit in one row across the dial (ten in two rows was too crowded to read)
#define SPARES_PER_BAND 6    // backups kept out of sight: when a station turns out dead, the next spare takes its place
#define DIAL_MIN 88.0f
#define DIAL_MAX 108.0f

typedef struct {
	char name[24];    // short label for the dial (the dial trims it further to fit; was 14, which cut "Venice Classic" to "Venice Classi")
	char title[48];   // full name, shown on the label plate
	char host[64];    // stream server, no "http://"
	int port;
	char secure;      // 1 = https (an encrypted connection; see HTTPS_STREAMS in edition.h)
	char path[160];   // path on that server, starting with "/"
	char uuid[40];    // Radio Browser's id for the station ("" when it did not come from the directory)
	int bitrate;      // kbps the directory reports (0 = unknown)
	char tags[40];    // what it plays, for the info panel: "hip hop, rap, r&b" (directory tags, tidied; "" = unknown)
	char country[28]; // where it broadcasts from: "Italy" ("" = unknown)
} Station;

typedef struct {
	char name[10];    // the preset key's label
	int count;        // stations in use, 0..MAX_PER_BAND
	Station st[MAX_PER_BAND];
	int spares;       // backups in spare[], best first (directory edition only; always 0 for SomaFM)
	Station spare[SPARES_PER_BAND];
} Band;

extern Band gBands[MAX_BANDS];
extern int gBandCount;
extern int gStationsVersion;   // goes up whenever any band's list changes, so main.c knows to retune

float station_freq(int index, int count);
int station_set_url(Station* s, const char* url);
int url_split(const char* url, char* host, int hostCap, int* port, char* path, int pathCap, int* secure);
void station_url(const Station* s, char* out, int cap);
int station_set_title(Station* s, const char* title);
int station_same(const Station* a, const Station* b);
int drawable_text(const char* src, char* dst, int cap);

void soma_init(void);   // personal edition only (stations_soma.c)

#endif
