// Crank FM: tune internet radio with the crank. The screen is the front of a tabletop radio: dial window, station info
// panel, label plate, preset keys. Two editions share this file (edition.h): the personal one plays SomaFM's channels,
// the public one plays stations from the Radio Browser directory sorted into seven genre bands.
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pd_api.h"
#include "audio.h"
#include "stream.h"
#include "stations.h"
#include "directory.h"
#include "saved.h"

#define SCREEN_DUMP 0        // 1: write the screen to screen.pbm every 3s (debug)
#define CLIP_CAPTURE 0       // 1: once the music has played for a few seconds, save 300 frames as cap_0000.pbm... (for the website's looping clip). Never ship with 1.
#define DEBUG_AUTO_B 0       // 1: press B every 6s (station-switch soak test; Simulator builds ignore make UDEFS)

// Tuning feel
#define MHZ_PER_REV 4.0f     // one crank turn sweeps 4 MHz (5 turns end to end)
#define CAPTURE 0.6f         // MHz: a station starts breaking through the static
#define DWELL_MS 250         // stay near a station this long before connecting
#define DROP_MS 2000         // keep the connection this long after tuning away
#define SAVE_DELAY_MS 1500   // save settings once they've stopped changing
#define MARQUEE_SPEED 30.0f  // px/s for song titles too wide to fit
#define MARQUEE_HOLD 1.5f    // seconds a long station name waits before it starts to scroll
#define HINT_SECONDS 6.0f    // controls card on first launch
#define SPLASH_SECONDS 2.0f  // the launch screen stays up at least this long
#define TOAST_SECONDS 1.6f   // how long a short message under the dial stays on screen
#define CLICK_AFTER_MS 10000 // a station counts as listened to (for the directory's statistics) after this long

// Layout: cabinet, dial window (top), grille (left), label plate (right), preset keys (bottom)
#define WIN_X 16
#define WIN_Y 14
#define WIN_W 368
#define WIN_H 80
#define SCALE_X0 (WIN_X + 16)
#define SCALE_X1 (WIN_X + WIN_W - 16)
#define SCALE_Y (WIN_Y + 50)
#define INFO_X 16            // station info panel (it replaced the speaker grille on 2026-11-11)
#define INFO_Y 110
#define INFO_W 156
#define INFO_H 90
#define PLATE_X 182
#define PLATE_Y 110
#define PLATE_W 202
#define PLATE_H 90
#define KEYS_X 16
#define KEYS_Y 207
#define KEYS_W 368
#define KEYS_H 22
#define KEY_GAP 4

#define SETTINGS_FILE "settings.txt"

static PlaydateAPI* pd;
static LCDFont* font;        // Asheville Sans 14 Bold
static LCDFont* small;       // Roobert 10 Bold
static LCDFont* light;       // Asheville Sans 14 Light: has the button glyphs (Ⓐ ⬅️ ...)
static LCDBitmap* cabinet;   // everything that never moves, drawn once
static LCDBitmap* splash;    // launcher/launchImage (Boraq), shown at startup
static float splashTimer = SPLASH_SECONDS;

static int band;
static float freq = 89.5f;
static float seekTarget = -1.0f;
static const Station* candidate;
static unsigned int candidateSince;
static float quality;        // 0..1 how well tuned the nearest station is
static float marquee;        // the song title's scroll position (px)
static float titleScroll;    // the station name's scroll position (px; negative = still waiting to start)
static unsigned int dirtySince;   // 0 = settings saved
static int hintsSeen;
static int aboutSeen;        // the credits card has been shown once (saved)
static float hintTimer;
static int regionSaved;      // directory edition: the region index from settings.txt
static char toast[64];       // short message under the dial ("that station can't play here"...)
static float toastTimer;
static int seenVersion = -1; // gStationsVersion last tuned against

// Animated parts
static float sigLevel;                     // smoothed signal strength for the bars
static float pulse;                        // how loud the music is right now, smoothed (0..50): drives the beat meter and lamp
static float beatClock;                    // seconds, for the beat meter's bars to move out of step with each other

static LCDPattern kGlow50 = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   // black where opaque
	0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55,   // mask: checkerboard
};
static LCDPattern kGlow25 = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x88, 0x00, 0x22, 0x00, 0x88, 0x00, 0x22, 0x00,
};

static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float rad(float deg) { return deg * 3.14159265f / 180.0f; }

// ---- the dial is a circle (2026-11-18, the user's idea: "make the dial movable to the left and right... a circle that rotates")
// 88 and 108 MHz meet, like the two ends of a drum: cranking past 108 comes round to 88 again. Every distance on the dial is
// therefore measured the short way round the circle.
#define DIAL_SPAN (DIAL_MAX - DIAL_MIN)   // 20 MHz all the way round

/** Brings any frequency back onto the dial (88.0 up to, but not including, 108.0). */
static float wrapFreq(float f)
{
	while (f < DIAL_MIN) f += DIAL_SPAN;
	while (f >= DIAL_MAX) f -= DIAL_SPAN;
	return f;
}

/** How far `to` lies from `from` going the short way round: positive = higher up the dial (to the right), -10..10 MHz. */
static float dialDelta(float from, float to)
{
	float d = to - from;
	while (d > DIAL_SPAN * 0.5f) d -= DIAL_SPAN;
	while (d <= -DIAL_SPAN * 0.5f) d += DIAL_SPAN;
	return d;
}

// ---- settings ----

// Dark mode (the user's idea, 2026-11-11). The Playdate's screen has only black and white, so dark mode is the whole
// display inverted by the system (display->setInverted): white lines on black, and every dither pattern flips with it, so
// nothing has to be drawn twice. Saved as dark= in settings.txt.
static int darkMode;
static PDMenuItem* darkItem;
static void applyDark(void) { pd->display->setInverted(darkMode); }
static void markDirty(void);
/** System menu -> "dark" checkbox. */
static void onDark(void* ud)
{
	(void)ud;
	darkMode = pd->system->getMenuItemValue(darkItem);
	applyDark();
	markDirty();
}

static void loadSettings(void)
{
	SDFile* f = pd->file->open(SETTINGS_FILE, kFileReadData);
	if (f == NULL) return;
	char buf[128];
	int n = pd->file->read(f, buf, sizeof buf - 1);
	pd->file->close(f);
	if (n <= 0) return;
	buf[n] = '\0';
	int b = 0, hints = 0, about = 0, region = 0, dark = 0;
	float fr = freq, vol = gAudio.volume;
	// hints=, about= and region= are optional, so settings files from older builds still load. The band is checked against
	// the real number of bands later, once the stations are loaded (eventHandler).
	if (sscanf(buf, "band=%d freq=%f volume=%f hints=%d about=%d region=%d dark=%d",
			&b, &fr, &vol, &hints, &about, &region, &dark) >= 3) {
		darkMode = dark != 0;
		band = b >= 0 && b < MAX_BANDS ? b : 0;
		regionSaved = region;
		freq = wrapFreq(clampf(fr, DIAL_MIN, DIAL_MAX));
		gAudio.volume = clampf(vol, 0.0f, 1.0f);
		hintsSeen = hints;
		aboutSeen = about;
	}
}

static void saveSettings(void)
{
	SDFile* f = pd->file->open(SETTINGS_FILE, kFileWrite);
	if (f == NULL) return;
	char buf[128];
	int n = snprintf(buf, sizeof buf, "band=%d freq=%.2f volume=%.2f hints=%d about=%d region=%d dark=%d\n",
		band, (double)freq, (double)gAudio.volume, hintsSeen, aboutSeen, directory_region(), darkMode);
	pd->file->write(f, buf, (unsigned int)n);
	pd->file->close(f);
	dirtySince = 0;
}

static void markDirty(void)
{
	dirtySince = pd->system->getCurrentTimeMilliseconds();
	if (dirtySince == 0) dirtySince = 1;
}

/**
 * Headphone plug/unplug callback. Registering a callback turns off the system's
 * automatic speaker/headphone switching, so we redo it by hand: headphones in means
 * headphones only, out means speaker. The audio callback reads gAudio.headphones to
 * decide between real stereo (headphones) and a mono fold-down (the mono speaker).
 * (Never pass NULL here: the device may call the callback even when it is NULL.)
 */
static void onHeadphones(int headphone, int mic)
{
	(void)mic;
	gAudio.headphones = headphone;
	pd->sound->setOutputsActive(headphone, !headphone);
	dlog("headphones %s", headphone ? "in: stereo" : "out: mono speaker");
}

static void setupHeadphones(void)
{
	int hp = 0, mic = 0;
	pd->sound->getHeadphoneState(&hp, &mic, onHeadphones);
	onHeadphones(hp, mic);   // apply the state we start in
}


// The system menu's "region" option: which country's stations fill the genre bands ("world" = anywhere).
static PDMenuItem* regionItem;
static void showToast(const char* text);   // defined below
// Full country names for the messages under the dial (the menu itself can only fit the short codes). Same order as
// kRegionNames in directory.c.
static const char* const kRegionLong[] = { "the world", "the United States", "the United Kingdom", "Canada", "Australia", "Germany", "France",
	"Italy", "Spain", "the Netherlands", "Poland", "Turkey", "India", "Japan", "Brazil", "Mexico", "Argentina",
	"Arabic", "Japanese", "Hindi" };
#define FIRST_LANGUAGE 17   // from here on the choices are languages, not countries (directory.c)
static int regionChanging;   // 1 from picking a region in the menu until its stations are in

/** System menu -> region: fetch that country's stations, and say so on screen (the change takes several seconds). */
static void onRegion(void* ud)
{
	(void)ud;
	int r = pd->system->getMenuItemValue(regionItem);
	if (r == directory_region()) return;
	directory_set_region(r);
	regionChanging = 1;
	markDirty();
}

/**
 * Keeps the message under the dial up to date after a region change: "finding stations n/6" while the bands are fetched,
 * then how many of the new stations really come from that country (many countries tag few stations with a genre, so the
 * rest of each band is filled from around the world, and the player should know why the dial looks familiar).
 */
static void regionMessages(void)
{
	if (!regionChanging) return;
	int r = directory_region();
	const char* where = r >= 0 && r < (int)(sizeof kRegionLong / sizeof kRegionLong[0]) ? kRegionLong[r] : "there";
	char line[64];
	if (directory_offline() && !directory_busy()) {   // could not reach the directory: say so instead of "finding..."
		regionChanging = 0;
		showToast("can't reach stations right now");
		return;
	}
	if (directory_busy() || directory_local_count() < 0) {
		// The menu can only show short codes ("UK"), so the full name is spelled out here while the search runs.
		const char* name = r >= 0 && r < (int)(sizeof kRegionLong / sizeof kRegionLong[0]) ? kRegionLong[r] : "";
		if (strncmp(name, "the ", 4) == 0) name += 4;
		const char* what = directory_fetching() != NULL ? directory_fetching() : "";
		if (r == 0) snprintf(line, sizeof line, "finding %s stations", what);
		else snprintf(line, sizeof line, "%s: finding %s stations", name, what);
		showToast(line);
		return;
	}
	regionChanging = 0;
	int n = directory_local_count();
	if (r == 0) snprintf(line, sizeof line, "stations from the world");
	else if (r >= FIRST_LANGUAGE) { if (n > 0) snprintf(line, sizeof line, "%d stations in %s", n, where); else snprintf(line, sizeof line, "none found in %s", where); }
	else if (n == 0) snprintf(line, sizeof line, "none from %s, world mix", where);
	else snprintf(line, sizeof line, "%d stations from %s", n, where);
	showToast(line);
	toastTimer = 4.0f;   // longer than the usual toast: this one is worth reading
}

// The credits card. It opens by itself on the very first launch, and any time
// from the system menu -> "about". Unlike the controls card it stays up until a
// button is pressed, because people read credits at their own pace.
static int aboutOpen;
static int controlsAfterAbout;   // first launch: show the controls card once credits close
static void showAbout(void* ud) { (void)ud; aboutOpen = 1; hintTimer = 0.0f; }
/** System menu -> "help": the credits card, then the controls card (one item for both, to leave a menu slot for "dark"). */
static void showHelp(void* ud) { showAbout(ud); controlsAfterAbout = 1; }

/**
 * Closes the credits card. The first time, this also remembers that it has been
 * seen (so it never pops up again on its own) and hands over to the controls
 * card if that is also still unseen: the two cards would otherwise overlap.
 */
static void closeAbout(void)
{
	aboutOpen = 0;
	if (!aboutSeen) { aboutSeen = 1; markDirty(); }
	if (controlsAfterAbout) { controlsAfterAbout = 0; hintTimer = HINT_SECONDS; }
}

// ---- tuning ----

/**
 * The station of the current band closest to frequency `f`, and how far away it is (in MHz). Returns -1 (and a huge
 * distance, so nothing tunes in) when the band is empty, e.g. a genre band still loading.
 */
static int nearestStation(float f, float* dist)
{
	const Band* b = &gBands[band];
	*dist = 99.0f;
	if (b->count == 0) return -1;
	int best = 0;
	for (int i = 1; i < b->count; i++)
		if (fabsf(dialDelta(f, station_freq(i, b->count))) < fabsf(dialDelta(f, station_freq(best, b->count)))) best = i;
	*dist = fabsf(dialDelta(f, station_freq(best, b->count)));
	return best;
}

static void showToast(const char* text)
{
	snprintf(toast, sizeof toast, "%s", text);
	toastTimer = TOAST_SECONDS;
}

// ---- how the dial moves (2026-11-18, the user: "make the movement more smooth and satisfying")
// FLICK: a fast spin of the crank keeps the drum turning for a moment after the hand stops, slowing like a heavy wheel.
// MAGNET: once the dial rests within reach of a station, the needle glides onto it (the old Ⓐ fine-tune, done for you).
// EASED SEEK: ⬅️/➡️ (and the magnet) move fast at first and slow down as they arrive, instead of at one fixed speed.
// DETENT: a soft click each time a station's mark passes under the needle, like the notches of a real tuning wheel.
#define FLICK_MIN 5.0f        // MHz/s: a spin at least this fast (about 1.25 crank turns a second) carries on by itself
#define FLICK_FRICTION 3.2f   // how quickly a flick dies away (per second; 3.2 = most of it is gone in about half a second)
#define FLICK_STOP 0.4f       // MHz/s: slower than this the drum stops
#define IDLE_GRACE 0.07f      // s: a frame or two without crank movement does not yet count as letting go
#define MAGNET_AFTER 0.35f    // s of rest before the magnet pulls the needle onto a nearby station
#define MAGNET_REACH 1.2f     // MHz: how far the magnet reaches (stations are ~3.4 apart, so only the middle ~1 MHz between two
                              // stays on static; it was 0.6 = the hearing range, which left the needle stuck in static, 2026-11-18)
// The seek (⬅️/➡️ and the magnet) follows a timed ease-in-out curve: it gathers speed gently, glides, and lands softly
// exactly on the station, instead of starting at full speed the moment the button is pressed (2026-11-18, the user: make
// the D-pad smoother). The curve is a cubic Hermite: it starts at the dial's current speed (so a second press mid-move
// carries on without a hitch) and ends at speed 0. A spring was tried first, but it crept over the last 0.1 MHz for half a
// second. Duration: 0.22 s + 0.11 s per MHz (0.25-0.7 s): a hop to the next station (~3.4 MHz) takes about 0.6 s.
static float seekVel;         // MHz/s, the seek's current speed
static float seekFrom, seekDist, seekDur, seekT, seekV0, seekAim = -1.0f;   // the move in progress (seekAim = its target)
// Ⓐ saves the station under the needle, or removes it if it is saved already (2026-11-19, saved.c). From 2026-11-18 to
// 11-19 it switched the radio off and on; before that it fine-tuned, which the magnet now does by itself.
static float crankVel;        // MHz/s, the crank's recent speed (smoothed)
static float flickVel;        // MHz/s, the drum's own spin after a flick (0 = none)
static float crankIdle;       // s since the crank last moved

static PDSynth* detentSynth;
/** A short, quiet tick (a square wave a few milliseconds long), played when a station's mark crosses the needle. */
static void detentClick(void)
{
	if (detentSynth == NULL) {
		detentSynth = pd->sound->synth->newSynth();
		pd->sound->synth->setWaveform(detentSynth, kWaveformSquare);
		pd->sound->synth->setAttackTime(detentSynth, 0.0f);
		pd->sound->synth->setDecayTime(detentSynth, 0.025f);
		pd->sound->synth->setSustainLevel(detentSynth, 0.0f);
		pd->sound->synth->setReleaseTime(detentSynth, 0.01f);
	}
	pd->sound->synth->playNote(detentSynth, 1900.0f, 0.12f + 0.2f * gAudio.volume, 0.02f, 0);
}

/** Plays the detent click if the move from `from` to `to` carried a station's mark across the needle. */
static void detentCheck(float from, float to)
{
	const Band* b = &gBands[band];
	for (int i = 0; i < b->count; i++) {
		float f = station_freq(i, b->count);
		float a = dialDelta(from, f), c = dialDelta(to, f);
		// opposite sides before and after, and close by (so the far side of the circle, where the sign also flips, is ignored)
		if (((a > 0.0f && c <= 0.0f) || (a < 0.0f && c >= 0.0f)) && fabsf(a) < 3.0f && fabsf(c) < 3.0f) { detentClick(); return; }
	}
}

/**
 * Ⓐ: saves the station under the needle, or removes it if it is saved already. `near`/`dist` are the nearest station of
 * the current band and how far the needle is from it; "under the needle" means close enough to be heard (CAPTURE).
 */
static void toggleSaved(int near, float dist)
{
	if (near < 0 || dist > CAPTURE) { showToast("tune to a station first"); return; }
	Station st = gBands[band].st[near];   // a copy: saving or removing changes the saved band's own array
	int r = saved_toggle(&st);
	if (r < 0) { showToast("saved is full: remove one first"); return; }
	detentClick();
	showToast(r ? "saved" : "removed from saved");
	// removing the last saved station while listening on the saved band: that band is gone, so step back to the first
	if (band >= gBandCount) band = 0;
	markDirty();
}

/**
 * A small heart, the sign for "saved". `big` 0 = 5x4 px (on the dial, in place of a station's mark), 1 = 7x6 px (the
 * saved band's key). (cx, top) = its middle column and top row. Drawn in `color` (black, or white on a filled key).
 */
static void drawHeart(int cx, int top, int big, LCDColor color)
{
	static const char* const small5[] = { "XX.XX", "XXXXX", ".XXX.", "..X.." };
	static const char* const big7[] = { ".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..." };
	const char* const* rows = big ? big7 : small5;
	int n = big ? 6 : 4, half = big ? 3 : 2;
	for (int r = 0; r < n; r++)
		for (int c = 0; rows[r][c] != '\0'; c++)
			if (rows[r][c] == 'X') pd->graphics->fillRect(cx - half + c, top + r, 1, 1, color);
}

static void handleInput(float dt)
{
	PDButtons current, pushed, released;
	pd->system->getButtonState(&current, &pushed, &released);
	float before = freq, volBefore = gAudio.volume;

	if (pushed && aboutOpen) {              // any button closes the credits card
		closeAbout();
		pushed = 0;
	}
	if (pushed && hintTimer > 0.0f) {       // any button dismisses the controls card
		hintTimer = 0.0f;
		pushed = 0;
	}

	float crank = pd->system->getCrankChange();
	float turned = crank / 360.0f * MHZ_PER_REV;
	if (crank != 0.0f) {
		seekTarget = -1.0f;                    // the hand on the dial wins
		seekVel = 0.0f;
		seekAim = -1.0f;
		flickVel = 0.0f;
		crankIdle = 0.0f;
		if (dt > 0.0f) crankVel = crankVel * 0.6f + (turned / dt) * 0.4f;
		freq += turned;
	} else {
		crankIdle += dt;
		// letting go of a fast spin hands its speed to the drum (only once: crankVel is cleared)
		if (crankIdle > IDLE_GRACE && crankVel != 0.0f) {
			if (fabsf(crankVel) >= FLICK_MIN) flickVel = crankVel;
			crankVel = 0.0f;
		}
	}
	if (flickVel != 0.0f) {
		freq += flickVel * dt;
		flickVel *= expf(-FLICK_FRICTION * dt);
		if (fabsf(flickVel) < FLICK_STOP) flickVel = 0.0f;
	}

	float dist;
	int near = nearestStation(freq, &dist);
	int count = gBands[band].count;
	// seek to the next station round the circle: after the last one comes the first again (and the other way)
	if (pushed & (kButtonRight | kButtonLeft)) {
		int dir = (pushed & kButtonRight) ? 1 : -1;
		flickVel = 0.0f;
		float from = seekTarget >= 0.0f ? seekTarget : freq;   // a second press while seeking goes one station further
		float bestD = 99.0f;
		for (int i = 0; i < count; i++) {
			float d = dialDelta(from, station_freq(i, count)) * (float)dir;
			if (d <= 0.05f) d += DIAL_SPAN;                     // behind us: reached by going on round
			if (d < bestD) { bestD = d; seekTarget = station_freq(i, count); }
		}
	}
	if (pushed & kButtonA) toggleSaved(near, dist);
#if DEBUG_AUTO_B
	{ static float t; t += dt; if (t > 6.0f) { t = 0.0f; pushed |= kButtonB; } }
#endif
	if (pushed & kButtonB) { band = (band + 1) % gBandCount; seekTarget = -1.0f; seekVel = 0.0f; seekAim = -1.0f; markDirty(); }

	// the magnet: resting near (but not exactly on) a station glides onto it
	if (seekTarget < 0.0f && flickVel == 0.0f && crankIdle > MAGNET_AFTER) {
		float dist2;
		int near2 = nearestStation(freq, &dist2);
		if (near2 >= 0 && dist2 < MAGNET_REACH && dist2 > 0.02f) seekTarget = station_freq(near2, count);
	}

	if (seekTarget >= 0.0f) {
		float d = dialDelta(freq, seekTarget);
		if (seekTarget != seekAim) {             // a new destination: plan the move from here, keeping the current speed
			seekAim = seekTarget;
			seekFrom = freq;
			seekDist = d;
			seekDur = clampf(0.22f + 0.11f * fabsf(d), 0.25f, 0.7f);
			seekT = 0.0f;
			seekV0 = seekVel;
		}
		seekT += dt;
		float u = clampf(seekT / seekDur, 0.0f, 1.0f), T = seekDur;
		// Hermite: position = h10(u) * startSpeed * T + h01(u) * distance; speed is its derivative
		float h10 = u * u * u - 2.0f * u * u + u, h01 = -2.0f * u * u * u + 3.0f * u * u;
		float d10 = 3.0f * u * u - 4.0f * u + 1.0f, d01 = -6.0f * u * u + 6.0f * u;
		freq = seekFrom + h10 * seekV0 * T + h01 * seekDist;
		seekVel = d10 * seekV0 + d01 * seekDist / T;
		if (u >= 1.0f) { freq = seekTarget; seekTarget = -1.0f; seekAim = -1.0f; seekVel = 0.0f; }
	}
	freq = wrapFreq(freq);
	detentCheck(before, freq);

	// Holding up/down moves the volume at 0.5 of the slider per second (2 s end to end): slow enough to stop where you
	// want. The audio itself follows on a curve and glides there (audio.c), so it never jumps.
	if (current & kButtonUp) gAudio.volume = clampf(gAudio.volume + dt * 0.5f, 0.0f, 1.0f);
	if (current & kButtonDown) gAudio.volume = clampf(gAudio.volume - dt * 0.5f, 0.0f, 1.0f);

	if (freq != before || gAudio.volume != volBefore) markDirty();
}

static const Station* playingStation;   // the station heard right now (for the directory's listen count)
static unsigned int playingSince;
static int playReported;

/**
 * Connect when the dial settles near a station; disconnect a while after leaving.
 *
 * Stations are compared by address in memory (a Station*). When the directory replaces a band's list, the same address can
 * suddenly hold a different station, so on a new gStationsVersion we drop the stream and tune again from scratch.
 */
static void manageStream(const Station* near, float dist)
{
	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	static Station tunedCopy;   // what the stream was last asked to play (by value: the slot may change under us)
	if (gStationsVersion != seenVersion) {
		seenVersion = gStationsVersion;
		// Keep playing if the needle is still on the very same stream: closing a connection and opening a new one at once
		// stalled the next connection for many seconds in testing, so we avoid it when nothing really changed.
		int same = candidate != NULL && near == candidate && dist < CAPTURE && station_same(near, &tunedCopy);
		if (!same) {
			stream_tune(NULL);
			candidate = NULL;
			candidateSince = now;
			playingStation = NULL;
		}
	}
	const Station* want = near != NULL && dist < CAPTURE ? near : NULL;
	// While the directory is searching (a region change, or the weekly refresh), the music waits. On the device the Wi-Fi
	// only just carries one stream (about 18 KB/s for 16 KB/s of music), so a search running beside it starved and timed
	// out again and again (TR, IT and FR in the device log of 2026-11-13), and the Playdate refused new connections while
	// both ran. The plate says "finding stations n/7" meanwhile, and the station list changes when it ends anyway.
	// If the directory can't be reached at all (offline after 4 failed tries), the stations we already have play again.
	if (directory_busy() && !directory_offline()) {
		// Stop the music at once (not after the usual DROP_MS): the fetch waits for the line to be quiet, so every
		// moment the old stream stays open is a moment longer before the new band's stations arrive.
		want = NULL;
		candidate = NULL;
		candidateSince = now;
		stream_tune(NULL);
	}
	if (want != candidate) { candidate = want; candidateSince = now; }
	if (now - candidateSince >= (candidate != NULL ? DWELL_MS : DROP_MS)) {
		stream_tune(candidate);
		if (candidate != NULL) tunedCopy = *candidate;
	}
	stream_update();

	// A station that can never play here (it forwards to an https address) is taken off its band, so the dial does not
	// keep a station that only ever gives static. Directory edition only: the personal list is fixed.
	const Station* dead = stream_take_dead();
	if (dead != NULL && directory_drop(dead)) showToast("that station can't play here");

	// Tell the directory once per listen that a station was played for a while (its API asks apps to do this).
	const Station* heard = stream_state() == STREAM_PLAYING ? candidate : NULL;
	if (heard != playingStation) { playingStation = heard; playingSince = now; playReported = 0; }
	if (heard != NULL && !playReported && now - playingSince >= CLICK_AFTER_MS) {
		playReported = 1;
		directory_played(heard);
	}
}

/**
 * Sets what the audio callback should mix, from how close the needle is to a station (`dist`, in MHz).
 *
 * When a station starts playing, its sound fades in over FADE_IN_SECONDS instead of arriving all at once, and the static
 * fades out with it: a real radio "comes in" as it warms up, and a sudden full-volume song felt in your face. When the
 * stream stops, the fade starts again from zero next time.
 */
#define FADE_IN_SECONDS 1.5f
static float fadeIn;   // 0..1: how far the current station's fade-in has got
static void updateAudioTargets(float dist, float dt)
{
	float q = clampf(1.0f - dist / CAPTURE, 0.0f, 1.0f);
	q = q * q * (3.0f - 2.0f * q);                 // smoothstep: flat and clear near the centre
	quality = q;
	if (stream_state() == STREAM_PLAYING) fadeIn = clampf(fadeIn + dt / FADE_IN_SECONDS, 0.0f, 1.0f);
	else fadeIn = 0.0f;
	float ease = fadeIn * fadeIn * (3.0f - 2.0f * fadeIn);   // smoothstep: starts and ends gently
	float heard = q * ease;

	gAudio.stationGain = heard;
	gAudio.noiseGain = 1.0f - 0.93f * heard;   // a whisper of hiss even when locked
	gAudio.muffle = 0.9f * (1.0f - q);
	gAudio.warble = 0.03f * (1.0f - q);
}

static void animate(float dt)
{
	float target = quality * (stream_state() == STREAM_PLAYING ? 1.0f : 0.35f);
	sigLevel += (target - sigLevel) * clampf(8.0f * dt, 0.0f, 1.0f);

	float level = stream_state() == STREAM_PLAYING ? gAudio.level : 0.0f;
	float r = clampf(level * 1.8f, 0.0f, 1.0f) * 50.0f;
	pulse += (r - pulse) * (r > pulse ? 0.6f : 0.15f);   // fast attack, slow release
	beatClock += dt;
}

// ---- drawing helpers ----

static int textWidth(LCDFont* f, const char* s)
{
	return pd->graphics->getTextWidth(f, s, strlen(s), kUTF8Encoding, 0);
}

static void text(const char* s, int x, int y)
{
	pd->graphics->drawText(s, strlen(s), kUTF8Encoding, x, y);
}

static void textCentered(LCDFont* f, const char* s, int cx, int y)
{
	pd->graphics->setFont(f);
	text(s, cx - textWidth(f, s) / 2, y);
}

static void roundRect(int x, int y, int w, int h, int r, int lw)
{
	LCDColor c = kColorBlack;
	pd->graphics->fillRect(x + r, y, w - 2 * r, lw, c);
	pd->graphics->fillRect(x + r, y + h - lw, w - 2 * r, lw, c);
	pd->graphics->fillRect(x, y + r, lw, h - 2 * r, c);
	pd->graphics->fillRect(x + w - lw, y + r, lw, h - 2 * r, c);
	pd->graphics->drawEllipse(x, y, 2 * r, 2 * r, lw, 270.0f, 360.0f, c);
	pd->graphics->drawEllipse(x + w - 2 * r, y, 2 * r, 2 * r, lw, 0.0f, 90.0f, c);
	pd->graphics->drawEllipse(x + w - 2 * r, y + h - 2 * r, 2 * r, 2 * r, lw, 90.0f, 180.0f, c);
	pd->graphics->drawEllipse(x, y + h - 2 * r, 2 * r, 2 * r, lw, 180.0f, 270.0f, c);
}

static void polarLine(int cx, int cy, float deg, float r0, float r1, int width)
{
	float s = sinf(rad(deg)), c = cosf(rad(deg));
	pd->graphics->drawLine(cx + (int)(s * r0), cy - (int)(c * r0),
		cx + (int)(s * r1), cy - (int)(c * r1), width, kColorBlack);
}

// ---- the dial band: how the dial circle shows through the window
// The needle stays in the middle of the window and the scale slides under it at ONE steady speed (DIAL_PX_PER_MHZ), like a
// long printed band going round behind the window; it is still a circle (108 runs on into 88). 2026-11-18: a curved "drum"
// view was tried first, where marks bunched up towards the edges, but names then moved at different speeds and had to be
// cut off behind each other (the user: names cut off). With a flat band and this spacing, two names can never overlap:
// stations are at least 2.8 MHz apart (the gap across 108/88), 2.8 x 46 = 129 px, and a name is at most 116 px + a 12 px gap.
#define NEEDLE_X (WIN_X + WIN_W / 2)
#define DIAL_PX_PER_MHZ 46.0f
#define DIAL_HALF ((float)(SCALE_X1 - SCALE_X0) / 2.0f)   // 168 px each side of the needle

/**
 * Where frequency `f` appears in the window. Returns 0 when it is out of sight. Otherwise *x is its screen position and
 * *facing (0..1) how central it is: 1 under the needle, 0 at the edge of the scale.
 */
static int drumX(float f, int* x, float* facing)
{
	float dx = dialDelta(freq, f) * DIAL_PX_PER_MHZ;
	if (dx <= -DIAL_HALF - 70.0f || dx >= DIAL_HALF + 70.0f) return 0;   // (70: a name half out of the window still shows)
	*x = NEEDLE_X + (int)lroundf(dx);
	if (facing) { float t = 1.0f - fabsf(dx) / DIAL_HALF; *facing = t < 0.0f ? 0.0f : t; }
	return 1;
}


// ---- the static cabinet ----

static void buildCabinet(void)
{
	cabinet = pd->graphics->newBitmap(400, 240, kColorWhite);
	pd->graphics->pushContext(cabinet);
	LCDColor black = kColorBlack;

	roundRect(2, 2, 396, 236, 14, 4);

	// dial window and scale
	roundRect(WIN_X, WIN_Y, WIN_W, WIN_H, 6, 3);
	pd->graphics->drawLine(SCALE_X0, SCALE_Y, SCALE_X1, SCALE_Y, 1, black);
	// (the ticks, numbers and station names turn with the drum, so draw() adds them every frame: drawDrum)

	// station info panel: a rounded frame with a header strip and a rule above the "earlier" song (text drawn per frame)
	roundRect(INFO_X, INFO_Y, INFO_W, INFO_H, 8, 3);
	pd->graphics->drawLine(INFO_X + 8, INFO_Y + 22, INFO_X + INFO_W - 9, INFO_Y + 22, 1, black);
	pd->graphics->drawLine(INFO_X + 8, INFO_Y + 55, INFO_X + INFO_W - 9, INFO_Y + 55, 1, black);

	// label plate, with a rule above the signal/volume line
	pd->graphics->drawRect(PLATE_X, PLATE_Y, PLATE_W, PLATE_H, black);
	pd->graphics->drawRect(PLATE_X + 2, PLATE_Y + 2, PLATE_W - 4, PLATE_H - 4, black);
	pd->graphics->drawLine(PLATE_X + 8, PLATE_Y + 56, PLATE_X + PLATE_W - 9, PLATE_Y + 56, 1, black);
	pd->graphics->setFont(small);
	text("VOL", PLATE_X + PLATE_W - 84, PLATE_Y + 66);

	pd->graphics->popContext();
}

// ---- per-frame drawing ----

static const char* statusWord(void)
{
	if (pd->network->getStatus() == kWifiNotAvailable) return "no wi-fi";
	if (gBands[band].count == 0 && directory_offline()) return "offline";
	if (gBands[band].count == 0 && directory_busy()) return "searching";
	switch (stream_state()) {
		case STREAM_NEED_ACCESS: return "allow net";
		case STREAM_DENIED:      return "no access";
		case STREAM_CONNECTING:
		case STREAM_BUFFERING:   return stream_rebuffering() ? "buffering" : "tuning";
		case STREAM_PLAYING:     return "live";
		case STREAM_ERROR:       return "no signal";
		default:                 return "static";
	}
}

// Preset keys, one per band; the active one is pressed in (black, no shadow).
//
// Each key is as wide as its label plus an equal share of the leftover room, so a long label ("CLASSIC") still fits when
// seven keys share the row (equal widths gave only 49 px each, and "CLASSIC" needs about 52).
/** One preset key at (x, w): filled black when its band is the one playing, raised (outline + shadow) otherwise. */
static void drawKeyFrame(int x, int w, int active)
{
	if (active) pd->graphics->fillRect(x, KEYS_Y + 2, w, KEYS_H - 2, kColorBlack);
	else {
		pd->graphics->drawRect(x, KEYS_Y, w, KEYS_H - 2, kColorBlack);
		pd->graphics->fillRect(x + 1, KEYS_Y + KEYS_H - 2, w - 1, 2, kColorBlack);   // key shadow
	}
}

/**
 * The row of preset keys, one per band. When stations are saved, the saved band gets a narrow key with a heart at the far
 * LEFT (2026-11-19) and the genre keys share the rest of the row. Its band is the LAST one, so Ⓑ goes from the right-most
 * key round to the heart and then on to the first genre key, which reads as the row wrapping round.
 */
#define HEART_KEY_W 24
static void drawKeys(void)
{
	int savedShown = saved_count() > 0 && saved_band() < gBandCount;
	int genres = savedShown ? gBandCount - 1 : gBandCount;
	int x0 = KEYS_X, rowW = KEYS_W;
	if (savedShown) {
		int active = band == saved_band();
		drawKeyFrame(KEYS_X, HEART_KEY_W, active);
		drawHeart(KEYS_X + HEART_KEY_W / 2, KEYS_Y + (active ? 8 : 6), 1, active ? kColorWhite : kColorBlack);
		x0 += HEART_KEY_W + KEY_GAP;
		rowW -= HEART_KEY_W + KEY_GAP;
	}
	if (genres <= 0) return;
	int textW[MAX_BANDS], total = 0;
	for (int i = 0; i < genres; i++) { textW[i] = textWidth(small, gBands[i].name); total += textW[i]; }
	int spare = rowW - KEY_GAP * (genres - 1) - total;
	if (spare < 0) spare = 0;
	pd->graphics->setFont(small);
	int x = x0;
	for (int i = 0; i < genres; i++) {
		// the leftover pixels are shared out evenly; the last key takes the rounding so the row ends exactly at the edge
		int w = i == genres - 1 ? x0 + rowW - x : textW[i] + spare / genres;
		const char* name = gBands[i].name;
		int tx = x + (w - textW[i]) / 2;
		drawKeyFrame(x, w, i == band);
		if (i == band) {
			pd->graphics->setDrawMode(kDrawModeFillWhite);
			text(name, tx, KEYS_Y + 7);
			pd->graphics->setDrawMode(kDrawModeCopy);
		} else text(name, tx, KEYS_Y + 5);
		x += w + KEY_GAP;
	}
}

/**
 * Draws one line of text in the big font inside a box `w` px wide. If it fits, it simply sits there. If it is wider, it
 * scrolls left like a shop sign, with a 40 px gap before it comes round again. `*pos` is that line's own scroll position, so
 * the station name and the song title move independently; a negative position is a pause before scrolling starts (the
 * caller sets -MARQUEE_HOLD * MARQUEE_SPEED to give people a moment to read the start).
 */
static void drawMarquee(const char* s, float* pos, float dt, int x, int y, int w)
{
	pd->graphics->setFont(font);
	int tw = textWidth(font, s);
	pd->graphics->setClipRect(x, y, w, 20);
	if (tw <= w) {
		*pos = 0.0f;
		text(s, x, y);
	} else {
		int gap = 40;
		*pos += MARQUEE_SPEED * dt;
		if (*pos >= (float)(tw + gap)) *pos -= (float)(tw + gap);
		int off = *pos > 0.0f ? (int)*pos : 0;
		text(s, x - off, y);
		text(s, x - off + tw + gap, y);
	}
	pd->graphics->clearClipRect();
}

static void drawHints(void)
{
	int x = 58, y = 30, w = 284, h = 176;
	pd->graphics->fillRect(x, y, w, h, kColorWhite);
	roundRect(x, y, w, h, 8, 3);
	textCentered(font, "How to tune", x + w / 2, y + 10);
	const char* rows[][2] = {
		{ "Crank", "turn the dial" },
		{ "⬅️ ➡️", "jump to a station" },
		{ "Ⓐ", "save / unsave" },
		{ "Ⓑ", "change band" },
		{ "⬆️ ⬇️", "volume" },
	};
	for (int i = 0; i < 5; i++) {
		pd->graphics->setFont(i == 0 ? font : light);
		text(rows[i][0], x + 24, y + 38 + i * 24);
		pd->graphics->setFont(font);
		text(rows[i][1], x + 108, y + 38 + i * 24);
	}
	textCentered(small, "press any button", x + w / 2, y + h - 18);
}

/**
 * Draws the credits card over the radio: who made the app, who provides the
 * radio streams, and the other things we are built on. Kept as plain centred
 * lines so adding or removing a credit is a one-line change.
 */
static void drawAbout(void)
{
	int x = 40, y = 14, w = 320, h = 212;
	pd->graphics->fillRect(x, y, w, h, kColorWhite);
	roundRect(x, y, w, h, 8, 3);
	int cx = x + w / 2;
	textCentered(font, "Crank FM", cx, y + 12);
	textCentered(small, "created and programmed by", cx, y + 38);
	textCentered(font, "Boraq Abdulmajeed", cx, y + 52);
	textCentered(font, "Nityaansh Parekh", cx, y + 72);
	textCentered(small, "stations found with", cx, y + 98);
	textCentered(font, "Radio Browser", cx, y + 112);
	textCentered(small, "community directory, radio-browser.info", cx, y + 130);
	textCentered(small, "built with Claude Code (Anthropic)", cx, y + 150);
	textCentered(small, "mp3 decoding: minimp3 (public domain)", cx, y + 165);
	textCentered(small, "press any button", cx, y + h - 18);
}

/**
 * Fits one dial label into maxW pixels and returns how wide it ends up (0 for an empty name). Directory names are free
 * text, often wider than the room by a station, so:
 *  1. whole words are dropped from the end ("Alabama's Finest Radio" -> "Alabama's"), which reads far better than a word
 *     cut in half;
 *  2. if the one word left is still too wide for the big font, it is kept whole in the small font instead ("Chilltrax"):
 *     a complete name in smaller letters beats "Chillt";
 *  3. only a word too wide even for the small font loses letters from its end.
 * The result goes to `out`; *isSmall says which font to draw it in.
 */
/**
 * Does this label read right to left? Labels arrive already in SCREEN order (src/arabic.c), so an Arabic name STARTS at its
 * right end: if the rightmost character is an Arabic shape (UTF-8 lead byte 0xD8-0xDB, or 0xEF for the presentation forms),
 * the reader begins there, and trimming must happen on the left.
 */
static int readsRightToLeft(const char* s)
{
	int n = (int)strlen(s);
	while (n > 0 && s[n - 1] == ' ') n--;
	if (n == 0) return 0;
	int i = n - 1;
	while (i > 0 && ((unsigned char)s[i] & 0xC0) == 0x80) i--;   // back to the start of the last character
	unsigned char lead = (unsigned char)s[i];
	return (lead >= 0xD8 && lead <= 0xDB) || lead == 0xEF;
}

static int fitLabel(const char* s, int maxW, char* out, int outCap, int* isSmall)
{
	snprintf(out, (size_t)outCap, "%s", s);
	int n = (int)strlen(out);
	while (n > 0 && out[n - 1] == ' ') out[--n] = '\0';
	// An Arabic name starts on the right, so its words and letters are trimmed from the LEFT (its end when read);
	// everything else is trimmed from the right as before.
	int rtl = readsRightToLeft(out);
	while (textWidth(font, out) > maxW) {              // step 1: drop words
		if (rtl) {
			char* space = strchr(out, ' ');
			if (space == NULL || space[1] == '\0') break;
			memmove(out, space + 1, strlen(space + 1) + 1);
		} else {
			char* space = strrchr(out, ' ');
			if (space == NULL || space == out) break;
			*space = '\0';
		}
	}
	LCDFont* f = font;
	*isSmall = 0;
	if (textWidth(font, out) > maxW) { f = small; *isSmall = 1; }   // step 2
	n = (int)strlen(out);
	while (n > 1 && textWidth(f, out) > maxW) {        // step 3: cut letters, never half a UTF-8 character
		if (rtl) {
			int k = 1;
			while (out[k] != '\0' && ((unsigned char)out[k] & 0xC0) == 0x80) k++;   // the whole first character
			memmove(out, out + k, strlen(out + k) + 1);
			n = (int)strlen(out);
		} else {
			n--;
			while (n > 0 && ((unsigned char)out[n] & 0xC0) == 0x80) n--;
			out[n] = '\0';
		}
	}
	return out[0] != '\0' ? textWidth(f, out) : 0;
}

// ---- the drum's labels
// Each name is fitted ONCE (fitLabel: whole words first) to LABEL_MAX and then never changes while the drum turns.
// (Until 2026-11-18 it was re-fitted to the room left beside its neighbours on every turn, so a name jumped: "...sota" became
// "...ota Public" in one step, re-centred, as a word came back. The user spotted it at the left edge.) Where a name would
// run into a nearer one, it slides BEHIND it instead: it is drawn at its normal place and size, cut off by a moving edge
// just short of its neighbour, so its letters are covered gradually like a card going behind a curtain.
#define LABEL_MAX 116    // the widest a name may be (about 15 letters): with DIAL_PX_PER_MHZ no two names can then overlap
#define LABEL_GAP 12     // between two names: clearly wider than a space, so neighbours never read as one sentence
static struct {
	char text[sizeof(((Station*)0)->name)];
	int width, isSmall, room;   // room = the width it was fitted to (-1 = not yet)
} dialLabel[MAX_PER_BAND];
static const Band* dialLabelBand;
static int dialLabelVersion = -1;

/** Fits station i's name to LABEL_MAX, once per band (room < 0 = not fitted yet). */
static void fitStationLabel(const Band* b, int i)
{
	if (dialLabel[i].room >= 0) return;
	dialLabel[i].room = LABEL_MAX;
	dialLabel[i].width = fitLabel(b->st[i].name, LABEL_MAX, dialLabel[i].text, (int)sizeof dialLabel[i].text, &dialLabel[i].isSmall);
}

// ---- the dissolve at the edges (2026-11-18, the user: "I want the titles to FADE more smoothly")
// A 1-bit screen cannot draw grey, so a fade means rubbing out more and more of a name's pixels. The first try laid a FIXED
// grid of white dots over the window's edges; a name sliding through that grid had each of its pixels blink off and on as
// it passed the dots, which looked like flicker. Now the dots travel WITH the name: each pixel of a name has its own
// threshold (from an 8x8 ordered dither, counted from the name's left edge), and it is rubbed out once the fade at its
// position on the screen passes that threshold. As the name moves outwards the fade only grows, so a pixel that has gone
// stays gone: a steady dissolve. The fade is worked out every 2 px, from FADE_IN px off the needle to fully gone at FADE_OUT.
#define FADE_IN 112      // px from the needle where names start to dissolve
#define FADE_OUT 176     // px from the needle where they are gone (the window's inside edge is at 181)
static const uint8_t kBayer8[8][8] = {
	{ 0, 32,  8, 40,  2, 34, 10, 42}, {48, 16, 56, 24, 50, 18, 58, 26}, {12, 44,  4, 36, 14, 46,  6, 38},
	{60, 28, 52, 20, 62, 30, 54, 22}, { 3, 35, 11, 43,  1, 33,  9, 41}, {51, 19, 59, 27, 49, 17, 57, 25},
	{15, 47,  7, 39, 13, 45,  5, 37}, {63, 31, 55, 23, 61, 29, 53, 21} };

/** How much of a name is rubbed out at screen column x: 0 (none) to 64 (all), easing in gently. */
static int fadeLevel(int x)
{
	int d = abs(x - NEEDLE_X);
	if (d <= FADE_IN) return 0;
	if (d >= FADE_OUT) return 64;
	float t = (float)(d - FADE_IN) / (float)(FADE_OUT - FADE_IN);
	return (int)(t * t * (3.0f - 2.0f * t) * 64.0f + 0.5f);   // smoothstep: no visible start or end of the fade
}

/**
 * Rubs out part of a name drawn at [left, left + w) in the label row, by its position on the screen (see above). The dot
 * pattern is shifted by the name's own left edge, so the dots move with the name instead of staying put on the screen.
 */
static void dissolveLabel(int left, int w)
{
	int top = WIN_Y + 3, h = 22;
	int phase = ((left % 8) + 8) % 8;
	for (int x = left & ~1; x < left + w; x += 2) {
		int level = fadeLevel(x + 1);
		if (level <= 0) continue;
		if (level >= 64) { pd->graphics->fillRect(x, top, 2, h, kColorWhite); continue; }
		LCDPattern pat;
		for (int y = 0; y < 8; y++) {
			uint8_t m = 0;
			for (int px = 0; px < 8; px++)        // screen column px (mod 8) is the name's column (px - phase) mod 8
				if (kBayer8[y][(px - phase + 8) % 8] < level) m |= (uint8_t)(0x80 >> px);
			pat[y] = 0xFF;                        // white...
			pat[8 + y] = m;                       // ...only on the pixels whose turn it is to go
		}
		pd->graphics->fillRect(x, top, 2, h, (LCDColor)pat);
	}
}

/**
 * The turning scale: ticks every 0.5 MHz (taller every 2 MHz, with the number), and the station names with a marker under each.
 * Names are placed nearest-the-needle first: the one in the middle gets up to LABEL_MAX pixels, and each one further out gets
 * whatever room is left beside the names already placed, so they never overlap. Towards the edges the drum turns away, so
 * a dither is laid over the outer part of the window (drawn last) to make the scale fade round the curve.
 */
static void drawDrum(const Band* b)
{
	LCDColor black = kColorBlack;
	if (b != dialLabelBand || gStationsVersion != dialLabelVersion) {   // a new band or station list: forget the old fits
		for (int i = 0; i < MAX_PER_BAND; i++) dialLabel[i].room = -1;
		dialLabelBand = b;
		dialLabelVersion = gStationsVersion;
	}

	// ticks and numbers, all round the circle (the hidden half is skipped by drumX)
	for (int t = 0; t < 40; t++) {
		float f = DIAL_MIN + (float)t * 0.5f, facing;
		int x;
		if (!drumX(f, &x, &facing) || x < SCALE_X0 || x > SCALE_X1) continue;
		int major = (t % 4) == 0;
		pd->graphics->drawLine(x, SCALE_Y, x, SCALE_Y - (major ? 8 : 3), 1, black);
		if (major && facing > 0.08f) {                    // (not right at the frame, where the number would be cut)
			char lbl[8];
			snprintf(lbl, sizeof lbl, "%d", (int)f);
			textCentered(small, lbl, x, SCALE_Y + 4);
		}
	}

	// station names, nearest the needle first
	int n = b->count, order[MAX_PER_BAND], xs[MAX_PER_BAND], shown = 0;
	int placedL[MAX_PER_BAND], placedR[MAX_PER_BAND], placed = 0;
	for (int i = 0; i < n; i++) if (drumX(station_freq(i, n), &xs[i], NULL)) order[shown++] = i;
	for (int a = 1; a < shown; a++)                        // (at most six: a simple insertion sort by distance from the needle)
		for (int k = a; k > 0 && abs(xs[order[k]] - NEEDLE_X) < abs(xs[order[k - 1]] - NEEDLE_X); k--) {
			int t = order[k]; order[k] = order[k - 1]; order[k - 1] = t;
		}
	const int winL = WIN_X + 6, winR = WIN_X + WIN_W - 6;
	for (int k = 0; k < shown; k++) {
		int i = order[k], x = xs[i];
		int lo = winL - LABEL_MAX, hi = winR + LABEL_MAX;   // (the window itself is applied below)
		for (int p = 0; p < placed; p++) {                  // the free stretch around the marker between names already drawn
			// which side of that name we are on is decided by its middle, so a wide name lying over our marker still
			// puts us behind it on the correct side
			if (x >= (placedL[p] + placedR[p]) / 2) { if (placedR[p] + LABEL_GAP > lo) lo = placedR[p] + LABEL_GAP; }
			else if (placedL[p] - LABEL_GAP < hi) hi = placedL[p] - LABEL_GAP;
		}
		fitStationLabel(b, i);
		int w = dialLabel[i].width;
		if (x >= SCALE_X0 && x <= SCALE_X1) {              // its marker (only on the scale: a name may start just outside it)
			// a saved station (seen from a genre band) gets a tiny heart instead of the plain mark, so favourites
			// stand out while browsing; on the saved band itself every station is saved, so the plain mark is enough
			if (band != saved_band() && saved_has(&b->st[i])) drawHeart(x, SCALE_Y - 15, 0, black);
			else pd->graphics->fillRect(x - 1, SCALE_Y - 15, 3, 4, black);
		}
		if (w <= 0) continue;
		int left = x - w / 2;                               // always its own size, centred on its marker
		// the visible part: inside the window, and short of the names already drawn (the "curtain")
		int cl = left > lo ? left : lo, cr = left + w < hi ? left + w : hi;
		if (cl < WIN_X + 3) cl = WIN_X + 3;
		if (cr > WIN_X + WIN_W - 3) cr = WIN_X + WIN_W - 3;
		if (cr - cl < 1) continue;                          // entirely behind its neighbour
		pd->graphics->setClipRect(cl, WIN_Y + 3, cr - cl, WIN_H - 6);
		pd->graphics->setFont(dialLabel[i].isSmall ? small : font);
		text(dialLabel[i].text, left, WIN_Y + (dialLabel[i].isSmall ? 8 : 5));   // small: lowered onto the line
		dissolveLabel(left, w);
		pd->graphics->clearClipRect();
		placedL[placed] = cl; placedR[placed] = cr; placed++;   // later names stop short of what actually shows
	}

	// The curve: names and ticks dissolve smoothly as the drum turns them away. The outer FADE_STEPS x FADE_STEP px on each
	// side are covered with white dots, sparse on the inside and denser towards the frame, reaching solid white at the frame
	// itself, so a name melts away instead of jumping in two steps and then being cut off by the frame (2026-11-18, the user:
	// "the words in the edge don't vanish smooth"). The dot patterns come from an 8x8 ordered (Bayer) dither, so each step
	// adds dots between the earlier ones and the fade looks even.
	enum { FADE_STEPS = 10, FADE_STEP = 6 };
	static LCDPattern fade[FADE_STEPS];
	static int fadeReady;
	if (!fadeReady) {
		static const uint8_t bayer[8][8] = {
			{ 0, 32,  8, 40,  2, 34, 10, 42}, {48, 16, 56, 24, 50, 18, 58, 26}, {12, 44,  4, 36, 14, 46,  6, 38},
			{60, 28, 52, 20, 62, 30, 54, 22}, { 3, 35, 11, 43,  1, 33,  9, 41}, {51, 19, 59, 27, 49, 17, 57, 25},
			{15, 47,  7, 39, 13, 45,  5, 37}, {63, 31, 55, 23, 61, 29, 53, 21} };
		for (int k = 0; k < FADE_STEPS; k++) {
			// step 0 is next to the frame (solid white), the last step is barely dotted; the curve is squared so the
			// fade starts gently and only gets strong near the frame
			float t = 1.0f - (float)k / (float)FADE_STEPS;
			int level = (int)(t * t * 64.0f + 0.5f);
			for (int y = 0; y < 8; y++) {
				uint8_t m = 0;
				for (int x = 0; x < 8; x++) if (bayer[y][x] < level) m |= (uint8_t)(0x80 >> x);
				fade[k][y] = 0xFF;          // white...
				fade[k][8 + y] = m;         // ...only where the mask lets it through
			}
		}
		fadeReady = 1;
	}
	int top = WIN_Y + 25, h = WIN_H - 28;   // only the scale (ticks and numbers): the names dissolve on their own (dissolveLabel)
	for (int k = 0; k < FADE_STEPS; k++) {
		pd->graphics->fillRect(WIN_X + 3 + k * FADE_STEP, top, FADE_STEP, h, (LCDColor)fade[k]);
		pd->graphics->fillRect(WIN_X + WIN_W - 3 - (k + 1) * FADE_STEP, top, FADE_STEP, h, (LCDColor)fade[k]);
	}
}

/** 1 if `b` is the band of saved stations. */
static int isSavedBand(const Band* b) { return saved_band() >= 0 && b == &gBands[saved_band()]; }

/** What the plate's top line says when no station is tuned in. */
static const char* plateIdleText(const Band* b)
{
	static char line[32];
	if (b->count > 0) return isSavedBand(b) ? "Saved" : b->name;   // between stations: which band this is
	if (directory_offline()) return "can't reach stations";
	if (directory_busy()) {
		snprintf(line, sizeof line, "finding %s stations", directory_fetching() != NULL ? directory_fetching() : "");
		return line;
	}
	return "no stations here";
}

/**
 * The beat meter in the info panel's header: seven little bars that jump with the music. The loudness (`pulse`) sets how
 * tall they can get; each bar also rides its own slow wave (beatClock), so they move like a graphic equaliser rather than
 * all together. Flat stubs when nothing is playing.
 */
static void drawBeatMeter(int right, int baseY)
{
	float level = clampf(pulse / 50.0f, 0.0f, 1.0f);
	for (int i = 0; i < 7; i++) {
		float wave = 0.45f + 0.55f * fabsf(sinf(beatClock * (3.1f + 0.7f * (float)i) + (float)i * 1.9f));
		int h = 1 + (int)(level * 11.0f * wave);
		int x = right - (7 - i) * 5;
		pd->graphics->fillRect(x, baseY - h, 3, h, kColorBlack);
	}
}

/**
 * The station info panel (left, where the speaker grille was): what the tuned station plays, where it broadcasts from,
 * its quality, and the song it played before this one. With no station tuned it shows the app's name and the source of
 * the stations instead.
 */
#define INFO_HOLD 1.5f                 // seconds the info panel keeps the last station while the needle is between stations
static const Station* infoStation;     // the station the info panel is showing (NULL = the "tune in" card)
static float infoIdle;                 // how long the needle has been away from any station

/**
 * One "signpost" row of the between-stations card: a small arrow pointing the way (the same way ⬅️/➡️ jumps), the
 * station's dial name, and how far it is in MHz, right-aligned. `dir` -1 = to the left (lower), +1 = to the right.
 */
static void drawSignpost(int dir, const Station* st, float mhz, int y)
{
	int x = INFO_X + 9, right = INFO_X + INFO_W - 9;
	if (dir < 0) pd->graphics->fillTriangle(x, y + 6, x + 5, y + 2, x + 5, y + 10, kColorBlack);
	else pd->graphics->fillTriangle(x + 5, y + 6, x, y + 2, x, y + 10, kColorBlack);
	char dist[12];
	snprintf(dist, sizeof dist, "%.1f", (double)mhz);
	pd->graphics->setFont(small);
	int dw = textWidth(small, dist);
	text(dist, right - dw, y);
	char name[sizeof st->name];
	if (!drawable_text(st->name, name, (int)sizeof name)) snprintf(name, sizeof name, "station");
	// the name gets the room between the arrow and the distance, cut short if it is longer
	pd->graphics->drawTextInRect(name, strlen(name), kUTF8Encoding, x + 10, y, right - dw - 6 - (x + 10), 13, kWrapClip, kAlignTextLeft);
}

/**
 * The card shown while the needle rests between stations (2026-11-19, the user: make the in-between page neat; it used
 * to cram "Crank FM / via Radio Browser / tune in..." into three tight lines, the middle one struck through by the panel's
 * rule at +55). It now works as a signpost: the nearest station each way round the dial and how far it is, then the app's
 * name and where its stations come from, each part inside its own section of the panel.
 */
static void drawBetween(void)
{
	const Band* b = &gBands[band];
	int left = -1, right = -1;
	float dl = 99.0f, dr = 99.0f;
	for (int i = 0; i < b->count; i++) {
		float d = dialDelta(freq, station_freq(i, b->count));   // + = to the right (higher), round the circle
		if (d >= 0.0f && d < dr) { dr = d; right = i; }
		if (d < 0.0f && -d < dl) { dl = -d; left = i; }
	}
	if (b->count == 1) {   // one station: point only the shorter way to it
		if (dl < dr) right = -1; else left = -1;
	}
	if (left < 0 && right < 0) textCentered(small, "no stations here yet", INFO_X + INFO_W / 2, INFO_Y + 33);
	else if (left < 0 || right < 0) {    // a single signpost sits in the middle of its section
		if (left >= 0) drawSignpost(-1, &b->st[left], dl, INFO_Y + 33);
		else drawSignpost(1, &b->st[right], dr, INFO_Y + 33);
	} else {
		drawSignpost(-1, &b->st[left], dl, INFO_Y + 28);
		drawSignpost(1, &b->st[right], dr, INFO_Y + 41);
	}
	textCentered(small, "Crank FM", INFO_X + INFO_W / 2, INFO_Y + 60);
	textCentered(small, BADGE_CREDIT, INFO_X + INFO_W / 2, INFO_Y + 73);
}

static void drawInfo(const Station* s)
{
	int x = INFO_X + 9, w = INFO_W - 18;
	pd->graphics->setFont(small);
	text(s != NULL ? "ON AIR" : "NEARBY", x, INFO_Y + 7);
	drawBeatMeter(INFO_X + INFO_W - 8, INFO_Y + 18);
	if (s == NULL) { drawBetween(); return; }
	// What it plays, then where from and the quality. The tags are already a ", "-separated list (tidyTags), so whole tags
	// are dropped from the end until the line fits ("alternative, electronic" rather than "alternative, elec").
	char plays[sizeof s->tags];
	snprintf(plays, sizeof plays, "%s", s->tags);
	while (plays[0] != '\0' && textWidth(small, plays) > w) {
		char* cut = strstr(plays, ", ");
		char* last = NULL;
		while (cut != NULL) { last = cut; cut = strstr(cut + 2, ", "); }
		if (last == NULL) { plays[0] = '\0'; break; }   // one tag that is too long on its own: say "music" instead
		*last = '\0';
	}
	if (plays[0] == '\0') snprintf(plays, sizeof plays, "%s", s->tags[0] != '\0' ? "music" : "music and talk");
	pd->graphics->setFont(small);
	text(plays, x, INFO_Y + 26);
	char line[64];
	// Full country names can be wide ("United Kingdom, 128k" is 146 px, the panel line 138): then the country wins and
	// the quality is left off.
	if (s->country[0] != '\0' && s->bitrate > 0) {
		snprintf(line, sizeof line, "%s, %dk", s->country, s->bitrate);
		if (textWidth(small, line) > w) snprintf(line, sizeof line, "%s", s->country);
	}
	else if (s->country[0] != '\0') snprintf(line, sizeof line, "%s", s->country);
	else if (s->bitrate > 0) snprintf(line, sizeof line, "%dk", s->bitrate);
	else line[0] = '\0';
	pd->graphics->setFont(small);
	pd->graphics->drawTextInRect(line, strlen(line), kUTF8Encoding, x, INFO_Y + 39, w, 13, kWrapClip, kAlignTextLeft);
	// The song before this one. Until the station has changed song once there is none, and the line used to say
	// "earlier: just tuned in" every time (the user disliked it, 2026-11-16), so it shows how long you have been listening
	// instead ("listening 2:31"), counted from when this station started playing; blank while it is still connecting.
	static char prev[160];
	static const Station* listenStation;   // the station the listening clock belongs to
	static unsigned int listenStart;       // when it started playing (0 = not playing yet)
	unsigned int nowMs = pd->system->getCurrentTimeMilliseconds();
	// (The first version only started the clock in the frame the STATION changed, but a station is picked while it is still
	// connecting and starts playing a moment later, so the clock never started and the line stayed blank: found by the
	// device stress test of 2026-11-16. The three steps below are independent.)
	if (s != listenStation) { listenStation = s; listenStart = 0; }          // another station: start over
	if (stream_state() != STREAM_PLAYING) listenStart = 0;                     // not playing (yet, or any more)
	else if (listenStart == 0) listenStart = nowMs != 0 ? nowMs : 1;           // it just started playing
	const char* raw = stream_previous_title();
	if (raw[0] == '\0') {
		if (listenStart == 0) prev[0] = '\0';
		else {
			unsigned int secs = (nowMs - listenStart) / 1000;
			if (secs >= 3600) snprintf(prev, sizeof prev, "listening %u:%02u:%02u", secs / 3600, secs / 60 % 60, secs % 60);
			else snprintf(prev, sizeof prev, "listening %u:%02u", secs / 60, secs % 60);
		}
	} else {
		char clean[150];
		if (!drawable_text(raw, clean, (int)sizeof clean)) snprintf(clean, sizeof clean, "(another script)");
		snprintf(prev, sizeof prev, "earlier: %s", clean);
	}
	pd->graphics->drawTextInRect(prev, strlen(prev), kUTF8Encoding, x, INFO_Y + 59, w, 26, kWrapWord, kAlignTextLeft);
}

static void draw(const Station* near, float dist, float dt)
{
	LCDColor black = kColorBlack;
	const Band* b = &gBands[band];
	int tuned = near != NULL && dist < CAPTURE;
	pd->graphics->drawBitmap(cabinet, 0, 0, kBitmapUnflipped);

	// dial: station names, lamp glow around the needle, needle
	drawDrum(b);
	int nx = NEEDLE_X;   // the needle stays put; the drum turns under it
	float glow = stream_state() == STREAM_PLAYING ? quality : 0.0f;
	if (glow > 0.05f) {
		// The lamp behind the needle throbs with the music (the beat used to pulse the speaker grille, which the info
		// panel replaced): it widens by up to 7 px on loud beats and turns to the denser glow pattern on the peaks.
		float beat = clampf(pulse / 50.0f, 0.0f, 1.0f) * glow;
		int gw = 4 + (int)(glow * 12.0f + beat * 7.0f);
		pd->graphics->fillRect(nx - gw, WIN_Y + 27, gw * 2 + 1, SCALE_Y - WIN_Y - 29,   /* starts below the needle's arrow, so the glow never hides it */
			(LCDColor)(glow > 0.6f || beat > 0.55f ? kGlow50 : kGlow25));
	}
	// the needle starts below the names: the name under it now sits right in the middle and would be struck through; a
	// small arrow on top points up at it instead
	pd->graphics->fillRect(nx - 1, WIN_Y + 25, 3, WIN_H - 29, black);
	pd->graphics->fillTriangle(nx - 4, WIN_Y + 25, nx + 4, WIN_Y + 25, nx, WIN_Y + 21, black);

	// The info panel keeps showing the last station while the needle travels (a seek or a crank sweeps across empty dial,
	// and the panel used to flash back to "Crank FM" on every switch). Only after INFO_HOLD seconds of resting between
	// stations does it go back to the "tune in" card. It also lets go at once if that station is not in this band any more
	// (a band change, or a refreshed list that dropped it).
	if (tuned) { infoStation = near; infoIdle = 0.0f; }
	else {
		infoIdle += dt;
		int inBand = infoStation != NULL && infoStation >= b->st && infoStation < b->st + b->count;
		if (!inBand || infoIdle > INFO_HOLD) infoStation = NULL;
	}
	drawInfo(infoStation);

	// label plate: station + frequency, then the song
	char fbuf[16];
	snprintf(fbuf, sizeof fbuf, "%.1f FM", (double)freq);
	pd->graphics->setFont(small);
	int fw = textWidth(small, fbuf);
	text(fbuf, PLATE_X + PLATE_W - 8 - fw, PLATE_Y + 8);
	// The station's full name scrolls when it is wider than the room beside the frequency ("Exclusively Kendrick Lamar"
	// used to be cut to "Exclusively Kendr"). It starts again from the beginning whenever a different station tunes in.
	static const Station* titleOf;
	if ((tuned ? near : NULL) != titleOf) { titleOf = tuned ? near : NULL; titleScroll = -MARQUEE_HOLD * MARQUEE_SPEED; }
	drawMarquee(tuned ? near->title : plateIdleText(b), &titleScroll, dt, PLATE_X + 8, PLATE_Y + 5, PLATE_W - 24 - fw);
	{
		// Song titles come straight from the station: in Arabic or Japanese radio they are often in a script the font
		// cannot draw, which would show as empty boxes. drawable_text keeps the drawable part ("Fairuz - [Arabic]" ->
		// "Fairuz") or, if nothing is left, a note.
		static char songShown[160];
		const char* song = "";
		if (stream_state() == STREAM_PLAYING && tuned) {
			const char* raw = stream_title();
			if (raw[0] != '\0' && !drawable_text(raw, songShown, (int)sizeof songShown)) snprintf(songShown, sizeof songShown, "(song title in another script)");
			song = raw[0] != '\0' ? songShown : "";
		}
		// between stations the song line says how many stations the band holds, under the band's name
		static char countLine[32];
		if (!tuned && b->count > 0) {
			snprintf(countLine, sizeof countLine, "%d %sstation%s", b->count, isSavedBand(b) ? "saved " : "", b->count == 1 ? "" : "s");
			song = countLine;
		}
		drawMarquee(song, &marquee, dt, PLATE_X + 8, PLATE_Y + 27, PLATE_W - 16);
	}

	// plate footer: signal bars + status, volume
	int bars = (int)(sigLevel * 5.0f + 0.5f);
	for (int i = 0; i < 5; i++) {
		int h = 3 + i * 2, x = PLATE_X + 9 + i * 5, y = PLATE_Y + 78 - h;
		if (i < bars) pd->graphics->fillRect(x, y, 3, h, black);
		else pd->graphics->fillRect(x, PLATE_Y + 77, 3, 1, black);
	}
	pd->graphics->setFont(small);
	text(statusWord(), PLATE_X + 38, PLATE_Y + 66);
	int vx = PLATE_X + PLATE_W - 56, vy = PLATE_Y + 71;
	pd->graphics->drawLine(vx, vy, vx + 46, vy, 1, black);
	pd->graphics->fillRect(vx + (int)(gAudio.volume * 44.0f), vy - 4, 3, 9, black);

	drawKeys();

#if !CLIP_CAPTURE   // (the website clip should not show the docked-crank message the Simulator causes)
	if (toastTimer > 0.0f && hintTimer <= 0.0f)
		textCentered(small, toast, 200, WIN_Y + WIN_H + 1);
	else if (pd->system->isCrankDocked() && hintTimer <= 0.0f)
		textCentered(small, "undock the crank to tune", 200, WIN_Y + WIN_H + 1);
#endif
	if (hintTimer > 0.0f) drawHints();
	if (aboutOpen) drawAbout();
}

#if CLIP_CAPTURE
/**
 * Saves 300 consecutive frames (10 seconds at 30fps) as PBM files in the data folder, starting once
 * the station has been playing for 5 seconds so the music and the grille's pulsing are in full swing.
 * Used only to make the website's silent looping clip of the radio.
 */
static void captureFrame(void)
{
	static int playingFrames = 0, saved = 0;
	if (saved >= 300) return;
	if (stream_state() != STREAM_PLAYING) { playingFrames = 0; return; }
	if (++playingFrames < 150) return;
	char name[32];
	snprintf(name, sizeof name, "cap_%04d.pbm", saved++);
	SDFile* f = pd->file->open(name, kFileWrite);
	if (f == NULL) return;
	const char* hdr = "P4\n400 240\n";
	pd->file->write(f, hdr, (unsigned int)strlen(hdr));
	uint8_t* frame = pd->graphics->getFrame();
	uint8_t row[50];
	for (int y = 0; y < 240; y++) {
		// PBM: 1 = black. In dark mode the display inverts the frame, so the dump inverts it too (it shows what you see).
		for (int i = 0; i < 50; i++) row[i] = darkMode ? frame[y * LCD_ROWSIZE + i] : (uint8_t)~frame[y * LCD_ROWSIZE + i];
		pd->file->write(f, row, 50);
	}
	pd->file->close(f);
	if (saved == 300) dlog("capture done");
}
#endif

#if SCREEN_DUMP
// Writes the frame as a PBM so the screen can be inspected off-device.
static void dumpScreen(void)
{
	static unsigned int next;
	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	if (now < next) return;
	next = now + 3000;
	SDFile* f = pd->file->open("screen.pbm", kFileWrite);
	if (f == NULL) return;
	const char* hdr = "P4\n400 240\n";
	pd->file->write(f, hdr, (unsigned int)strlen(hdr));
	uint8_t* frame = pd->graphics->getFrame();
	uint8_t row[50];
	for (int y = 0; y < 240; y++) {
		// PBM: 1 = black. In dark mode the display inverts the frame, so the dump inverts it too (it shows what you see).
		for (int i = 0; i < 50; i++) row[i] = darkMode ? frame[y * LCD_ROWSIZE + i] : (uint8_t)~frame[y * LCD_ROWSIZE + i];
		pd->file->write(f, row, 50);
	}
	pd->file->close(f);
}
#endif

static int update(void* userdata)
{
	(void)userdata;
	float dt = clampf(pd->system->getElapsedTime(), 0.001f, 0.1f);
	pd->system->resetElapsedTime();

	static int bootFrames = 3;   // log the phases of the first few frames (device debugging)
	if (bootFrames > 0) dlog("frame %d: start", 3 - bootFrames);
	if (splashTimer <= 0.0f) handleInput(dt);
	else pd->system->getCrankChange();   // discard crank movement during the splash
	float dist;
	int nearIndex = nearestStation(freq, &dist);
	const Station* near = nearIndex >= 0 ? &gBands[band].st[nearIndex] : NULL;
	if (bootFrames > 0) dlog("frame: near %s", near != NULL ? near->title : "(empty band)");
	manageStream(near, dist);        // the stream starts connecting behind the splash
	directory_focus(band);           // the band on screen is the one fetched first
	directory_update();              // (directory edition) fetch stations in the background
	regionMessages();
	if (toastTimer > 0.0f) toastTimer -= dt;
	if (bootFrames > 0) { dlog("frame: stream ok"); bootFrames--; }
	updateAudioTargets(dist, dt);
	if (splashTimer > 0.0f) {
		// Hold the launch screen; keep the radio silent so it fades in afterwards.
		splashTimer -= dt;
		gAudio.stationGain = 0.0f;
		gAudio.noiseGain = 0.0f;
		if (splash != NULL) pd->graphics->drawBitmap(splash, 0, 0, kBitmapUnflipped);
		else splashTimer = 0.0f;
		if (splashTimer <= 0.0f) applyDark();   // the tower photo is never shown inverted; dark mode starts after it
#if SCREEN_DUMP
		dumpScreen();
#endif
		return 1;
	}
	animate(dt);

	if (hintTimer > 0.0f) {
		hintTimer -= dt;       // (counts only after the splash)
		if (!hintsSeen) { hintsSeen = 1; markDirty(); }
	}
	draw(near, dist, dt);
#if SCREEN_DUMP
	dumpScreen();
#endif
#if CLIP_CAPTURE
	captureFrame();
#endif

	if (dirtySince != 0 && pd->system->getCurrentTimeMilliseconds() - dirtySince >= SAVE_DELAY_MS)
		saveSettings();
	return 1;
}

#ifdef _WINDLL
__declspec(dllexport)
#endif
int eventHandler(PlaydateAPI* playdate, PDSystemEvent event, uint32_t arg)
{
	(void)arg;
	if (event == kEventInit) {
		pd = playdate;
		dlog_init(pd);
		dlog("init: start");
		const char* err = NULL;
		// Our own copies of the system fonts with Arabic letter shapes added (Source/fonts, made by
		// tunes/tools/make_arabic_font.py: the Latin letters are the system font's, unchanged), so Arabic station names and
		// song titles can be drawn (src/arabic.c shapes them). The system fonts are the fallback if a copy is missing.
		font = pd->graphics->loadFont("fonts/Asheville-Sans-14-Bold-AR", &err);
		if (font == NULL) font = pd->graphics->loadFont("/System/Fonts/Asheville-Sans-14-Bold.pft", &err);
		if (font == NULL) pd->system->error("font: %s", err);
		small = pd->graphics->loadFont("fonts/Roobert-10-Bold-AR", &err);
		if (small == NULL) small = pd->graphics->loadFont("/System/Fonts/Roobert-10-Bold.pft", &err);
		if (small == NULL) pd->system->error("font: %s", err);
		light = pd->graphics->loadFont("fonts/Asheville-Sans-14-Light-AR", &err);
		if (light == NULL) light = pd->graphics->loadFont("/System/Fonts/Asheville-Sans-14-Light.pft", &err);
		if (light == NULL) pd->system->error("font: %s", err);
		dlog("init: fonts %p %p %p", (void*)font, (void*)small, (void*)light);
		// 10s of audio: the adaptive buffer (stream.c) can grow to 10s when the Wi-Fi is weak.
		if (!audio_init(pd, 10)) pd->system->error("out of memory for audio buffer");
		setupHeadphones();
		dlog("init: audio");
		loadSettings();
		directory_init(pd, regionSaved);   // stations from the cache; a refresh starts once allowed
		saved_init(pd);                      // your saved stations: one more band after the genre bands
		if (band >= gBandCount) band = 0;
		dlog("init: settings band %d freq %.1f, %d bands", band, (double)freq, gBandCount);
		if (!aboutSeen) {                    // first launch: credits first, then the controls
			aboutOpen = 1;
			controlsAfterAbout = !hintsSeen;
		} else if (!hintsSeen) hintTimer = HINT_SECONDS;
		buildCabinet();
		dlog("init: cabinet");
		splash = pd->graphics->loadBitmap("launcher/launchImage", &err);
		dlog("init: splash %p", (void*)splash);
		if (splash != NULL) pd->graphics->drawBitmap(splash, 0, 0, kBitmapUnflipped);
		stream_init(pd);
		dlog("init: stream");
		// The Playdate allows three items of our own: help (credits + controls), dark, and (directory edition) region.
		pd->system->addMenuItem("help", showHelp, NULL);
		darkItem = pd->system->addCheckmarkMenuItem("dark", darkMode, onDark, NULL);   // applied once the splash is over
		regionItem = pd->system->addOptionsMenuItem("region", (const char**)kRegionNames, kRegionCount, onRegion, NULL);
		pd->system->setMenuItemValue(regionItem, directory_region());
		pd->display->setRefreshRate(30);
		pd->system->resetElapsedTime();
		pd->system->setUpdateCallback(update, NULL);
		dlog("init: done");
	} else if (event == kEventTerminate || event == kEventLock || event == kEventPause) {
		if (dirtySince != 0) saveSettings();
	}
	return 0;
}
