#include <math.h>
#include "audio.h"

#define OUT_RATE 44100
#define GLIDE 0.0005f       // per-sample smoothing toward target gains (~50ms)
#define TWO_PI 6.2831853f
#define STATIC_RISE 0.00008f   // per-sample glide when the static grows louder (~0.3 s)
#define STATIC_LEVEL 0.2f  // static's loudness next to the music (was 0.5: too loud)

// Limiter. It keeps the final output under LIM_CEIL so loud songs at high volume
// squash gently instead of clipping into harsh distortion.
#define LIM_CEIL 0.90f      // the level the limiter holds peaks to (of full scale)
#define LIM_ATTACK 0.2f     // per-sample gain drop toward the target: ~0.1ms, catches peaks fast
#define LIM_RELEASE 0.00015f // per-sample recovery: ~150ms, slow so it doesn't pump
#define SOFT_KNEE 0.85f     // above this the last-resort soft clipper starts to round peaks

AudioState gAudio;

// Callback-private state
static float phase;         // fractional read position into the ring
static float sGain, nGain, muffle, warble, volume;
static float lpStationL, lpStationR, lpNoise, lfo1, lfo2;
static float peak;
static float limGain = 1.0f;   // the limiter's current gain (1 = not limiting)
static uint32_t rng = 0x12345678u;

static inline float noise(void)
{
	rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
	return (float)(int32_t)rng * (1.0f / 2147483648.0f);
}

/**
 * Last-resort soft clipper. Samples below SOFT_KNEE pass untouched; above it they
 * bend smoothly toward 1.0 and never reach it, so even a peak that slips past the
 * limiter's attack time is rounded, not chopped flat (which is what sounds harsh).
 */
static inline float softClip(float x)
{
	float a = fabsf(x);
	if (a <= SOFT_KNEE) return x;
	float room = 1.0f - SOFT_KNEE;
	float d = (a - SOFT_KNEE) / room;               // how far into the knee, in units of "room"
	float y = SOFT_KNEE + room * (d / (1.0f + d));  // slope 1 at the knee, asymptote 1.0
	return x < 0.0f ? -y : y;
}

static int audioCallback(void* ctx, int16_t* left, int16_t* right, int len)
{
	(void)ctx;
	AudioState* a = &gAudio;
	int rate = a->srcRate;
	float baseStep = rate > 0 ? (float)rate / OUT_RATE : 1.0f;

	for (int i = 0; i < len; i++) {
		sGain += (a->stationGain - sGain) * GLIDE;
		// Static swells in slowly (~0.3 s) but leaves at the normal speed: when a station drops out or the app starts, the
		// hiss rises gently instead of bursting in.
		nGain += (a->noiseGain - nGain) * (a->noiseGain > nGain ? STATIC_RISE : GLIDE);
		muffle += (a->muffle - muffle) * GLIDE;
		warble += (a->warble - warble) * GLIDE;
		volume += (a->volume - volume) * GLIDE;

		// Station: resample both channels from the ring with linear interpolation
		// and a pitch wobble (the wobble is shared, so the stereo image holds still).
		float stationL = 0.0f, stationR = 0.0f;
		if (a->playing && rate > 0) {
			uint32_t avail = ring_count(&a->ring);
			if (avail >= 2) {
				int16_t l0, r0, l1, r1;
				ring_peek(&a->ring, 0, &l0, &r0);
				ring_peek(&a->ring, 1, &l1, &r1);
				stationL = (l0 + (l1 - l0) * phase) * (1.0f / 32768.0f);
				stationR = (r0 + (r1 - r0) * phase) * (1.0f / 32768.0f);

				lfo1 += 5.3f / OUT_RATE; if (lfo1 >= 1.0f) lfo1 -= 1.0f;
				lfo2 += 0.7f / OUT_RATE; if (lfo2 >= 1.0f) lfo2 -= 1.0f;
				float wob = warble * (0.6f * sinf(TWO_PI * lfo1) + 0.4f * sinf(TWO_PI * lfo2));
				phase += baseStep * (1.0f + wob);
				uint32_t adv = (uint32_t)phase;
				if (adv > avail - 1) adv = avail - 1;
				ring_drop(&a->ring, adv);
				phase -= (float)adv;
			} else {
				a->underruns++;
			}
		}
		// Mistuning muffles the station: one-pole low-pass, cutoff falls with muffle.
		float k = 1.0f - 0.95f * muffle;
		lpStationL += (stationL - lpStationL) * k;
		lpStationR += (stationR - lpStationR) * k;

		// Static: filtered white noise with the odd crackle (same in both ears). The filter (0.35) takes the sharpest
		// top off the hiss so it sounds like a soft rush rather than a harsh fizz on the little speaker.
		lpNoise += (noise() - lpNoise) * 0.35f;
		float hiss = lpNoise;
		if ((rng & 0x3fff) == 0) hiss += noise() * 1.5f;

		float heardL = lpStationL * sGain;
		float heardR = lpStationR * sGain;
		float env = fabsf(heardL) > fabsf(heardR) ? fabsf(heardL) : fabsf(heardR);
		peak = env > peak ? env : peak * 0.9997f;   // ~75ms release

		// STATIC_LEVEL sets how loud the static is next to the music. It was 0.5, which the user found too loud; 0.2 is
		// about 8 dB quieter, so the static still tells you you're off a station without shouting.
		float hissOut = hiss * nGain * STATIC_LEVEL;
		// Loudness follows the volume setting on a curve (volume squared): our ears hear loudness roughly on a log
		// scale, so a straight line made the bottom of the slider jump from silent to loud and the top barely change.
		// Squared spreads the change evenly across the whole slider.
		float loud = volume * volume;
		float outL = (heardL + hissOut) * loud;
		float outR = (heardR + hissOut) * loud;

		// The speaker is mono, so fold to L == R there: that is exactly how the
		// old mono source sounded, so the loudness doesn't change. Headphones keep stereo.
		if (!a->headphones) {
			float m = (outL + outR) * 0.5f;
			outL = outR = m;
		}

		// Limiter: pull the gain down fast when the louder channel would pass the
		// ceiling, let it creep back up slowly. One gain for both channels, so the
		// stereo image doesn't shift when it kicks in.
		float pk = fabsf(outL) > fabsf(outR) ? fabsf(outL) : fabsf(outR);
		if (pk * limGain > LIM_CEIL) {
			float want = LIM_CEIL / pk;
			limGain += (want - limGain) * LIM_ATTACK;   // the soft clipper below catches the first samples of a peak
		} else {
			limGain += (1.0f - limGain) * LIM_RELEASE;
		}
		outL = softClip(outL * limGain);
		outR = softClip(outR * limGain);

		left[i] = (int16_t)(outL * 32767.0f);
		right[i] = (int16_t)(outR * 32767.0f);
	}
	a->level = peak;
	return 1;
}

int audio_init(PlaydateAPI* pd, uint32_t ringSeconds)
{
	// Ring capacity: next power of two above ringSeconds of 48kHz audio (in frames;
	// each frame holds a left and a right sample).
	uint32_t cap = 1;
	while (cap < ringSeconds * 48000u) cap <<= 1;
	gAudio.ring.data = pd->system->realloc(NULL, (size_t)cap * 2 * sizeof(int16_t));
	if (gAudio.ring.data == NULL) return 0;
	gAudio.ring.cap = cap;
	gAudio.ring.w = gAudio.ring.r = 0;
	gAudio.volume = 0.8f;
	gAudio.noiseGain = 1.0f;

	pd->sound->addSource(audioCallback, NULL, 1);   // 1 = stereo source
	return 1;
}
