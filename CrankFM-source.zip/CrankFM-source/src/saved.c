// Saved stations: see saved.h for what they are and how the player reaches them.
//
// saved.txt holds one station per line, its fields separated by '|' (a character station_set_title already removes from
// names, so it can never appear inside a title):
//     title|address|tags|country|bitrate|uuid|dial label
// Example:  KEXP 90.3 FM|http://live-mp3-128.kexp.org/kexp128.mp3|indie, rock|US|128||KEXP
// The file is small text on purpose: it can be read, and fixed by hand, in Data Disk mode.
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "saved.h"

#define SAVED_FILE "saved.txt"
#define FILE_CAP 4096   // six stations of at most ~400 characters each

static PlaydateAPI* pd;
static int slot = -1;   // index of the saved band in gBands (right after the genre bands)

/** Shows or hides the saved band: it only counts as a band while it holds something, so new players never see it empty. */
static void updateBandCount(void)
{
	gBandCount = slot + (gBands[slot].count > 0 ? 1 : 0);
}

/** Copies `src` into `dst` (at most cap-1 bytes), turning the separators '|' and line breaks into spaces. */
static void cleanField(char* dst, int cap, const char* src)
{
	int n = 0;
	for (const char* c = src; *c != '\0' && n < cap - 1; c++) dst[n++] = (*c == '|' || *c == '\n' || *c == '\r') ? ' ' : *c;
	dst[n] = '\0';
}

/** Writes the whole list to saved.txt (rewritten on every change; it is only a few hundred bytes). */
static void writeFile(void)
{
	static char buf[FILE_CAP];
	int n = 0;
	const Band* b = &gBands[slot];
	for (int i = 0; i < b->count && n < FILE_CAP - 1; i++) {
		const Station* s = &b->st[i];
		char url[256], title[48], tags[40], country[28], name[24];
		station_url(s, url, (int)sizeof url);
		cleanField(title, (int)sizeof title, s->title);
		cleanField(tags, (int)sizeof tags, s->tags);
		cleanField(country, (int)sizeof country, s->country);
		cleanField(name, (int)sizeof name, s->name);
		int w = snprintf(buf + n, (size_t)(FILE_CAP - n), "%s|%s|%s|%s|%d|%s|%s\n",
				title, url, tags, country, s->bitrate, s->uuid, name);
		if (w < 0 || w >= FILE_CAP - n) break;   // would not fit: keep what is complete
		n += w;
	}
	SDFile* f = pd->file->open(SAVED_FILE, kFileWrite);
	if (f == NULL) return;
	pd->file->write(f, buf, (unsigned int)n);
	pd->file->close(f);
}

/**
 * Reads one saved.txt line into a Station. Returns 1 if it held a usable address. Missing fields at the end are allowed,
 * so a line written by hand ("My station|http://host/stream") also works.
 */
static int parseLine(char* line, Station* s)
{
	char* field[7] = { 0 };
	int k = 0;
	field[k++] = line;
	for (char* c = line; *c != '\0' && k < 7; c++)
		if (*c == '|') { *c = '\0'; field[k++] = c + 1; }
	if (k < 2 || !station_set_url(s, field[1])) return 0;
	station_set_title(s, field[0][0] != '\0' ? field[0] : s->host);   // also makes a dial label from the title
	if (k > 2) snprintf(s->tags, sizeof s->tags, "%s", field[2]);
	if (k > 3) snprintf(s->country, sizeof s->country, "%s", field[3]);
	if (k > 4) s->bitrate = atoi(field[4]);
	if (k > 5) snprintf(s->uuid, sizeof s->uuid, "%s", field[5]);
	if (k > 6 && field[6][0] != '\0') snprintf(s->name, sizeof s->name, "%s", field[6]);   // the label the dial showed ("K-Dot")
	return 1;
}

void saved_init(PlaydateAPI* api)
{
	pd = api;
	slot = gBandCount;               // right after the genre bands (6 in the personal edition, 7 in the directory one)
	if (slot >= MAX_BANDS) { slot = -1; return; }   // no room (cannot happen with MAX_BANDS 8): saving stays off
	Band* b = &gBands[slot];
	memset(b, 0, sizeof *b);
	snprintf(b->name, sizeof b->name, "SAVED");   // used by the plate; the key itself is drawn as a heart

	SDFile* f = pd->file->open(SAVED_FILE, kFileReadData);
	if (f != NULL) {
		static char buf[FILE_CAP];
		int n = pd->file->read(f, buf, FILE_CAP - 1);
		pd->file->close(f);
		if (n > 0) {
			buf[n] = '\0';
			char* line = buf;
			while (line != NULL && *line != '\0' && b->count < SAVED_MAX) {
				char* next = strchr(line, '\n');
				if (next != NULL) *next++ = '\0';
				size_t len = strlen(line);
				if (len > 0 && line[len - 1] == '\r') line[len - 1] = '\0';   // a file edited on Windows
				Station s;
				memset(&s, 0, sizeof s);
				// '#' starts a comment line (the saved.txt of the older SAVED band, removed 2026-11-11, began with one)
				if (line[0] != '\0' && line[0] != '#' && parseLine(line, &s)) b->st[b->count++] = s;
				line = next;
			}
		}
	}
	updateBandCount();
	gStationsVersion++;
}

int saved_band(void) { return slot; }

int saved_count(void) { return slot >= 0 ? gBands[slot].count : 0; }

int saved_has(const Station* s)
{
	if (slot < 0 || s == NULL) return 0;
	const Band* b = &gBands[slot];
	for (int i = 0; i < b->count; i++) if (station_same(&b->st[i], s)) return 1;
	return 0;
}

int saved_toggle(const Station* s)
{
	if (slot < 0 || s == NULL) return -1;
	Band* b = &gBands[slot];
	for (int i = 0; i < b->count; i++) {
		if (!station_same(&b->st[i], s)) continue;
		// already saved: take it out and close the gap, so the others keep their order
		memmove(&b->st[i], &b->st[i + 1], sizeof b->st[0] * (size_t)(b->count - i - 1));
		b->count--;
		updateBandCount();
		gStationsVersion++;
		writeFile();
		return 0;
	}
	if (b->count >= SAVED_MAX) return -1;
	// Copy it first: `s` may point INTO the saved band's own array, and the dial shows the newest save last.
	Station copy = *s;
	b->st[b->count++] = copy;
	updateBandCount();
	gStationsVersion++;
	writeFile();
	return 1;
}
