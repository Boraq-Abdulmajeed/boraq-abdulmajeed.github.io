// Build settings for Crank FM (public source).
//
// This is the "directory" edition: its stations come from Radio Browser (radio-browser.info), a free community directory
// with an open API for apps, sorted into seven genre bands. SomaFM is filtered out of the results (directory.c): its
// terms do not allow third-party apps. (The authors' own copy also has a private edition for their Playdate.)
#ifndef EDITION_H
#define EDITION_H

#define DIRECTORY_EDITION 1
#define BUILTIN_KDOT 0
// 1 = stations on https:// addresses can play too. Off: on the device some https servers failed the certificate check,
// and a stalled https stream could jam the network until the app restarted. Plain http is stable.
#define HTTPS_STREAMS 0
#define APP_AGENT "CrankFM/1.0 (Playdate; +https://boraq-abdulmajeed.github.io)"   // Radio Browser asks apps to name themselves
#define BADGE_CREDIT "via Radio Browser"

#endif
