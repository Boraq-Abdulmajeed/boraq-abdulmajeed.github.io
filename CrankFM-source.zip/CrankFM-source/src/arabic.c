// Arabic text for the Playdate's screen (the user's request, 2026-11-16: Arabic station names and song titles, e.g. Fairuz).
//
// THE PROBLEM
// The Playdate draws text one character at a time, left to right, each character a fixed picture from the font. Arabic needs
// two things that kind of drawing cannot do by itself:
//   1. SHAPING. A letter has up to four shapes (alone, at the start of a word, in the middle, at the end), chosen by its
//      neighbours. A title arrives as plain letters ("logical" code points) with no shape decided yet.
//   2. ORDER. Arabic reads right to left, but the Playdate draws from the left. The characters must be handed over in the
//      order they appear on screen (and numbers or English words inside keep their own left-to-right order).
//
// THE SOLUTION
// arabic_visual() does both: it swaps each letter for the code point of its correct shape (Unicode's "presentation forms",
// table in arabic_table.h, generated from Unicode's own data by tools/make_arabic_table.py) and reorders the string into
// screen order. Crank FM's fonts (Source/fonts, made by tunes/tools/make_arabic_font.py) hold a picture for each of those
// shapes, so the result is drawn like any other text, and long titles scroll as usual.
//
// This is a port of Crank Tunes' server code (tunes/server/arabic_text.py), which did the same on the Mac. Crank FM has no
// computer in between (titles come straight from the radio stations), so the Playdate does it here.
//
// LIMITS
// Vowel marks (harakat) are dropped: a font of fixed pictures cannot place a mark above a letter, and titles rarely have them.
// The ordering is a compact form of the Unicode bidirectional algorithm: right for titles like "فيروز - Live (1990)",
// not for deeply nested mixed text.

#include <string.h>
#include "arabic.h"
#include "arabic_table.h"

#define MAX_CHARS 200   // the longest text handled (titles are at most ~150 bytes); the rest is cut off

/** Finds a letter's row in kArForms (binary search; the table is sorted). NULL if it is not a letter with shapes. */
static const ArForms* formsOf(unsigned int cp)
{
	int lo = 0, hi = (int)(sizeof kArForms / sizeof kArForms[0]) - 1;
	while (lo <= hi) {
		int mid = (lo + hi) / 2;
		if (kArForms[mid].base == cp) return &kArForms[mid];
		if (kArForms[mid].base < cp) lo = mid + 1;
		else hi = mid - 1;
	}
	return NULL;
}

/** Can this letter join the letter AFTER it? (It has a start or middle shape: ب س م yes; ا د ر و no.) */
static int joinsNext(unsigned int cp)
{
	const ArForms* f = formsOf(cp);
	return f != NULL && f->initial != 0;
}

/** Can this letter join the letter BEFORE it? (Every letter that has an end shape.) */
static int joinsPrev(unsigned int cp)
{
	const ArForms* f = formsOf(cp);
	return f != NULL && f->final != 0;
}

/** Vowel marks and other small signs written above or below letters: dropped (see LIMITS above). */
static int isMark(unsigned int cp)
{
	return (cp >= 0x064B && cp <= 0x065F) || cp == 0x0670 || (cp >= 0x06D6 && cp <= 0x06DC) || (cp >= 0x06DF && cp <= 0x06E8)
		|| (cp >= 0x06EA && cp <= 0x06ED);
}

int arabic_drawable(unsigned int cp)
{
	if ((cp >= 0xFB50 && cp <= 0xFDFF) || (cp >= 0xFE70 && cp <= 0xFEFC)) return 1;   // letter shapes (the font has them all)
	if ((cp >= 0x0660 && cp <= 0x066C) || (cp >= 0x06F0 && cp <= 0x06F9)) return 1;   // Arabic and Persian digits, ٪ ٫ ٬
	return cp == 0x060C || cp == 0x061B || cp == 0x061F || cp == 0x0640;               // ، ؛ ؟ and the joining stroke (tatweel)
}

/** Reads one UTF-8 character at s[*i] and moves *i past it. Broken bytes come back as '?'. */
static unsigned int nextChar(const unsigned char* s, int* i)
{
	unsigned int c = s[*i];
	int extra = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : c >= 0xC0 ? 1 : 0;
	if (c >= 0x80 && extra == 0) { (*i)++; return '?'; }   // a stray continuation byte
	unsigned int cp = extra == 0 ? c : extra == 1 ? (c & 0x1F) : extra == 2 ? (c & 0x0F) : (c & 0x07);
	(*i)++;
	for (int k = 0; k < extra; k++) {
		if ((s[*i] & 0xC0) != 0x80) return '?';
		cp = (cp << 6) | (s[*i] & 0x3F);
		(*i)++;
	}
	return cp;
}

int arabic_has(const char* utf8)
{
	const unsigned char* s = (const unsigned char*)utf8;
	int i = 0;
	while (s[i] != '\0') {
		unsigned int cp = nextChar(s, &i);
		if ((cp >= 0x0621 && cp <= 0x06FF) || (cp >= 0x0750 && cp <= 0x077F)) return 1;
	}
	return 0;
}

/**
 * Shaping: replaces each letter in `cps` (reading order, n of them) with the shape it takes in its word, in place.
 * Returns the new count (lam + alef become one character).
 */
static int shape(unsigned int* cps, int n)
{
	int out = 0;
	// The letter before, as it was in the text. It must be kept aside: the shapes are written back into the same array, so
	// cps[i - 1] may already hold the previous letter's SHAPE, which is not in the table (the first version made that
	// mistake and no letter ever joined the one before it).
	unsigned int prev = 0;
	for (int i = 0; i < n; ) {
		unsigned int c = cps[i];
		const ArForms* f = formsOf(c);
		if (f == NULL) { cps[out++] = c; prev = c; i++; continue; }
		// does the letter before reach forward into this one? (both must be able to join)
		int connectPrev = i > 0 && joinsNext(prev) && joinsPrev(c);
		// lam followed by an alef: one joined shape
		if (c == 0x0644 && i + 1 < n) {
			const ArLigature* lig = NULL;
			for (int k = 0; k < (int)(sizeof kArLigatures / sizeof kArLigatures[0]); k++)
				if (kArLigatures[k].alef == cps[i + 1]) lig = &kArLigatures[k];
			if (lig != NULL) {
				cps[out++] = connectPrev && lig->final ? lig->final : lig->isolated;
				prev = cps[i + 1];   // the alef: the letter after the ligature looks at it (an alef never joins forward)
				i += 2;
				continue;
			}
		}
		unsigned int next = i + 1 < n ? cps[i + 1] : 0;
		int connectNext = joinsNext(c) && i + 1 < n && joinsPrev(next);
		unsigned int s = 0;
		if (connectPrev && connectNext) s = f->medial;
		else if (connectPrev) s = f->final;
		else if (connectNext) s = f->initial;
		if (s == 0) s = f->isolated ? f->isolated : (f->final ? f->final : c);
		cps[out++] = s;
		prev = c;
		i++;
	}
	return out;
}

enum { DIR_N, DIR_L, DIR_R };

/** Which way a character reads: right to left (Arabic, Hebrew), left to right (Latin letters, ALL digits), or neutral. */
static int direction(unsigned int cp)
{
	if ((cp >= '0' && cp <= '9') || (cp >= 0x0660 && cp <= 0x0669) || (cp >= 0x06F0 && cp <= 0x06F9)) return DIR_L;
	if ((cp >= 0x0590 && cp <= 0x08FF) || (cp >= 0xFB1D && cp <= 0xFDFF) || (cp >= 0xFE70 && cp <= 0xFEFF)) return DIR_R;
	if ((cp >= 'A' && cp <= 'Z') || (cp >= 'a' && cp <= 'z') || (cp >= 0x00C0 && cp <= 0x024F && cp != 0x00D7 && cp != 0x00F7))
		return DIR_L;
	return DIR_N;   // spaces, punctuation, symbols
}

/** A bracket seen inside right-to-left text is drawn turned around: "(" on screen must close a phrase that reads leftwards. */
static unsigned int mirror(unsigned int cp)
{
	switch (cp) {
	case '(': return ')'; case ')': return '(';
	case '[': return ']'; case ']': return '[';
	case '{': return '}'; case '}': return '{';
	case '<': return '>'; case '>': return '<';
	case 0x00AB: return 0x00BB; case 0x00BB: return 0x00AB;   // « »
	default: return cp;
	}
}

static int isOpen(unsigned int c) { return c == '(' || c == '[' || c == '{' || c == '<' || c == 0x00AB; }
static int isClose(unsigned int c) { return c == ')' || c == ']' || c == '}' || c == '>' || c == 0x00BB; }

/**
 * Ordering: puts `cps` (n characters, reading order) into the order they appear on screen from left to right, in place.
 * A compact form of the Unicode bidirectional algorithm (the same steps as tunes/server/arabic_text.py's reorder()).
 */
static void reorder(unsigned int* cps, int n)
{
	unsigned char kind[MAX_CHARS], level[MAX_CHARS];
	int order[MAX_CHARS];
	int base = DIR_N, hasR = 0;
	for (int i = 0; i < n; i++) {
		kind[i] = (unsigned char)direction(cps[i]);
		if (base == DIR_N && kind[i] != DIR_N) base = kind[i];   // the first strong letter decides the paragraph's direction
		if (kind[i] == DIR_R) hasR = 1;
	}
	if (!hasR) return;   // nothing right to left: already in screen order
	// A bracket pair is decided together, so "(2020)" inside Arabic stays one piece: if the words inside go the paragraph's
	// way, the pair does too; if they go the other way, the pair follows them when the text just before it also did.
	int stack[16], depth = 0;
	for (int i = 0; i < n; i++) {
		if (isOpen(cps[i])) { if (depth < 16) stack[depth++] = i; continue; }
		if (!isClose(cps[i]) || depth == 0) continue;
		int start = stack[--depth], insideL = 0, insideR = 0;
		for (int k = start + 1; k < i; k++) { insideL |= kind[k] == DIR_L; insideR |= kind[k] == DIR_R; }
		if (!insideL && !insideR) continue;
		int before = base;
		for (int k = start - 1; k >= 0; k--) if (kind[k] != DIR_N) { before = kind[k]; break; }
		int other = base == DIR_R ? DIR_L : DIR_R;
		int sameAsBase = base == DIR_R ? insideR : insideL;
		int resolved = sameAsBase ? base : (before == other ? other : base);
		kind[start] = kind[i] = (unsigned char)resolved;
	}
	// Neutrals (spaces, dashes) take the direction of their neighbours when both sides agree, else the paragraph's.
	for (int i = 0; i < n; ) {
		if (kind[i] != DIR_N) { i++; continue; }
		int j = i;
		while (j < n && kind[j] == DIR_N) j++;
		int before = i > 0 ? kind[i - 1] : base, after = j < n ? kind[j] : base;
		int fill = before == after ? before : base;
		for (int k = i; k < j; k++) kind[k] = (unsigned char)fill;
		i = j;
	}
	// Embedding levels: in a right-to-left paragraph R is level 1 and L level 2; in a left-to-right one L is 0 and R is 1.
	int top = 0;
	for (int i = 0; i < n; i++) {
		level[i] = base == DIR_R ? (kind[i] == DIR_R ? 1 : 2) : (kind[i] == DIR_L ? 0 : 1);
		if (level[i] > top) top = level[i];
		order[i] = i;
	}
	// Rule L2: from the highest level down to 1, reverse every stretch at that level or above.
	for (int lv = top; lv >= 1; lv--) {
		for (int i = 0; i < n; ) {
			if (level[order[i]] < lv) { i++; continue; }
			int j = i;
			while (j < n && level[order[j]] >= lv) j++;
			for (int a = i, b = j - 1; a < b; a++, b--) { int t = order[a]; order[a] = order[b]; order[b] = t; }
			i = j;
		}
	}
	unsigned int tmp[MAX_CHARS];
	for (int i = 0; i < n; i++) tmp[i] = level[order[i]] % 2 == 1 ? mirror(cps[order[i]]) : cps[order[i]];
	memcpy(cps, tmp, sizeof(unsigned int) * (size_t)n);
}

/** Writes one code point as UTF-8 into dst at *n (if it fits in cap - 1 bytes). Returns 0 when it did not fit. */
static int putChar(char* dst, int* n, int cap, unsigned int cp)
{
	char b[4];
	int len;
	if (cp < 0x80) { b[0] = (char)cp; len = 1; }
	else if (cp < 0x800) { b[0] = (char)(0xC0 | (cp >> 6)); b[1] = (char)(0x80 | (cp & 0x3F)); len = 2; }
	else if (cp < 0x10000) {
		b[0] = (char)(0xE0 | (cp >> 12)); b[1] = (char)(0x80 | ((cp >> 6) & 0x3F)); b[2] = (char)(0x80 | (cp & 0x3F)); len = 3;
	} else {
		b[0] = (char)(0xF0 | (cp >> 18)); b[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
		b[2] = (char)(0x80 | ((cp >> 6) & 0x3F)); b[3] = (char)(0x80 | (cp & 0x3F)); len = 4;
	}
	if (*n + len > cap - 1) return 0;
	memcpy(dst + *n, b, (size_t)len);
	*n += len;
	return 1;
}

void arabic_visual(const char* src, char* dst, int cap)
{
	if (cap <= 0) return;
	if (!arabic_has(src)) {   // the common case: nothing to do
		int n = (int)strlen(src);
		if (n > cap - 1) n = cap - 1;
		while (n > 0 && ((unsigned char)src[n] & 0xC0) == 0x80) n--;   // never cut a character in half
		memcpy(dst, src, (size_t)n);
		dst[n] = '\0';
		return;
	}
	unsigned int cps[MAX_CHARS];
	int count = 0, i = 0;
	const unsigned char* s = (const unsigned char*)src;
	while (s[i] != '\0' && count < MAX_CHARS) {
		unsigned int cp = nextChar(s, &i);
		if (!isMark(cp)) cps[count++] = cp;
	}
	count = shape(cps, count);
	reorder(cps, count);
	int n = 0;
	for (int k = 0; k < count; k++)
		if (!putChar(dst, &n, cap, cps[k])) break;
	dst[n] = '\0';
}
