// Fills the directory edition's bands from Radio Browser (https://www.radio-browser.info), a free, community-run directory
// of internet radio stations with an open API that apps may use.
//
// How it works:
//  - Each genre band (POP, ROCK, JAZZ, CLASSIC, NEWS, CHILL, RAP) is one or more searches by tag, already filtered by the
//    server to what Crank FM can play: MP3 over plain http, at most 128 kbps, marked working by the directory's own checks, sorted by how
//    often people listen. A band with too few stations from the chosen region is topped up from nearby countries, then from anywhere.
//  - Every result is checked again here (plain http, a name the system font can draw, no duplicates) and SomaFM is dropped:
//    their terms forbid third-party apps, so Crank FM never plays them, even when the directory lists them.
//  - The finished bands are saved to stations.txt, so the next launch starts at once; the directory is asked again only
//    once a week or when the region changes. That keeps our load on a volunteer-run service small.
//  - The seventh band, RAP, starts with one built-in station (K-Dot, see addPinned). Until 2026-11-11 that key held a
//    SAVED band of the player's own stations; the user swapped it for RAP, and its code was removed in the polish pass.
//  - When a station has played for a while we tell the directory once (its "click" count), as its API documentation asks;
//    that is how the directory knows which stations people listen to.
//
// Only one directory request runs at a time, on its own connection, next to the audio stream. Callbacks only set flags and
// the work happens in directory_update(), the same rule as stream.c (closing a connection inside its own callback is unsafe).
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "directory.h"
#include "stream.h"

// New countries are only ever ADDED at the end: the saved settings and the station cache store a region by its position.
// Picked on 2026-11-11 by counting how many stations each country lists that Crank FM can play (plain-http MP3 at 128 kbps
// or less, with a Latin-script name): Italy 415, Poland 204, Spain 194, Mexico 126, Netherlands 103, India 104, UAE 99,
// Brazil 97, Argentina 64, Turkey 62, Japan 19. (Saudi Arabia had 4 and Kuwait 0, too few to fill even one band.)
// A genre a country has fewer than MIN_LOCAL stations in is topped up from its nearby countries (kNearby), then the world.
const char* const kRegionNames[] = { "world", "US", "UK", "CA", "AU", "DE", "FR",
	"IT", "ES", "NL", "PL", "TR", "IN", "JP", "BR", "MX", "AR",
	"Arabic", "Japanese", "Hindi" };
// (UAE was on this list for a day and was removed: its playable stations were mostly English-language Dubai channels,
// which made it confusing next to "Arabic". Nothing was published yet, so the positions could still change.)
// The last three are LANGUAGES, not countries (the user wanted to hear songs in other languages, 2026-11-11). Arabic radio
// is spread over many countries (Tunisia, Egypt, Morocco, Iraq...), so a country filter missed most of it. Playable counts
// that day: Arabic 45, Japanese 20, Hindi 44.
const int kRegionCount = (int)(sizeof kRegionNames / sizeof kRegionNames[0]);


static const char* const kRegionCodes[] = { "", "US", "GB", "CA", "AU", "DE", "FR",
	"IT", "ES", "NL", "PL", "TR", "IN", "JP", "BR", "MX", "AR",   // ISO country codes
	"lang:arabic", "lang:japanese", "lang:hindi" };                      // "lang:" = a language, not a country

// NEARBY COUNTRIES (the user's idea, 2026-11-14: "Japan radio might not have a lot of CHILL, fetch some stations close
// by Japan"). A band that is thin in the chosen country is first topped up from these neighbours, in this order, and only
// then from the whole world. One row per entry of kRegionCodes, in the same order; "" ends a row. Chosen by closeness and
// shared language, at most three each, because every neighbour costs up to three more searches (one per tag) while the
// band is fetched and the music is off. A neighbour is only listed if Radio Browser has at least ~20 stations from it that
// Crank FM can play (plain-http MP3, 128 kbps or less; counted 2026-11-14: DE 1094, US 1234, FR 569, GR 502, CA 209,
// CH 108, NL 101, BR 97, PT 89, BG 73, CZ 69, CO 69, AT 63, BE 50, CL 47, SK 37, NZ 28, IE 22). Countries below that
// (Luxembourg 1, Hong Kong 1, Nepal 6, Guatemala 6, Paraguay 7, Korea 8, China 10, Sri Lanka 13, Pakistan 15, Uruguay 16,
// Cyprus 17) were left out: asking them almost always comes back empty. That leaves JAPAN and INDIA with no neighbours:
// the whole region has hardly any plain-http stations (Taiwan has 30, but none tagged with a music genre), so their thin
// bands go straight to the world as before. World and the languages have no neighbours either.
static const char* const kNearby[][4] = {
	{ "" },                       // world
	{ "CA", "MX", "" },           // US
	{ "IE", "NL", "BE" },         // UK
	{ "US", "" },                 // CA
	{ "NZ", "" },                 // AU
	{ "AT", "CH", "NL" },         // DE
	{ "BE", "CH", "" },           // FR
	{ "CH", "AT", "FR" },         // IT
	{ "PT", "FR", "" },           // ES
	{ "BE", "DE", "" },           // NL
	{ "CZ", "DE", "SK" },         // PL
	{ "GR", "BG", "" },           // TR
	{ "" },                       // IN (see above)
	{ "" },                       // JP (see above)
	{ "AR", "PT", "" },           // BR
	{ "US", "CO", "" },           // MX
	{ "CL", "BR", "" },           // AR
	{ "" }, { "" }, { "" },       // Arabic, Japanese, Hindi (languages never borrow from other languages)
};
_Static_assert(sizeof kNearby / sizeof kNearby[0] == sizeof kRegionCodes / sizeof kRegionCodes[0],
	"kNearby needs one row per region");

/** The k-th neighbour of region r, or NULL when it has no more (see kNearby). */
static const char* nearbyCode(int r, int k)
{
	if (k < 0 || k >= 4 || kNearby[r][k] == NULL || kNearby[r][k][0] == '\0') return NULL;
	return kNearby[r][k];
}

// ONE BIG SEARCH (2026-11-14, to cut the wait). For these regions, Radio Browser has fewer than 100 stations Crank FM can
// play in total (counted 2026-11-14: Japan 18, Turkey 64, Argentina 64, the languages Arabic 45, Japanese 20, Hindi 43), so
// ONE search for the region's 100 most listened stations returns all of them, and each band picks its own from that list by
// tag. That one answer (about 1.1 KB a station) replaces up to 14 searches by genre, most of which came back empty. Bigger
// countries keep the searches by genre: their top 100 leave most bands thin (Germany's top 100 had 2 jazz stations while a
// jazz search finds 20). If a listed region ever has 100 or more, the search by genre runs as well (see nextSearch).
static const unsigned char kSweep[] = {
	0,                                  // world
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,       // US UK CA AU DE FR IT ES NL PL
	1, 0, 1, 0, 0, 1,                   // TR IN JP BR MX AR
	1, 1, 1,                            // Arabic Japanese Hindi
};
_Static_assert(sizeof kSweep == sizeof kRegionCodes / sizeof kRegionCodes[0], "kSweep needs one entry per region");
#define SWEEP_LIMIT 100

/** Is the chosen region a language ("lang:arabic") rather than a country? */
static int regionIsLanguage(int r) { return strncmp(kRegionCodes[r], "lang:", 5) == 0; }

#define CACHE_FILE "stations.txt"
#define CACHE_MAX_AGE (7u * 24u * 3600u)  // ask the directory again after a week
#define FETCH_TIMEOUT_MS 25000            // one search on the slow device Wi-Fi: usually 1-5 s, a big one ~15 s
#define QUICK_RETRY_MS 1500               // first failures: try the other server almost at once...
#define SLOW_RETRY_MS 20000               // ...then back off, so a Playdate with no internet does not hammer anything
#define BUF_CAP (160 * 1024)              // one answer: ~36 KB for 30 stations; a language fill-up (60) is ~70 KB since
                                          // https stations are included (56 KB was too small: Arabic, Japanese and Hindi
                                          // all failed as "answer too long" and showed offline, 2026-11-13)
#if HTTPS_STREAMS
#define HTTPS_FILTER "&"                  // https stations are wanted too
#else
#define HTTPS_FILTER "&is_https=false&" // plain http only
#endif
#define SEARCH_GAP_MS 800                 // pause between two searches (see nextSearch)
#define QUIET_MS 1200                     // the stream must be closed this long before a fetch opens its connection
#define OFFLINE_PAUSE_MS 60000            // after 4 failed tries in a row, wait this long before trying again
#define MIN_LOCAL 4                       // fewer than this from the chosen region: top up (nearby countries first)
#define GENRE_BANDS 7

// Two mirrors of the same directory; if one does not answer we use the other.
// Radio Browser asks apps not to hard-wire one server: "Do a DNS-lookup of 'all.api.radio-browser.info'. This gives you a
// list of all available servers." The Playdate has no DNS call, but asking for all.api.radio-browser.info itself lets the
// network pick one of those servers for us (checked 2026-11-13: it answers plain http). de1 and de2 are only the fallback
// when that fails, so the app keeps working if the shared name is down.
static const char* const kServers[] = { "all.api.radio-browser.info", "de1.api.radio-browser.info", "de2.api.radio-browser.info" };
#define SERVER_COUNT 3

typedef struct {
	const char* name;      // key label
	const char* tags[3];   // directory tags searched, in order (NULL ends the list)
	int limit;             // stations asked for per tag
} BandDef;

static const BandDef kDefs[GENRE_BANDS] = {
	// POP searches "top 40" and "hits" before plain "pop": stations tagged only "pop" were mostly oldies and 80s channels,
	// while "top 40" and "hits" bring current chart stations (.977 Hitz, Radio 105, Hit Radio FFH, Los 40, Kiss FM).
	{ "POP",     { "top 40", "hits", "pop" },           20 },
	{ "ROCK",    { "rock", NULL },                      20 },
	{ "JAZZ",    { "jazz", NULL },                      20 },
	{ "CLASSIC", { "classical", NULL },                 20 },
	{ "NEWS",    { "news", "talk", NULL },              14 },
	{ "CHILL",   { "chillout", "lounge", "ambient" },   12 },
	// RAP replaced the SAVED band on 2026-11-11 (the user's request). Its first station is always the built-in
	// Kendrick Lamar channel below; the other five come from these tags.
	{ "RAP",     { "hip hop", "rap", "hiphop" },        20 },
};
#define RAP_BAND 6

/**
 * The one station Crank FM carries itself rather than finding in the directory: Exclusive Radio's (Dubai) all-Kendrick
 * Lamar channel, 128 kbps MP3. The network's other artist channels are listed in Radio Browser; this one is not, so it is
 * added by hand (found 2026-11-11 by trying the network's address pattern /er/<artist>/icecast.audio). It sits first on
 * the RAP band, labelled with Kendrick's nickname, as the user asked ("I want K-Dot").
 */
static void addPinned(Band* band)
{
	(void)band;   // release build: no built-in station (its address is not even compiled in); RAP is filled from the
	              // directory like every other band
}

static PlaydateAPI* pd;
static const struct playdate_tcp* tcp;
static int region;
// Which bands still need stations for the chosen region. Since 2026-11-13 bands are fetched ONE AT A TIME, when the
// listener first lands on them, instead of all seven at once: on the device a band takes about 5 s over its slow Wi-Fi,
// so fetching all seven kept the music off for 40-60 s after every region change.
static unsigned char bandStale[GENRE_BANDS];
static int focusBand = -1;        // the band on screen (main.c tells us every frame: directory_focus)
static int fetchBand = -1;        // the band being fetched, or waiting to be
static int waitingQuiet;          // a fetch is due and waits for the music's connection to be closed for QUIET_MS
static unsigned int quietSince;   // when the stream last was NOT idle
static unsigned int offlineUntil; // after repeated failures, no new fetch until then
static int refreshing;            // a refresh is under way (between requests too)
static int localFound;            // stations the current refresh found in the chosen country
static int localDone = -1;        // the last finished refresh's count (-1 = none finished since launch)
// The search to run next. Passes run in the order 0, 2, 1:
//   0 = the chosen country (or language), 2 = its nearby countries (jobNear = which one, see kNearby),
//   1 = the whole world (for a language: more stations in that language, any genre).
static int jobBand, jobTag, jobPass, jobNear;
static int jobSweep;              // pass 0 is the one big search (kSweep) instead of one search per tag
static int rawCount;              // how many stations the last answer listed (before our own checks threw any out)
static int failures;
static int server;
static unsigned int retryAt;
static Band staging[GENRE_BANDS]; // new bands are built here and only replace the old ones when all are done
static char clickUuid[40];        // a station waiting to be reported as listened to

// The one directory connection.
enum { PURPOSE_NONE, PURPOSE_SEARCH, PURPOSE_CLICK };
static TCPConnection* conn;
static int purpose;
static unsigned int generation, startedAt;
static int pendingOpen;           // 0 waiting, 1 connected, < 0 the open failed (error code)
static int pendingClosed;         // the server closed the connection
static int requestSent, headerDone;
static int status;                // the answer's HTTP status (0 until the header is read)
static int contentLength;
static unsigned int lastByteAt;
static int chunked;               // the answer comes in chunks ("Transfer-Encoding: chunked": big answers do)   // when bytes last arrived (see the direct read in pump)         // from the header, -1 when the server did not say
static char* buf;
static int bufLen;

static unsigned int nowMs(void) { return pd->system->getCurrentTimeMilliseconds(); }

/** Does `hay` contain `needle`, ignoring case? (newlib on the Playdate has no strcasestr.) */
static int containsNoCase(const char* hay, const char* needle)
{
	size_t n = strlen(needle);
	for (; *hay != '\0'; hay++)
		if (strncasecmp(hay, needle, n) == 0) return 1;
	return 0;
}

// ---- stations.txt: the cache of the last refresh ----

// Everyday names for countries whose official names are too long for the info panel (the user asked for full country
// names, 2026-11-13; before this, long names fell back to the two-letter code, so the UK showed as "GB"). Each row is
// the country code, the directory's official name, and the name we show. Rows match on either the code or the name, so
// it also fixes stations saved in the cache before this table existed (they hold "GB" or "Syrian Arab Republic").
static const char* const kCountryNames[][3] = {
	{ "US", "The United States Of America", "United States" },
	{ "GB", "The United Kingdom Of Great Britain And Northern Ireland", "United Kingdom" },
	{ "NL", "The Netherlands", "Netherlands" },
	{ "RU", "The Russian Federation", "Russia" },
	{ "KR", "The Republic Of Korea", "South Korea" },
	{ "KP", "The Democratic People's Republic Of Korea", "North Korea" },
	{ "IR", "Iran (Islamic Republic Of)", "Iran" },
	{ "SY", "Syrian Arab Republic", "Syria" },
	{ "VE", "Venezuela (Bolivarian Republic Of)", "Venezuela" },
	{ "BO", "Bolivia (Plurinational State Of)", "Bolivia" },
	{ "TZ", "United Republic Of Tanzania", "Tanzania" },
	{ "MD", "The Republic Of Moldova", "Moldova" },
	{ "DO", "The Dominican Republic", "Dominican Rep." },
	{ "PH", "The Philippines", "Philippines" },
	{ "AE", "The United Arab Emirates", "UAE" },          // "United Arab Emirates" is wider than the panel
	{ "VN", "Viet Nam", "Vietnam" },
	{ "TW", "Taiwan, Republic Of China", "Taiwan" },
	{ "CD", "The Democratic Republic Of The Congo", "DR Congo" },
	{ "CG", "The Congo", "Congo" },
	{ "BA", "Bosnia And Herzegovina", "Bosnia" },
	{ "PS", "State Of Palestine", "Palestine" },
	{ "MK", "Republic Of North Macedonia", "North Macedonia" },
	{ "LA", "Lao People's Democratic Republic", "Laos" },
	{ "CZ", "Czechia", "Czechia" },
};

/**
 * Writes the name the info panel shows for a station's country into `out`. `code` is the two-letter country code (may
 * be ""), `name` the directory's name (or what an older cache saved). Known long names come from kCountryNames; any
 * other name loses a leading "The " and anything after " (" or ", " ("Korea, Republic of" style), and a name the
 * system font cannot draw falls back to the code.
 */
static void countryName(const char* code, const char* name, char* out, int cap)
{
	for (int i = 0; i < (int)(sizeof kCountryNames / sizeof kCountryNames[0]); i++)
		if ((code[0] != '\0' && strcasecmp(code, kCountryNames[i][0]) == 0) || strcasecmp(name, kCountryNames[i][1]) == 0
			|| strcmp(name, kCountryNames[i][0]) == 0) {
			snprintf(out, (size_t)cap, "%s", kCountryNames[i][2]);
			return;
		}
	const char* n = name;
	if (strncasecmp(n, "the ", 4) == 0) n += 4;
	char clean[64];
	if (!drawable_text(n, clean, (int)sizeof clean)) { snprintf(out, (size_t)cap, "%s", code); return; }
	char* cut = strstr(clean, " (");
	if (cut != NULL) *cut = '\0';
	cut = strstr(clean, ", ");
	if (cut != NULL) *cut = '\0';
	if ((int)strlen(clean) >= cap && code[0] != '\0') snprintf(out, (size_t)cap, "%s", code);
	else snprintf(out, (size_t)cap, "%.*s", cap - 1, clean);   // (precision: the compiler cannot see the length check)
}

/**
 * The cache is plain text so it can be read by eye when debugging:
 *   crankfm <format> <region> <seconds since 2000 when fetched>
 *   band <NAME>
 *   st <bitrate>\t<uuid>\t<address>\t<title>
 */
static void saveCache(void)
{
	SDFile* f = pd->file->open(CACHE_FILE, kFileWrite);
	if (f == NULL) return;
	char line[400];
	// Format 7 = fetched with https stations allowed, 8 = plain http only, 9 = plain http with nearby-country top-ups
	// (see loadCache: a cache in another format is refetched band by band, its stations playing meanwhile).
	int m = snprintf(line, sizeof line, "crankfm %d %d %u\n", HTTPS_STREAMS ? 7 : 9, region, pd->system->getSecondsSinceEpoch(NULL));
	pd->file->write(f, line, (unsigned int)m);
	for (int b = 0; b < GENRE_BANDS; b++) {
		m = snprintf(line, sizeof line, "band %s %d\n", gBands[b].name, bandStale[b]);   // 1 = still needs fetching
		pd->file->write(f, line, (unsigned int)m);
		for (int i = 0; i < gBands[b].count; i++) {
			const Station* s = &gBands[b].st[i];
			char url[256];
			station_url(s, url, sizeof url);
			m = snprintf(line, sizeof line, "st %d\t%s\t%s\t%s\t%s\t%s\n", s->bitrate, s->uuid, url, s->tags, s->country, s->title);
			pd->file->write(f, line, (unsigned int)m);
		}
		for (int i = 0; i < gBands[b].spares; i++) {   // "sp" lines: the band's backups
			const Station* s = &gBands[b].spare[i];
			char url[256];
			station_url(s, url, sizeof url);
			m = snprintf(line, sizeof line, "sp %d\t%s\t%s\t%s\t%s\t%s\n", s->bitrate, s->uuid, url, s->tags, s->country, s->title);
			pd->file->write(f, line, (unsigned int)m);
		}
	}
	pd->file->close(f);
}

/**
 * Marks every band as needing stations. With `empty`, the bands are also cleared (the stations belong to another region),
 * keeping only the built-in station on RAP; without it they keep playing until each one is fetched again.
 */
static void markAllStale(int empty)
{
	for (int b = 0; b < GENRE_BANDS; b++) {
		bandStale[b] = 1;
		if (!empty) continue;
		gBands[b].count = 0;
		gBands[b].spares = 0;
		if (b == RAP_BAND) addPinned(&gBands[b]);
	}
	if (empty) gStationsVersion++;
}

/**
 * Loads stations.txt into the genre bands. Returns 1 if it was there and usable; marks the bands stale when it was made for
 * another region or is more than a week old (the old stations still show meanwhile, so the radio works offline).
 */
static int loadCache(void)
{
	SDFile* f = pd->file->open(CACHE_FILE, kFileReadData);
	if (f == NULL) return 0;
	int n = pd->file->read(f, buf, BUF_CAP - 1);
	pd->file->close(f);
	if (n <= 0) return 0;
	buf[n] = '\0';
	int cachedRegion = -1, b = -1, cacheFormat = 0;
	unsigned int when = 0;
	for (char* line = strtok(buf, "\n"); line != NULL; line = strtok(NULL, "\n")) {
		if (strncmp(line, "crankfm 5 ", 10) == 0 || strncmp(line, "crankfm 6 ", 10) == 0
			|| strncmp(line, "crankfm 7 ", 10) == 0 || strncmp(line, "crankfm 8 ", 10) == 0
			|| strncmp(line, "crankfm 9 ", 10) == 0) {
			sscanf(line + 10, "%d %u", &cachedRegion, &when);
			cacheFormat = line[8] - '0';
		} else if (strncmp(line, "band ", 5) == 0) {
			b++;
			if (b >= GENRE_BANDS) break;
			gBands[b].count = 0;
			gBands[b].spares = 0;
			const char* flag = strrchr(line, ' ');   // "band POP 1" (format 6); format 5 had no flag: fetched
			bandStale[b] = flag != NULL && flag > line + 5 && flag[1] == '1';
		} else if ((strncmp(line, "st ", 3) == 0 || strncmp(line, "sp ", 3) == 0) && b >= 0) {
			int isSpare = line[1] == 'p';
			if (isSpare ? gBands[b].spares >= SPARES_PER_BAND : gBands[b].count >= MAX_PER_BAND) continue;
			// fields: bitrate, uuid, address, tags, country, title (the title last: it is the only free text)
			char* fields[6];
			char* p = line + 3;
			int k = 0;
			for (; k < 6; k++) {
				fields[k] = p;
				char* tab = k < 5 ? strchr(p, '\t') : NULL;
				if (k < 5 && tab == NULL) break;
				if (tab != NULL) { *tab = '\0'; p = tab + 1; }
			}
			if (k < 6) continue;
			Station* s = isSpare ? &gBands[b].spare[gBands[b].spares] : &gBands[b].st[gBands[b].count];
			memset(s, 0, sizeof *s);
			s->bitrate = atoi(fields[0]);
			snprintf(s->uuid, sizeof s->uuid, "%s", fields[1]);
			snprintf(s->tags, sizeof s->tags, "%s", fields[3]);
			countryName("", fields[4], s->country, (int)sizeof s->country);   // older caches hold "GB" or official names
			if (station_set_url(s, fields[2]) && station_set_title(s, fields[5])) {
				if (isSpare) gBands[b].spares++;
				else gBands[b].count++;
			}
		}
	}
	if (cachedRegion < 0) return 0;
	unsigned int now = pd->system->getSecondsSinceEpoch(NULL);
	if (cachedRegion != region) markAllStale(1);              // another region's stations: clear them
	else if (now < when || now - when > CACHE_MAX_AGE) markAllStale(0);   // a week old: refetch, but keep them meanwhile
	else if (cacheFormat != (HTTPS_STREAMS ? 7 : 9)) markAllStale(0);   // fetched by an older version (other https setting,
	                                                                      // or topped up from the world, not neighbours)
	// (formats 5, 6 and 8 hold plain http stations only; format 7 also https ones, which cannot play with HTTPS_STREAMS 0)
	dlog("directory cache: region %d, %u s old", cachedRegion, now - when);
	return 1;
}

// ---- reading one search answer ----

// The station being read from the JSON right now (only the fields we need).
static struct {
	char name[128];
	char url[300];
	char uuid[40];
	char codec[16];
	char homepage[160];
	char tags[200];
	char country[64];
	char countrycode[8];
	int bitrate;
	int hls;
} cur;
static Band* target;
static int parseError;

static void onJsonError(json_decoder* d, const char* error, int line)
{
	(void)d;
	dlog("directory json error line %d: %s", line, error);
	parseError = 1;
}

static void onWillDecode(json_decoder* d, const char* name, json_value_type type)
{
	(void)d; (void)name;
	if (type == kJSONTable) memset(&cur, 0, sizeof cur);
}

/** Only the keys we use are decoded; the directory sends about 35 per station. */
static int onShouldDecode(json_decoder* d, const char* key)
{
	(void)d;
	return strcmp(key, "name") == 0 || strcmp(key, "url_resolved") == 0 || strcmp(key, "stationuuid") == 0
		|| strcmp(key, "codec") == 0 || strcmp(key, "bitrate") == 0 || strcmp(key, "hls") == 0
		|| strcmp(key, "homepage") == 0 || strcmp(key, "tags") == 0
		|| strcmp(key, "country") == 0 || strcmp(key, "countrycode") == 0;
}

static void copyJsonString(char* dst, size_t cap, json_value v)
{
	const char* s = json_stringValue(v);
	snprintf(dst, cap, "%s", s != NULL ? s : "");
}

static void onTableValue(json_decoder* d, const char* key, json_value v)
{
	(void)d;
	if (strcmp(key, "name") == 0) copyJsonString(cur.name, sizeof cur.name, v);
	else if (strcmp(key, "url_resolved") == 0) copyJsonString(cur.url, sizeof cur.url, v);
	else if (strcmp(key, "stationuuid") == 0) copyJsonString(cur.uuid, sizeof cur.uuid, v);
	else if (strcmp(key, "codec") == 0) copyJsonString(cur.codec, sizeof cur.codec, v);
	else if (strcmp(key, "bitrate") == 0) cur.bitrate = json_intValue(v);
	else if (strcmp(key, "hls") == 0) cur.hls = json_intValue(v);
	else if (strcmp(key, "homepage") == 0) copyJsonString(cur.homepage, sizeof cur.homepage, v);
	else if (strcmp(key, "tags") == 0) copyJsonString(cur.tags, sizeof cur.tags, v);
	else if (strcmp(key, "country") == 0) copyJsonString(cur.country, sizeof cur.country, v);
	else if (strcmp(key, "countrycode") == 0) copyJsonString(cur.countrycode, sizeof cur.countrycode, v);
}

/**
 * Turns the directory's tag list ("hiphop,rap,R&B,usa,128kbps,...") into a short line for the info panel: the first three
 * readable tags, lower case, separated by ", ", without tabs (the cache file uses tabs) or characters the font lacks.
 */
static void tidyTags(char* out, int cap, const char* raw)
{
	int n = 0, kept = 0;
	out[0] = '\0';
	const char* p = raw;
	while (*p != '\0' && kept < 3) {
		const char* end = strchr(p, ',');
		int len = end != NULL ? (int)(end - p) : (int)strlen(p);
		while (len > 0 && *p == ' ') { p++; len--; }
		while (len > 0 && p[len - 1] == ' ') len--;
		char tag[48];
		if (len > 0 && len < (int)sizeof tag) {
			memcpy(tag, p, (size_t)len);
			tag[len] = '\0';
			for (char* c = tag; *c != '\0'; c++) {
				if (*c >= 'A' && *c <= 'Z') *c = (char)(*c - 'A' + 'a');
				if (*c == '\t') *c = ' ';
			}
			char clean[48];
			int sep = kept > 0 ? 2 : 0;
			if (drawable_text(tag, clean, (int)sizeof clean) && n + sep + (int)strlen(clean) < cap) {
				if (sep) { memcpy(out + n, ", ", 2); n += 2; }
				memcpy(out + n, clean, strlen(clean));
				n += (int)strlen(clean);
				out[n] = '\0';
				kept++;
			}
		}
		if (end == NULL) break;
		p = end + 1;
	}
}

/**
 * Is `tag` one of the tags in the directory's comma-separated list ("hiphop, rap,R&B")? Whole tags only, ignoring case and
 * spaces around them, the same as the directory's own "tagExact" search, so the one big search sorts stations into bands
 * exactly as the searches by genre would.
 */
static int hasTag(const char* list, const char* tag)
{
	size_t want = strlen(tag);
	for (const char* p = list; *p != '\0'; ) {
		while (*p == ' ' || *p == ',') p++;
		const char* end = strchr(p, ',');
		size_t len = end != NULL ? (size_t)(end - p) : strlen(p);
		while (len > 0 && p[len - 1] == ' ') len--;
		if (len == want && strncasecmp(p, tag, want) == 0) return 1;
		if (end == NULL) break;
		p = end + 1;
	}
	return 0;
}

/**
 * One station has been read: keep it if Crank FM can really play it. The server already filtered most of this; checking
 * again costs nothing and protects against odd entries (the directory is edited by its community).
 */
static void considerStation(void)
{
	if (target == NULL || (target->count >= MAX_PER_BAND && target->spares >= SPARES_PER_BAND)) return;
	// The one big search lists every genre: this band only takes stations tagged with one of its own tags.
	if (jobPass == 0 && jobSweep) {
		int match = 0;
		for (int t = 0; t < 3 && kDefs[jobBand].tags[t] != NULL && !match; t++) match = hasTag(cur.tags, kDefs[jobBand].tags[t]);
		if (!match) return;
	}
	if (cur.hls || strncasecmp(cur.codec, "MP3", 3) != 0) return;
	if (cur.bitrate <= 0 || cur.bitrate > 128) return;   // more than 16 KB/s would outrun the Playdate's Wi-Fi
	if (containsNoCase(cur.url, "somafm") || containsNoCase(cur.name, "somafm") || containsNoCase(cur.name, "soma fm"))
		return;                                          // SomaFM does not allow third-party apps (see the top of this file)
	// A language's stations include many prayer and sermon stations (common in Arabic radio); keep them out of the music
	// bands (they are common in Arabic radio; the NEWS band, last searched with "talk", may keep them).
	if (regionIsLanguage(region) && jobBand != 4
		&& (containsNoCase(cur.tags, "quran") || containsNoCase(cur.url, "quran") || containsNoCase(cur.tags, "catholic")
			|| containsNoCase(cur.name, "maria") || containsNoCase(cur.tags, "religi") || containsNoCase(cur.tags, "islam")
			|| containsNoCase(cur.tags, "christian") || containsNoCase(cur.tags, "church") || containsNoCase(cur.tags, "bible")
			|| containsNoCase(cur.tags, "gospel") || containsNoCase(cur.name, "quran") || containsNoCase(cur.name, "coran")))
		return;
	Station s;
	memset(&s, 0, sizeof s);
	if (!station_set_url(&s, cur.url)) return;
	// A name in a script the Playdate's font cannot draw (Arabic, Japanese...) falls back to the station's web address,
	// "www.radio9090.com" -> "radio9090.com", so the station is still on the dial with a readable label.
	if (!station_set_title(&s, cur.name)) {
		char site[96];
		const char* h = cur.homepage;
		if (strncasecmp(h, "https://", 8) == 0) h += 8;
		else if (strncasecmp(h, "http://", 7) == 0) h += 7;
		if (strncasecmp(h, "www.", 4) == 0) h += 4;
		int n = 0;
		while (h[n] != '\0' && h[n] != '/' && h[n] != '?' && n < (int)sizeof site - 1) { site[n] = h[n]; n++; }
		site[n] = '\0';
		if (n < 3 || !station_set_title(&s, site)) return;
	}
	// In a language's fill-up pass, every band draws from the same list, so a station already in another band is skipped
	// (otherwise all six bands would show the same few most popular stations).
	if (jobPass == 1 && regionIsLanguage(region)) {
		// (bands are fetched one at a time now: the band being built is in staging, the others already in gBands)
		for (int b = 0; b < GENRE_BANDS; b++) {
			const Band* other = b == jobBand ? &staging[b] : &gBands[b];
			if (b != jobBand && bandStale[b]) continue;
			for (int i = 0; i < other->count; i++)
				if (station_same(&other->st[i], &s)) return;
			for (int i = 0; i < other->spares; i++)
				if (station_same(&other->spare[i], &s)) return;
		}
	}
	// The same stream listed twice (or under two tags) is skipped, and so is a second station on the same server: networks
	// such as 181.FM run dozens of channels from one server, and with six places in a band, one network could fill half of
	// it with near-identical names. One station per server keeps each band varied.
	for (int i = 0; i < target->count; i++)
		if (station_same(&target->st[i], &s) || strcmp(target->st[i].title, s.title) == 0
			|| strcasecmp(target->st[i].host, s.host) == 0) return;
	for (int i = 0; i < target->spares; i++)
		if (station_same(&target->spare[i], &s) || strcmp(target->spare[i].title, s.title) == 0
			|| strcasecmp(target->spare[i].host, s.host) == 0) return;
	snprintf(s.uuid, sizeof s.uuid, "%s", cur.uuid);
	s.bitrate = cur.bitrate;
	tidyTags(s.tags, (int)sizeof s.tags, cur.tags);
	// Country for the info panel, by its everyday full name ("United Kingdom", "Syria"): see countryName.
	countryName(cur.countrycode, cur.country, s.country, (int)sizeof s.country);
	// The first six go on the dial; the next ones are kept as spares (still in popularity order).
	if (target->count < MAX_PER_BAND) target->st[target->count++] = s;
	else target->spare[target->spares++] = s;
	if (kRegionCodes[region][0] != '\0' && (jobPass == 0 || regionIsLanguage(region)))
		localFound++;   // found in the chosen country or language (not a top-up from the world)
}

static void* onDidDecode(json_decoder* d, const char* name, json_value_type type)
{
	(void)d; (void)name;
	if (type == kJSONTable) { rawCount++; considerStation(); }
	return NULL;
}

/** Reads the answer in `buf` into `band`. Returns 0 if it was not a JSON list of stations. */
static int parseStations(Band* band)
{
	json_decoder dec;
	memset(&dec, 0, sizeof dec);
	dec.decodeError = onJsonError;
	dec.willDecodeSublist = onWillDecode;
	dec.shouldDecodeTableValueForKey = onShouldDecode;
	dec.didDecodeTableValue = onTableValue;
	dec.didDecodeSublist = onDidDecode;
	target = band;
	parseError = 0;
	rawCount = 0;
	int before = band->count;
	if (bufLen < 2 || buf[0] != '[') return 0;
	pd->json->decodeString(&dec, buf, NULL);
	target = NULL;
	dlog("directory: %s +%d stations (now %d)", band->name, band->count - before, band->count);
	return !parseError;
}

// ---- the connection ----

// Why raw TCP and not the Playdate's HTTP client (2026-11-13): on the device, an HTTP-client request that hangs (status
// never arrives) blocked EVERY other connection: the directory search got 0 bytes for minutes even with nothing else
// connected, and the station streams were refused ("-2 busy") while it waited. The streams were already on raw TCP
// (stream.c) and switched reliably, so the directory now uses the same: our own "GET ... HTTP/1.0" and our own header
// reading. Radio Browser answers HTTP/1.0 with a Content-Length and no chunking (checked with nc on 2026-11-13).

static int isLive(TCPConnection* c) { return c == conn && tcp->getUserdata(c) == (void*)(uintptr_t)generation; }

/** Open callback: only records the result; pump() acts on it (closing inside a callback is not safe). */
static void onOpen(TCPConnection* c, PDNetErr err, void* ud)
{
	(void)ud;
	if (net_park_opened(c)) return;
	if (isLive(c)) pendingOpen = err == NET_OK ? 1 : (int)err;
}

/** The server closed the connection (normal at the end of an HTTP/1.0 answer). */
static void onClosed(TCPConnection* c, PDNetErr err)
{
	(void)err;
	if (isLive(c)) pendingClosed = 1;
}

static void endRequest(void);   // (defined below; startRequest closes an old connection with it)
static char reqPath[400];   // the path of the request in flight, sent once the connection is open
static int connServer = -1; // which server the open connection goes to
static int connIdle;        // 1 = the connection is open between two requests (kept for the next one)

/**
 * Opens a connection to the current directory server for a GET of `path`. The request itself is written by pump() once
 * the open callback says we are connected. Returns 0 if it could not even start.
 */
static int startRequest(const char* path, int why)
{
	requestSent = headerDone = status = chunked = 0;
	contentLength = -1;
	bufLen = 0;
	snprintf(reqPath, sizeof reqPath, "%s", path);
	// Reuse the connection the last answer came on (HTTP keep-alive): on the device a NEW connection opened soon after
	// two or three others had closed waited about 4.3 s just to connect (device log 2026-11-13), while a request on an
	// open connection is answered in about 0.4 s. One connection now carries a whole band's searches.
	if (conn != NULL && connIdle && connServer == server && pendingOpen == 1 && !pendingClosed) {
		connIdle = 0;
		purpose = why;
		startedAt = lastByteAt = nowMs();
		return 1;
	}
	endRequest();
	generation++;
	pendingOpen = pendingClosed = 0;
	connServer = server;
	conn = tcp->newConnection(kServers[server], 80, false);
	if (conn == NULL) return 0;
	tcp->setUserdata(conn, (void*)(uintptr_t)generation);
	tcp->setConnectTimeout(conn, 8000);
	tcp->setReadTimeout(conn, 50);          // we only read what is already there, so this should never be waited out
	tcp->setReadBufferSize(conn, 32 * 1024);
	tcp->setConnectionClosedCallback(conn, onClosed);
	PDNetErr err = tcp->open(conn, onOpen, NULL);
	if (err != NET_OK) {
		dlog("directory open failed %d", err);
		tcp->setUserdata(conn, NULL);
		tcp->close(conn);
		conn = NULL;
		return 0;
	}
	purpose = why;
	startedAt = lastByteAt = nowMs();
	return 1;
}

/** Closes the connection (close() also frees it: never call release() after it, see stream.c). */
static void endRequest(void)
{
	if (conn == NULL) return;
	if (pendingOpen != 0 || !net_park(conn)) {   // still connecting: park it, never close it (see net_park in stream.c)
		tcp->setUserdata(conn, NULL);
		tcp->close(conn);
	}
	conn = NULL;
	connIdle = 0;
	purpose = PURPOSE_NONE;
}

/** Writes "GET <path> HTTP/1.0" with our name; HTTP/1.0 so the answer is never chunked. Returns 0 on a short write. */
static int sendRequest(void)
{
	char req[600];
	// HTTP/1.1 so the server keeps the connection open for the next request (keep-alive is HTTP/1.1's default).
	// Radio Browser answers with a Content-Length and no chunking (checked with nc, two requests on one connection).
	int n = snprintf(req, sizeof req, "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: " APP_AGENT
		"\r\nAccept: application/json\r\n\r\n", reqPath, kServers[server]);
	if (n <= 0 || n >= (int)sizeof req) return 0;
	return tcp->write(conn, req, (size_t)n) == n;
}

/**
 * Joins a chunked answer back into one piece, in place. On a connection kept open, Radio Browser sends answers over 32 KB
 * as chunks: "<size in hex>\r\n<that many bytes>\r\n" again and again, ending with "0\r\n\r\n" (checked with nc,
 * 2026-11-13; small answers come with a Content-Length instead). Returns 0 if the chunks do not add up.
 */
static int dechunk(void)
{
	int r = 0, w = 0;
	for (;;) {
		char* endp;
		long size = strtol(buf + r, &endp, 16);
		char* crlf = strstr(buf + r, "\r\n");
		if (crlf == NULL || endp == buf + r) return 0;
		r = (int)(crlf - buf) + 2;
		if (size == 0) break;                      // the last chunk
		if (size < 0 || r + size > bufLen) return 0;
		memmove(buf + w, buf + r, (size_t)size);
		w += (int)size;
		r += (int)size + 2;                        // the chunk's data, then its "\r\n"
	}
	bufLen = w;
	buf[bufLen] = '\0';
	return 1;
}

/**
 * Once the whole header block is in buf, reads the status and Content-Length from it and moves the body to the start of
 * buf (so the JSON parser sees only the body). Returns 1 when the header has been handled.
 */
static int takeHeader(void)
{
	buf[bufLen] = '\0';
	char* end = strstr(buf, "\r\n\r\n");
	int sep = 4;
	if (end == NULL) { end = strstr(buf, "\n\n"); sep = 2; }
	if (end == NULL) return 0;
	*end = '\0';
	const char* sp = strchr(buf, ' ');          // "HTTP/1.0 200 OK"
	status = sp != NULL ? atoi(sp + 1) : 0;
	for (char* line = buf; line != NULL && *line != '\0'; ) {
		if (strncasecmp(line, "content-length:", 15) == 0) contentLength = atoi(line + 15);
		if (strncasecmp(line, "transfer-encoding:", 18) == 0 && strstr(line, "chunked") != NULL) chunked = 1;
		char* nl = strchr(line, '\n');
		line = nl != NULL ? nl + 1 : NULL;
	}
	int bodyStart = (int)(end - buf) + sep;
	bufLen -= bodyStart;
	memmove(buf, buf + bodyStart, (size_t)bufLen);
	headerDone = 1;
	return 1;
}

/** Something went wrong with a search: move on to the next server and try the same search again a little later. */
static void searchFailed(const char* why)
{
	failures++;
	server = (server + 1) % SERVER_COUNT;
	if (failures >= 4) {
		// Stop for a minute instead of retrying with the music off: the stations we already have can play meanwhile,
		// and a jammed network (the device refuses everything for about 45 s after a hung connection) gets time to clear.
		endRequest();               // a kept connection must not stay open: the music needs the line
		refreshing = 0;
		waitingQuiet = 0;
		offlineUntil = nowMs() + OFFLINE_PAUSE_MS;
		dlog("directory search failed (%s), giving up for a minute", why);
		return;
	}
	retryAt = nowMs() + (failures < 4 ? QUICK_RETRY_MS : SLOW_RETRY_MS);
	dlog("directory search failed (%s), try %d, next on %s", why, failures, kServers[server]);
}

/** A tag as it goes into the address: spaces become %20 ("top 40" -> "top%2040"). Returns a static buffer. */
static const char* tagForUrl(const char* tag)
{
	static char out[64];
	int n = 0;
	for (const char* c = tag; *c != '\0' && n < (int)sizeof out - 4; c++) {
		if (*c == ' ') { memcpy(out + n, "%20", 3); n += 3; }
		else out[n++] = *c;
	}
	out[n] = '\0';
	return out;
}

/** Writes the address of the search the job counters point at (band jobBand, tag jobTag, pass jobPass) into `path`. */
static void buildPath(char* path, size_t cap)
{
	const BandDef* def = &kDefs[jobBand];
	const char* code = kRegionCodes[region];
	const char* common = "codec=MP3" HTTPS_FILTER "hidebroken=true&bitrateMin=1&bitrateMax=128&order=clickcount&reverse=true";
	int lang = regionIsLanguage(region);
	if ((jobPass == 0 && jobSweep) || (jobPass == 1 && lang)) {
		// The one big search: the region's most listened stations, any genre. A language's fill-up (pass 1) asks the very
		// same thing (more stations in that language, any genre), so it is answered from the store without a second search.
		snprintf(path, cap, "/json/stations/search?%s=%s&%s&limit=%d", lang ? "language" : "countrycode",
			lang ? code + 5 : code, common, SWEEP_LIMIT);
		return;
	}
	int n = snprintf(path, cap, "/json/stations/search?tag=%s&tagExact=true&%s&limit=%d", tagForUrl(def->tags[jobTag]),
		common, def->limit);
	if (jobPass == 0 && lang) snprintf(path + n, cap - (size_t)n, "&language=%s", code + 5);
	else if (jobPass == 0 && code[0] != '\0') snprintf(path + n, cap - (size_t)n, "&countrycode=%s", code);
	else if (jobPass == 2) snprintf(path + n, cap - (size_t)n, "&countrycode=%s", nearbyCode(region, jobNear));
}

// ---- the answer store: every search answer is kept on the Playdate for a week ----
// (2026-11-14, to cut the wait.) The world's top CHILL stations are the same whichever country is chosen, an empty answer
// ("Korea has no jazz") stays empty, and a country visited earlier in the week has the same stations, so asking again
// only kept the music off. Each answer is a file "answers/<hash of the address>.json": a first line "t <seconds since
// 2000 when it was fetched>", then the directory's JSON exactly as it arrived. A band whose every search is in the store
// is filled without the network at all, so the music does not even stop (see directory_update). 100-odd files of up to
// ~115 KB at most; old ones are deleted when they are next looked up.
#define ANSWER_DIR "answers"

/** The store's file name for a search address (FNV-1a hash: short, and the same address always gives the same name). */
static void answerName(const char* path, char* out, size_t cap)
{
	unsigned int h = 2166136261u;
	for (const char* c = path; *c != '\0'; c++) h = (h ^ (unsigned char)*c) * 16777619u;
	snprintf(out, cap, ANSWER_DIR "/%08x.json", h);
}

/** Puts the stored answer for `path` into buf (as if it had just arrived). Returns 0 if there is none less than a week old. */
static int loadAnswer(const char* path)
{
	char name[40];
	answerName(path, name, sizeof name);
	SDFile* f = pd->file->open(name, kFileReadData);
	if (f == NULL) return 0;
	int n = pd->file->read(f, buf, BUF_CAP - 1);
	pd->file->close(f);
	if (n <= 0) return 0;
	buf[n] = '\0';
	unsigned int when = 0;
	char* nl = strchr(buf, '\n');
	unsigned int now = pd->system->getSecondsSinceEpoch(NULL);
	if (nl == NULL || sscanf(buf, "t %u", &when) != 1 || now < when || now - when > CACHE_MAX_AGE) {
		pd->file->unlink(name, 0);   // too old (or damaged): ask the directory again
		return 0;
	}
	bufLen = n - (int)(nl + 1 - buf);
	memmove(buf, nl + 1, (size_t)bufLen + 1);
	return 1;
}

/** Keeps the answer now in buf (a good station list) for `path`. */
static void saveAnswer(const char* path)
{
	char name[40], head[24];
	answerName(path, name, sizeof name);
	pd->file->mkdir(ANSWER_DIR);
	SDFile* f = pd->file->open(name, kFileWrite);
	if (f == NULL) return;
	int m = snprintf(head, sizeof head, "t %u\n", pd->system->getSecondsSinceEpoch(NULL));
	pd->file->write(f, head, (unsigned int)m);
	pd->file->write(f, buf, (unsigned int)bufLen);
	pd->file->close(f);
}

static void nextSearch(void);   // (below)

/**
 * Answers as many of the band's searches as the store holds, one after the other, at once. Stops at the first search the
 * store does not have (the network is needed), or when the band is done (`refreshing` goes back to 0).
 */
static void answerFromStore(void)
{
	char path[300];
	while (refreshing) {
		buildPath(path, sizeof path);
		if (!loadAnswer(path)) return;
		if (!parseStations(&staging[jobBand])) {   // a damaged file: forget it and ask the directory
			char name[40];
			answerName(path, name, sizeof name);
			pd->file->unlink(name, 0);
			return;
		}
		dlog("directory: answered from the store (%d bytes)", bufLen);
		nextSearch();
		retryAt = 0;   // no connection was used, so no pause is needed before the next one
	}
}

/** Starts the search the job counters point at (from the store if it has the answer, otherwise from the directory). */
static void startSearch(void)
{
	answerFromStore();
	if (!refreshing) return;
	char path[300];
	buildPath(path, sizeof path);
	if (!startRequest(path, PURPOSE_SEARCH)) searchFailed("no connection");
}

/** Moves the job counters to the next search, or finishes the refresh after the last band. */
static void nextSearch(void)
{
	const BandDef* def = &kDefs[jobBand];
	jobTag++;
	// A new connection opened right after the last one closed took ~5.5 s on the device (2026-11-13, even for empty
	// answers), while one opened after a quiet moment took 0.2 s. So the next search waits SEARCH_GAP_MS first.
	retryAt = nowMs() + (connIdle ? 0 : SEARCH_GAP_MS);
	// A language's fill-up and the one big search are a single search each, not one per tag.
	int single = (jobPass == 1 && regionIsLanguage(region)) || (jobPass == 0 && jobSweep);
	if (!single && jobTag < 3 && def->tags[jobTag] != NULL && staging[jobBand].count < MAX_PER_BAND) return;
	// The one big search came back full (SWEEP_LIMIT stations), so it may not be the whole region after all: search by
	// genre too, as for a big country (stations already found are not added twice).
	if (jobPass == 0 && jobSweep && rawCount >= SWEEP_LIMIT && staging[jobBand].count < MAX_PER_BAND) {
		jobSweep = 0;
		jobTag = 0;
		return;
	}
	// This pass is done. A thin band from one country gets a second pass with stations from anywhere.
	// For a language, every band that is not full is filled with more stations in that language (any genre), never from
	// the world: the point of choosing a language is to hear it.
	int thin = regionIsLanguage(region) ? staging[jobBand].count < MAX_PER_BAND : staging[jobBand].count < MIN_LOCAL;
	if (jobPass == 0 && kRegionCodes[region][0] != '\0' && thin) {
		jobTag = 0;
		jobNear = 0;
		jobPass = nearbyCode(region, 0) != NULL ? 2 : 1;   // nearby countries first, if this region has any
		return;
	}
	// A neighbour is done: try the next one while the band still has room, then the whole world for what is left.
	// (Neighbours fill the band up to all six, since a station from next door beats one from the other side of the world.)
	if (jobPass == 2 && staging[jobBand].count < MAX_PER_BAND) {
		jobTag = 0;
		if (nearbyCode(region, ++jobNear) == NULL) jobPass = 1;
		return;
	}
	// This band is done: close the line (the music needs it), swap the band in, remember it, and let main.c retune.
	endRequest();
	gBands[jobBand] = staging[jobBand];
	bandStale[jobBand] = 0;
	gStationsVersion++;
	saveCache();
	refreshing = 0;
	fetchBand = -1;
	localDone = localFound;
	dlog("directory: %s done (%d local)", kDefs[jobBand].name, localFound);
}

/** Starts fetching band `b`: an empty staging band (plus the built-in station on RAP), first search next frame. */
static void beginBandFetch(int b)
{
	memset(&staging[b], 0, sizeof staging[b]);
	snprintf(staging[b].name, sizeof staging[b].name, "%s", kDefs[b].name);
	if (b == RAP_BAND) addPinned(&staging[b]);
	jobBand = b;
	jobTag = jobPass = jobNear = 0;
	jobSweep = kSweep[region];
	failures = 0;
	refreshing = 1;
	retryAt = 0;
	localFound = 0;
	dlog("directory: fetching %s for region %s", kDefs[b].name, kRegionNames[region]);
}

/** Sends the request once connected, reads what has arrived, and acts once the answer is complete. */
static void pump(void)
{
	if (pendingOpen < 0) {          // could not connect
		int why = purpose, err = pendingOpen;
		endRequest();
		if (why == PURPOSE_SEARCH) {
			char what[40];
			snprintf(what, sizeof what, "could not connect (%d)", err);
			searchFailed(what);
		}
		return;
	}
	if (pendingOpen == 1 && !requestSent) {
		if (!sendRequest()) {
			int why = purpose;
			endRequest();
			if (why == PURPOSE_SEARCH) searchFailed("could not send the request");
			return;
		}
		requestSent = 1;
		dlog("directory: connected after %u ms", nowMs() - startedAt);
	}
	size_t avail = requestSent ? tcp->getBytesAvailable(conn) : 0;
	while (avail > 0 && bufLen < BUF_CAP - 1) {
		int want = (int)avail;
		if (want > BUF_CAP - 1 - bufLen) want = BUF_CAP - 1 - bufLen;
		int got = tcp->read(conn, buf + bufLen, (size_t)want);
		if (got <= 0) break;
		bufLen += got;
		lastByteAt = nowMs();
		avail = tcp->getBytesAvailable(conn);
	}
	// A server that sends its answer and closes at once can leave "available" at 0 although read() still has bytes
	// (found with stream.c, 2026-11-11): after a close, ask once more.
	if (pendingClosed && avail == 0 && bufLen < BUF_CAP - 1) {
		int got = tcp->read(conn, buf + bufLen, (size_t)(BUF_CAP - 1 - bufLen));
		if (got > 0) bufLen += got;
	}
	// The same quirk on a connection that stays open: the last bytes of a long answer can sit unseen while
	// getBytesAvailable says 0 (big answers never finished on the device, 2026-11-13). So when an answer is short of
	// its Content-Length and nothing has come for a moment, ask read() directly (it waits at most the 50 ms read timeout).
	if (requestSent && avail == 0 && !pendingClosed && nowMs() - lastByteAt > 300 && bufLen < BUF_CAP - 1
		&& (!headerDone || contentLength < 0 || bufLen < contentLength)) {
		int got = tcp->read(conn, buf + bufLen, (size_t)(BUF_CAP - 1 - bufLen));
		if (got > 0) bufLen += got;
		lastByteAt = nowMs();
	}
	if (requestSent && !headerDone) takeHeader();
	// Finished when the server closed, when Content-Length bytes are here, or when a whole JSON list has arrived.
	int end = bufLen;
	while (end > 0 && (buf[end - 1] == ' ' || buf[end - 1] == '\n' || buf[end - 1] == '\r')) end--;
	// A chunked answer is complete when its last, empty chunk has come: then join the pieces into one body.
	int chunksDone = headerDone && chunked && bufLen >= 5 && memcmp(buf + bufLen - 5, "0\r\n\r\n", 5) == 0;
	if (chunksDone) {
		if (!dechunk()) {
			int why = purpose;
			endRequest();
			if (why == PURPOSE_SEARCH) searchFailed("bad chunks");
			return;
		}
		chunked = 0;
		contentLength = bufLen;                   // treat it like an answer that said its length
		end = bufLen;
	}
	int wholeList = headerDone && purpose == PURPOSE_SEARCH && bufLen > 1 && buf[0] == '[' && end > 0 && buf[end - 1] == ']';
	int lengthMet = headerDone && contentLength >= 0 && bufLen >= contentLength;
	int done = headerDone && (lengthMet || wholeList || (pendingClosed && avail == 0));
	int tooBig = bufLen >= BUF_CAP - 1;
	int late = nowMs() - startedAt > FETCH_TIMEOUT_MS;
	if (!done && !tooBig && !late) return;
	buf[bufLen] = '\0';
	int why = purpose;
	// A complete answer (all Content-Length bytes) on a connection the server left open: keep it for the next request.
	if (lengthMet && !pendingClosed && !tooBig && status == 200) {
		connIdle = 1;
		purpose = PURPOSE_NONE;
	} else endRequest();
	if (why == PURPOSE_CLICK) {   // the answer does not matter; keep the line only if a band fetch follows at once
		if (!waitingQuiet) endRequest();
		return;
	}
	if (late && !wholeList) {
		char what[48];
		snprintf(what, sizeof what, "timeout after %d of %d bytes, status %d", bufLen, contentLength, status);
		searchFailed(what);
		return;
	}
	if (tooBig) { searchFailed("answer too long"); return; }
	if (status != 200) {
		char what[24];
		snprintf(what, sizeof what, "status %d", status);
		searchFailed(what);
		return;
	}
	dlog("directory: answer %d bytes after %u ms", bufLen, nowMs() - startedAt);
	if (!parseStations(&staging[jobBand])) { searchFailed("not a station list"); return; }
	saveAnswer(reqPath);   // for the week ahead (see the answer store)
	failures = 0;
	nextSearch();
}

// ---- the interface main.c uses ----

void directory_init(PlaydateAPI* playdate, int startRegion)
{
	pd = playdate;
	tcp = pd->network->tcp;
	region = startRegion >= 0 && startRegion < kRegionCount ? startRegion : 0;
	buf = pd->system->realloc(NULL, BUF_CAP);
	gBandCount = GENRE_BANDS;
	for (int b = 0; b < GENRE_BANDS; b++) {
		gBands[b].count = 0;
		snprintf(gBands[b].name, sizeof gBands[b].name, "%s", kDefs[b].name);
	}
	addPinned(&gBands[RAP_BAND]);   // K-Dot plays even before the first station search finishes
	if (buf == NULL || !loadCache()) markAllStale(0);
	// The cache stores titles only, and a title read back makes its own dial label ("Kendrick Lamar" -> "Kendri"), so
	// give the built-in station its own label again.
	gStationsVersion++;
}

/**
 * Runs the directory's network work, one connection at a time. On the device, two connections at once (a search beside
 * the music, or a play report beside it) hung the network for about 45 s (device logs of 2026-11-13), so a fetch waits
 * until the music's connection has been closed for QUIET_MS; while it waits and runs, directory_busy() is 1 and main.c
 * keeps the music off.
 */
void directory_update(void)
{
	if (buf == NULL) return;
	unsigned int now = nowMs();
	if (stream_state() != STREAM_IDLE) quietSince = now;
	if (conn != NULL && !connIdle) { pump(); return; }
	if (conn != NULL && pendingClosed) endRequest();   // the server closed a kept connection
	if (conn != NULL && !refreshing && !waitingQuiet) endRequest();   // nothing more to ask: free the line for the music
	if (!stream_has_access()) return;   // the player has not allowed the network (yet)
	if (refreshing) {
		if (now >= retryAt) startSearch();
		return;
	}
	int quiet = now - quietSince >= QUIET_MS;
	if (waitingQuiet) {
		if (!quiet) return;
		if (clickUuid[0] != '\0') {        // the line is free: send the waiting play report first (it is tiny)
			char path[80];
			snprintf(path, sizeof path, "/json/url/%s", clickUuid);
			clickUuid[0] = '\0';
			startRequest(path, PURPOSE_CLICK);
			return;
		}
		waitingQuiet = 0;
		refreshing = 1;   // the band was begun (and partly answered from the store) when it was picked below
		retryAt = 0;
		return;
	}
	if (now < offlineUntil) return;
	if (focusBand >= 0 && focusBand < GENRE_BANDS && bandStale[focusBand]) {
		fetchBand = focusBand;
		beginBandFetch(fetchBand);
		answerFromStore();   // everything the store knows, right now, with the music still playing
		if (refreshing) {
			// The directory has to be asked: main.c now stops the music, and the search starts once the line has been
			// quiet for QUIET_MS (two connections at once jam the device's network).
			refreshing = 0;
			waitingQuiet = 1;
		}
		return;
	}
	// A play report on its own, only when the music has been off a while (between stations): it never runs beside it.
	if (clickUuid[0] != '\0' && now - quietSince >= 3 * QUIET_MS) {
		char path[80];
		snprintf(path, sizeof path, "/json/url/%s", clickUuid);
		clickUuid[0] = '\0';
		startRequest(path, PURPOSE_CLICK);
	}
}

/** main.c says which band is on screen; that band is the one fetched next if it needs stations. */
void directory_focus(int b) { focusBand = b; }

/** A new region: every band is cleared and fetched again as the listener visits it, starting with the one on screen. */
void directory_set_region(int r)
{
	if (r < 0 || r >= kRegionCount || r == region) return;
	region = r;
	endRequest();               // stop a fetch for the old region
	refreshing = 0;
	waitingQuiet = 0;
	offlineUntil = 0;
	localDone = -1;             // main.c waits for this region's first count
	markAllStale(1);
	saveCache();
}

int directory_region(void) { return region; }
/** 1 while a fetch waits for the line or runs, or a play report is in flight: main.c keeps the music off meanwhile. */
int directory_busy(void) { return refreshing || waitingQuiet || conn != NULL; }
/** How many stations the last finished band fetch found in the chosen country (-1 if none has finished since launch). */
int directory_local_count(void) { return localDone; }
/** The name of the band being fetched ("POP"), or NULL. */
const char* directory_fetching(void) { return refreshing || waitingQuiet ? kDefs[fetchBand].name : NULL; }
int directory_offline(void) { return nowMs() < offlineUntil; }

void directory_played(const Station* s)
{
	if (s->uuid[0] != '\0') snprintf(clickUuid, sizeof clickUuid, "%s", s->uuid);
}

/**
 * Removes a station that cannot play from the genre bands, and every other station on the same server (they would fail
 * the same way, and each failed attempt can stall the network). Only for this session: the station list on disk is left
 * alone, because a server that does not answer today may answer tomorrow.
 */
int directory_drop(const Station* s)
{
	int inBands = 0;
	for (int b = 0; b < GENRE_BANDS && !inBands; b++)
		for (int i = 0; i < gBands[b].count; i++)
			if (&gBands[b].st[i] == s) inBands = 1;
	if (!inBands) return 0;
	char host[sizeof s->host];
	snprintf(host, sizeof host, "%s", s->host);   // copy first: s points into the bands being changed
	int removed = 0;
	for (int b = 0; b < GENRE_BANDS; b++) {
		Band* band = &gBands[b];
		for (int i = 0; i < band->count; ) {
			if (strcasecmp(band->st[i].host, host) != 0) { i++; continue; }
			dlog("dropping unplayable station %s", band->st[i].title);
			memmove(&band->st[i], &band->st[i + 1], sizeof(Station) * (size_t)(band->count - i - 1));
			band->count--;
			removed++;
		}
		for (int i = 0; i < band->spares; ) {   // spares on the same server would fail too
			if (strcasecmp(band->spare[i].host, host) != 0) { i++; continue; }
			memmove(&band->spare[i], &band->spare[i + 1], sizeof(Station) * (size_t)(band->spares - i - 1));
			band->spares--;
		}
		// Fill the gaps from the spares, best first. A spare goes in at the END of the dial (not into the hole), so the
		// stations that still work keep their order and the player's sense of where things are.
		while (band->count < MAX_PER_BAND && band->spares > 0) {
			dlog("spare %s takes a place in %s", band->spare[0].title, band->name);
			band->st[band->count++] = band->spare[0];
			memmove(&band->spare[0], &band->spare[1], sizeof(Station) * (size_t)(band->spares - 1));
			band->spares--;
		}
	}
	gStationsVersion++;
	return removed > 0;
}

