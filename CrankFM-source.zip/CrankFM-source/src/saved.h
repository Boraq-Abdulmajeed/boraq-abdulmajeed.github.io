// The player's own saved stations ("favourites"), kept as one extra band after the genre bands (2026-11-19).
//
// Ⓐ saves the station under the needle, or removes it if it is already saved. The saved band only exists while it holds at
// least one station: gBandCount counts it then, so Ⓑ reaches it after the last genre band, and the key row draws it as a
// small heart key at the far left. The list is written to saved.txt in the game's data folder at once, so a crash never
// loses it. It does not depend on the region: a saved Italian station stays saved after you switch to Japan.
#ifndef SAVED_H
#define SAVED_H

#include "pd_api.h"
#include "stations.h"

#define SAVED_MAX MAX_PER_BAND   // six, like every band, so the saved dial is as calm as the others

void saved_init(PlaydateAPI* pd);   // call once AFTER the genre bands exist (directory_init / soma_init): loads saved.txt
int saved_band(void);               // the saved band's index in gBands (it may be hidden: see saved_count)
int saved_count(void);              // how many stations are saved (0 = the band is hidden)
int saved_has(const Station* s);    // 1 if this station (same server, port and path) is saved
int saved_toggle(const Station* s); // saves or unsaves it: 1 = saved, 0 = removed, -1 = the list is full

#endif
