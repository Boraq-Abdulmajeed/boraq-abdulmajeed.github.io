// Arabic text for the Playdate's screen: letter shaping and right-to-left ordering, done on the Playdate itself.
// See arabic.c for why this is needed and how it works.
#pragma once

/** 1 if the UTF-8 text has any Arabic letter that still needs shaping (U+0600-U+06FF, U+0750-U+077F). */
int arabic_has(const char* utf8);

/**
 * Writes `src` into `dst` (at most cap - 1 bytes, always terminated) ready to be drawn left to right: every Arabic letter is
 * replaced by its correct shape and the text is put in the order it appears on screen. Text with no Arabic is copied as is.
 */
void arabic_visual(const char* src, char* dst, int cap);

/** 1 if Crank FM's fonts have a picture for this Arabic code point (a letter shape, an Arabic digit or Arabic punctuation). */
int arabic_drawable(unsigned int cp);
