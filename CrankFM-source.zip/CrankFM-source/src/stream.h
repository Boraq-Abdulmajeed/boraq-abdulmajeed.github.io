// HTTP MP3 stream -> decoder -> gAudio.ring. Only one station streams at a time.
#ifndef STREAM_H
#define STREAM_H

#include "pd_api.h"
#include "stations.h"

typedef enum {
	STREAM_NEED_ACCESS,   // waiting for the user to allow network access
	STREAM_DENIED,
	STREAM_IDLE,
	STREAM_CONNECTING,
	STREAM_BUFFERING,
	STREAM_PLAYING,
	STREAM_ERROR,         // retries automatically while still tuned in
} StreamState;

void stream_init(PlaydateAPI* pd);
void stream_tune(const Station* station);   // NULL = none. No-op if already on it.
void stream_update(void);        // call every frame: pulls bytes, decodes, manages state
StreamState stream_state(void);
int stream_has_access(void);
const Station* stream_take_dead(void);   // a station found to be unplayable since the last call (then NULL), or NULL   // 1 once the player has allowed network access
float stream_buffered_seconds(void);
int stream_rebuffering(void);   // 1 while refilling after the audio ran dry
int stream_bitrate(void);
const char* stream_title(void);
const char* stream_previous_title(void);
void dlog(const char* fmt, ...);
int net_park(TCPConnection* c);          // park a still-connecting connection instead of closing it (stream.c)
int net_park_opened(TCPConnection* c);   // open callbacks call this first: 1 = it was parked, do nothing else
void dlog_init(PlaydateAPI* pd);  // open the log (call first thing at init)   // console + radio.log in the data folder  // current song ("Artist - Title"), "" if unknown

#endif
