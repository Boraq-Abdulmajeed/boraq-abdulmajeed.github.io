// The directory edition's station source: Radio Browser (radio-browser.info) genre bands.
// Everything here compiles to empty stubs in the personal (SomaFM) edition.
#ifndef DIRECTORY_H
#define DIRECTORY_H

#include "pd_api.h"
#include "stations.h"

extern const char* const kRegionNames[];   // shown in the system menu ("world", "US", ...)
extern const int kRegionCount;

void directory_init(PlaydateAPI* pd, int region);   // fills the bands from the cache; refreshes if needed
void directory_update(void);                        // call every frame: runs the background fetches
void directory_set_region(int region);              // a new region fetches fresh bands
int directory_region(void);
int directory_busy(void);                           // 1 while the bands are being fetched
void directory_focus(int band);                    // which band is on screen (fetched next if it needs stations)
const char* directory_fetching(void);              // name of the band being fetched ("POP"), NULL when none
int directory_local_count(void);                    // stations found in the chosen country by the last refresh (-1 = none yet)
int directory_offline(void);                        // 1 when the directory could not be reached for a while
void directory_played(const Station* s);            // tell Radio Browser a station was listened to (its "click" count)
int directory_drop(const Station* s);               // remove an unplayable station from its genre band (1 = removed)

#endif
