// Helpers shared by both editions: where stations sit on the dial, and turning a stream address or a station name from the
// internet into something safe to connect to and to draw.
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include "stations.h"
#include "arabic.h"

Band gBands[MAX_BANDS];
int gBandCount;
int gStationsVersion;

/**
 * Where station `index` of `count` sits on the dial, in "MHz".
 *
 * Stations are spread evenly between 89.5 and 106.7 (a little in from both ends, so the needle can rest past the first and
 * last one) and rounded to 0.1 so the plate shows a tidy number. A band of six keeps the exact positions the first Crank FM
 * used, so the personal edition's saved dial position still lands on its station.
 */
float station_freq(int index, int count)
{
	static const float six[6] = { 89.5f, 92.7f, 96.1f, 99.9f, 103.3f, 106.7f };
	if (count <= 1) return 98.0f;
	if (count == 6) return six[index];
	float f = 89.5f + (106.7f - 89.5f) * (float)index / (float)(count - 1);
	return roundf(f * 10.0f) / 10.0f;
}

/**
 * Reads a stream address such as "http://ice.example.org:8000/live.mp3" into the station's host, port and path.
 * Returns 0 (and leaves the station unusable) for anything Crank FM cannot open: not plain http (the Playdate's Wi-Fi is too
 * slow to spare encryption on audio), parts too long for our fields, or spaces and control characters in the address.
 */
int station_set_url(Station* s, const char* url)
{
	int secure = 0;
	int ok = url_split(url, s->host, (int)sizeof s->host, &s->port, s->path, (int)sizeof s->path, &secure);
	s->secure = (char)secure;
	return ok;
}

/**
 * Splits "http://host[:port]/path" into its parts (the work behind station_set_url; stream.c also uses it with a bigger
 * path buffer to follow redirects, whose addresses can carry long tokens). Returns 0 for anything but plain http.
 */
int url_split(const char* url, char* host, int hostCap, int* portOut, char* pathOut, int pathCap, int* secureOut)
{
	const char* p;
	int secure = 0;
	if (strncasecmp(url, "http://", 7) == 0) p = url + 7;
#if HTTPS_STREAMS
	else if (strncasecmp(url, "https://", 8) == 0) { p = url + 8; secure = 1; }
#endif
	else return 0;
	const char* hostEnd = p;
	while (*hostEnd != '\0' && *hostEnd != ':' && *hostEnd != '/' && *hostEnd != '?') hostEnd++;
	int hostLen = (int)(hostEnd - p);
	if (hostLen <= 0 || hostLen >= hostCap) return 0;
	int port = secure ? 443 : 80;
	const char* q = hostEnd;
	if (*q == ':') {
		port = 0;
		for (q++; *q >= '0' && *q <= '9'; q++) port = port * 10 + (*q - '0');
		if (port <= 0 || port > 65535) return 0;
	}
	const char* path = *q == '\0' ? "/" : q;
	if (*path == '?') return 0;   // "host?x" without a path is too odd to bother with
	if ((int)strlen(path) >= pathCap) return 0;
	for (const char* c = path; *c != '\0'; c++)
		if ((unsigned char)*c <= ' ') return 0;   // the request line cannot carry spaces or control characters
	memcpy(host, p, (size_t)hostLen);
	host[hostLen] = '\0';
	*portOut = port;
	if (secureOut != NULL) *secureOut = secure;
	snprintf(pathOut, (size_t)pathCap, "%s", path);
	return 1;
}

/** Writes the station's address back out as "http://host[:port]/path" (the form saved.txt uses). */
void station_url(const Station* s, char* out, int cap)
{
	const char* scheme = s->secure ? "https" : "http";
	if (s->port == (s->secure ? 443 : 80)) snprintf(out, (size_t)cap, "%s://%s%s", scheme, s->host, s->path);
	else snprintf(out, (size_t)cap, "%s://%s:%d%s", scheme, s->host, s->port, s->path);
}

// Plain-letter forms of U+00A0..U+017F (Latin-1 Supplement + Latin Extended-A), made with Python's unicodedata
// (accents removed) plus a few by hand (ß->ss, ø->o, ł->l, ı->i...). "" = drop the character (e.g. the degree sign).
static const char* const kFold[0x180 - 0xA0] = {
	" ", "!", "", "", "", "", "", "", " ", "", "a", "\"", "", "", "", " ",
	"", "", "2", "3", " ", "", "", "-", " ", "1", "o", "\"", "14", "12", "34", "?",
	"A", "A", "A", "A", "A", "A", "AE", "C", "E", "E", "E", "E", "I", "I", "I", "I",
	"", "N", "O", "O", "O", "O", "O", "x", "O", "U", "U", "U", "U", "Y", "Th", "ss",
	"a", "a", "a", "a", "a", "a", "ae", "c", "e", "e", "e", "e", "i", "i", "i", "i",
	"d", "n", "o", "o", "o", "o", "o", "/", "o", "u", "u", "u", "u", "y", "th", "y",
	"A", "a", "A", "a", "A", "a", "C", "c", "C", "c", "C", "c", "C", "c", "D", "d",
	"D", "d", "E", "e", "E", "e", "E", "e", "E", "e", "E", "e", "G", "g", "G", "g",
	"G", "g", "G", "g", "H", "h", "H", "h", "I", "i", "I", "i", "I", "i", "I", "i",
	"I", "i", "IJ", "ij", "J", "j", "K", "k", "k", "L", "l", "L", "l", "L", "l", "L",
	"l", "L", "l", "N", "n", "N", "n", "N", "n", "n", "N", "n", "O", "o", "O", "o",
	"O", "o", "OE", "oe", "R", "r", "R", "r", "R", "r", "S", "s", "S", "s", "S", "s",
	"S", "s", "T", "t", "T", "t", "T", "t", "U", "u", "U", "u", "U", "u", "U", "u",
	"U", "u", "U", "u", "W", "w", "Y", "y", "Y", "Z", "z", "Z", "z", "Z", "z", "s",
};

/**
 * Turns the UTF-8 character at `u` into plain ASCII the Playdate's fonts can draw, written to `out` (at most 4 bytes,
 * not terminated). Returns how many bytes it wrote (0 = the character is simply dropped) or -1 if it comes from a script
 * we cannot show at all (Cyrillic, Greek, Arabic, Chinese...). *used gets the number of input bytes it took.
 *
 * Why: the big system font (Asheville Sans 14 Bold, used for the dial names, the station name and the song on the plate)
 * has NO accented letters at all, not even "é", nor curly quotes or dashes (checked in its .fnt file, 2026-11-13); on the
 * device "Şarkı" or "İstanbul" came out as empty boxes. So accents are taken off: ş -> s, İ -> I, é -> e, ß -> ss.
 */
static int foldChar(const unsigned char* u, char* out, int* used)
{
	if (u[0] < 0x80) { *used = 1; out[0] = (char)u[0]; return 1; }
	if (u[0] >= 0xC2 && u[0] <= 0xC5 && (u[1] & 0xC0) == 0x80) {   // U+0080..U+017F
		*used = 2;
		int cp = ((u[0] & 0x1F) << 6) | (u[1] & 0x3F);
		if (cp < 0xA0) return 0;                                      // control characters: drop
		const char* f = kFold[cp - 0xA0];
		int n = (int)strlen(f);
		memcpy(out, f, (size_t)n);
		return n;
	}
	if (u[0] == 0xE2 && u[1] == 0x80 && (u[2] & 0xC0) == 0x80) {      // U+2000..U+203F: general punctuation
		*used = 3;
		int cp = 0x2000 | (u[2] & 0x3F);
		if (cp >= 0x2010 && cp <= 0x2015) { out[0] = '-'; return 1; }                 // dashes
		if (cp >= 0x2018 && cp <= 0x201B) { out[0] = '\''; return 1; }                // single quotes
		if (cp >= 0x201C && cp <= 0x201F) { out[0] = '"'; return 1; }                 // double quotes
		if (cp == 0x2022) { out[0] = '-'; return 1; }                                  // bullet
		if (cp == 0x2026) { memcpy(out, "...", 3); return 3; }                         // ellipsis
		if (cp == 0x2032) { out[0] = '\''; return 1; }                                 // prime
		return 0;                                                                      // other spaces/marks: drop
	}
	// Arabic letter shapes, Arabic digits and Arabic punctuation (2026-11-16): Crank FM's fonts have a picture for each, so
	// they are copied as they are. The text has already been through arabic_visual() (see drawable_text and
	// station_set_title), which turned the plain letters into these shapes and put them in screen order.
	if ((u[0] >= 0xD8 && u[0] <= 0xDB && (u[1] & 0xC0) == 0x80)
		|| (u[0] == 0xEF && u[1] >= 0xAD && u[1] <= 0xBB && (u[1] & 0xC0) == 0x80 && (u[2] & 0xC0) == 0x80)) {
		int len = u[0] == 0xEF ? 3 : 2;
		unsigned int cp = len == 2 ? (unsigned int)(((u[0] & 0x1F) << 6) | (u[1] & 0x3F))
			: (unsigned int)(((u[0] & 0x0F) << 12) | ((u[1] & 0x3F) << 6) | (u[2] & 0x3F));
		*used = len;
		if (!arabic_drawable(cp)) return -1;
		memcpy(out, u, (size_t)len);
		return len;
	}
	// Any other character: skip all its bytes and report it as unshowable.
	int n = 1;
	while ((u[n] & 0xC0) == 0x80) n++;
	*used = n;
	return -1;
}

/** Could every character of this text be shown (after foldChar)? Names in other scripts are skipped, not shown broken. */
static int drawable(const char* s)
{
	const unsigned char* u = (const unsigned char*)s;
	char tmp[4];
	int used;
	while (*u != '\0') {
		if (foldChar(u, tmp, &used) < 0) return 0;
		u += used;
	}
	return 1;
}

/** Copies `src` into `dst` as plain ASCII (foldChar); characters from other scripts must already be ruled out. */
static void foldText(const char* src, char* dst, int cap)
{
	const unsigned char* u = (const unsigned char*)src;
	int n = 0, used;
	char tmp[4];
	while (*u != '\0') {
		int k = foldChar(u, tmp, &used);
		u += used;
		if (k <= 0) continue;
		if (n + k >= cap) break;
		memcpy(dst + n, tmp, (size_t)k);
		n += k;
	}
	dst[n] = '\0';
}

/**
 * Copies the parts of `src` the fonts can draw into `dst`, as plain ASCII (accents taken off by foldChar), dropping every
 * character from another script (Arabic, Japanese...) and the separators left dangling around them. Returns 1 if anything
 * readable (a letter or digit) is left, else 0.
 */
int drawable_text(const char* src, char* dst, int cap)
{
	// Arabic is shaped and put in screen order first (arabic.c), so what follows only sees letters the fonts can draw.
	char visual[320];
	arabic_visual(src, visual, (int)sizeof visual);
	const unsigned char* u = (const unsigned char*)visual;
	int n = 0, letters = 0, used;
	char tmp[4];
	while (*u != '\0' && n < cap - 4) {
		int k = foldChar(u, tmp, &used);
		u += used;
		for (int i = 0; i < k && n < cap - 1; i++) {
			char c = tmp[i];
			if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')
				|| (i == 0 && (unsigned char)c >= 0x80)) letters++;   // an Arabic shape counts as readable too
			if (c == ' ' && (n == 0 || dst[n - 1] == ' ')) continue;   // no double or leading spaces
			dst[n++] = c;
		}
	}
	// trim trailing spaces and separators such as " - " left behind by a removed half
	while (n > 0 && (dst[n - 1] == ' ' || dst[n - 1] == '-' || dst[n - 1] == '|' || dst[n - 1] == ':' || dst[n - 1] == '/')) n--;
	dst[n] = '\0';
	int lead = 0;
	while (dst[lead] == ' ' || dst[lead] == '-' || dst[lead] == '|' || dst[lead] == ':' || dst[lead] == '/') lead++;
	if (lead > 0) memmove(dst, dst + lead, strlen(dst + lead) + 1);
	return letters > 0 && dst[0] != '\0';
}

/** Copies at most `cap - 1` bytes of `src` into `dst` without cutting a UTF-8 character in half. */
static void copyUtf8(char* dst, const char* src, int cap)
{
	int n = 0;
	while (src[n] != '\0' && n < cap - 1) n++;
	while (n > 0 && ((unsigned char)src[n] & 0xC0) == 0x80 && src[n] != '\0') n--;   // back off to a character start
	memcpy(dst, src, (size_t)n);
	dst[n] = '\0';
}

/**
 * Tidies a station name from the directory and stores it as the title and the dial label. Names arrive with stray tabs,
 * newlines, runs of spaces and leading symbols ("\tHard Rock Radio", "*** RADIO X ***"); those are dropped. Returns 0 when
 * nothing drawable is left, so the caller skips the station.
 */
int station_set_title(Station* s, const char* title)
{
	char clean[96];
	int n = 0, space = 1;   // space = 1 also drops leading blanks
	for (const char* c = title; *c != '\0' && n < (int)sizeof clean - 1; c++) {
		unsigned char ch = (unsigned char)*c;
		if (ch < 0x20 || ch == ' ' || ch == '|') {   // '|' is our field separator in saved.txt
			if (!space) { clean[n++] = ' '; space = 1; }
			continue;
		}
		clean[n++] = (char)ch;
		space = 0;
	}
	// ...and trailing decoration the same way as leading ("*** RADIO X ***" -> "RADIO X"): any run of symbols at the end,
	// except a closing bracket, quote or "!" that belongs to the name.
	while (n > 0 && (clean[n - 1] == ' ' || clean[n - 1] == '*' || clean[n - 1] == '-' || clean[n - 1] == '='
		|| clean[n - 1] == '~' || clean[n - 1] == '#' || clean[n - 1] == '_' || clean[n - 1] == '+')) n--;
	clean[n] = '\0';
	const char* start = clean;   // skip leading decoration such as "*** " or "- "
	while (*start != '\0' && !((*start >= 'A' && *start <= 'Z') || (*start >= 'a' && *start <= 'z')
		|| (*start >= '0' && *start <= '9') || (unsigned char)*start >= 0x80)) start++;
	if (*start == '\0') return 0;
	// The full title: Arabic shaped and in screen order (arabic.c), then accents taken off ("Gri - Sevdiğin Şarkı" ->
	// "Gri - Sevdigin Sarki", see foldChar). Names in a script the fonts cannot draw at all (Japanese...) are refused.
	char shaped[200], plain[200];
	arabic_visual(start, shaped, (int)sizeof shaped);
	if (!drawable(shaped)) return 0;
	foldText(shaped, plain, (int)sizeof plain);
	// The title field holds 48 bytes, only about 16 shaped Arabic letters (3 bytes each). Cutting the screen-order text would
	// drop the START of an Arabic name (it is on the right), so an Arabic title that is too long loses whole words from its
	// END in reading order, and is shaped again.
	if ((int)strlen(plain) >= (int)sizeof s->title && arabic_has(start)) {
		char logical[200];
		snprintf(logical, sizeof logical, "%s", start);
		for (;;) {
			char* lastSpace = strrchr(logical, ' ');
			if (lastSpace == NULL || lastSpace - logical < 3) break;
			*lastSpace = '\0';
			int k = (int)strlen(logical);
			while (k > 0 && (logical[k - 1] == ' ' || logical[k - 1] == '-' || logical[k - 1] == '|')) logical[--k] = '\0';
			arabic_visual(logical, shaped, (int)sizeof shaped);
			foldText(shaped, plain, (int)sizeof plain);
			if ((int)strlen(plain) < (int)sizeof s->title) break;
		}
	}
	copyUtf8(s->title, plain, (int)sizeof s->title);
	// The dial label is short, so it keeps only the station's own name: many names start with "Radio " ("Radio Kiss Kiss",
	// "Radio Kiss Kiss Italia"...) and many end with a description after a dash, a bracket or a comma ("Big R Radio - 80s and
	// 90s Pop Mix", "HardRadio [MP3]", "KEXP 90.3 FM Seattle, WA"). The plate under the dial still shows the full title.
	const char* label = start;
	// "Radio Aswat" -> "Aswat", but only if a real name is left: "RADIO X" keeps its "RADIO".
	if (strncasecmp(label, "radio ", 6) == 0 && strlen(label + 6) >= 4) label += 6;
	// Dubai's "Exclusively ..." network names each channel after one artist ("Exclusively George Harrison"): the artist
	// is the part that tells them apart on the dial.
	if (strncasecmp(label, "exclusively ", 12) == 0 && label[12] != '\0') label += 12;
	// "The Jazz Groove" would be cut down to "The" on a crowded dial: the article goes, the name stays.
	if (strncasecmp(label, "the ", 4) == 0 && strlen(label) > 7) label += 4;
	char shortName[96];
	snprintf(shortName, sizeof shortName, "%s", label);
	static const char* const cuts[] = { " - ", " | ", " (", " [", ", ", " :: " };
	for (int i = 0; i < (int)(sizeof cuts / sizeof cuts[0]); i++) {
		char* at = strstr(shortName, cuts[i]);
		if (at != NULL && at - shortName >= 3) *at = '\0';   // keep the cut only if a real name (3+ characters) is left
	}
	// The label is cut above in READING order (so "فيروز - طرب" keeps "فيروز", the first words, not the last), and only then
	// shaped and put in screen order. A shaped Arabic letter takes 3 bytes, so a long Arabic name is shortened by whole
	// words, again in reading order, until it fits the label field.
	char labelOut[200];
	for (;;) {
		char v[200];
		arabic_visual(shortName, v, (int)sizeof v);
		foldText(v, labelOut, (int)sizeof labelOut);
		char* lastSpace = strrchr(shortName, ' ');
		if ((int)strlen(labelOut) < (int)sizeof s->name || lastSpace == NULL || lastSpace - shortName < 3) break;
		*lastSpace = '\0';
	}
	copyUtf8(s->name, labelOut, (int)sizeof s->name);
	// If the field cut the name in the middle of a word ("Venice Classi"), go back to the end of the last whole word.
	if (strlen(s->name) < strlen(labelOut) && labelOut[strlen(s->name)] != ' ') {
		char* sp = strrchr(s->name, ' ');
		if (sp != NULL && sp - s->name >= 3) *sp = '\0';
	}
	int ln = (int)strlen(s->name);   // cutting at the label's length can leave a space at the end ("KEXP 90.3 FM ")
	while (ln > 0 && s->name[ln - 1] == ' ') s->name[--ln] = '\0';
	return 1;
}

/** Two stations are the same if they point at the same stream (the name does not matter). */
int station_same(const Station* a, const Station* b)
{
	return a->port == b->port && strcasecmp(a->host, b->host) == 0 && strcmp(a->path, b->path) == 0;
}
