# Crank FM: source code

Internet radio for the [Playdate](https://play.date), tuned with the crank like an old tabletop radio: static between
stations, and a station that breaks through muffled and wavering as you come close, then settles in clear. Written in C.

## Where the stations come from

Crank FM finds its stations in [Radio Browser](https://www.radio-browser.info), a free, community-run directory of
internet radio with an open API. It asks for stations the Playdate can play (MP3 over plain http, 128 kbps or less),
sorts them into seven bands (POP, ROCK, JAZZ, CLASSIC, NEWS, CHILL, RAP) and keeps the list for a week, so the directory
is asked again only now and then. The system menu's **region** picks a country or a language (Arabic, Japanese, Hindi).

Crank FM does not host any audio. Every stream belongs to its station, and each station's own terms apply. SomaFM is left
out on purpose: its terms do not allow third-party apps.

## Controls

* **Crank:** turn the dial (it goes all the way round; a fast spin keeps it turning, and it settles onto a station near the needle). **Left / Right:** jump to the next station. **A:** save the station you are on (a heart key appears at the left of the band keys; press A again to remove it).
* **B:** next band. **Up / Down:** volume.
* System menu: **help** (credits and controls), **dark** (dark mode), **region**.

## Build

You need the [Playdate SDK](https://play.date/dev/) (3.x) and `make`.

```sh
make                 # builds CrankFM.pdx for the Simulator and the device
sh build.sh          # builds and opens it in the Playdate Simulator (macOS)
```

## What is where

* `src/main.c`: the app: the dial and its labels, the tuning (how close the needle is to a station sets the static, the
  muffle and the warble), the radio face, the station info panel, settings, dark mode.
* `src/directory.c`: the Radio Browser searches, the bands, the region and language choice, the weekly cache, and the
  backup stations that take over when a station turns out to be dead.
* `src/stations.c`: where stations sit on the dial, and tidying names from the directory for a small screen.
* `src/stream.c`: the station connection, written on the Playdate's raw TCP API (its own http requests, redirects, and
  header reading), with a buffer that grows by itself when the Wi-Fi is weak.
* `src/icy.c`: strips the song titles out of the stream (ICY metadata) and reads them.
* `src/decoder.c`: MP3 decoding with [minimp3](https://github.com/lieff/minimp3) (public domain, `src/minimp3.h`).
* `src/audio.c`: the sound: resampling, the static, the muffle, stereo for headphones, a mono mix for the speaker, and a
  limiter.
* `tools/make_launcher.py`: the launcher pictures. `tools/host_decode_test.c`: a test of the decoder on a Mac.

## Licence

MIT (see `LICENSE`). minimp3 is public domain (CC0). The Beaumont Tower photo in `assets/` is Boraq's own.

Made by Boraq Abdulmajeed and Nityaansh Parekh, with Claude Code. Playdate is a trademark of Panic Inc.
