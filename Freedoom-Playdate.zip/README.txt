FREEDOOM FOR PLAYDATE  (version 1.0)
====================================

The classic Doom engine running on the Playdate, with Freedoom's free levels, monsters and art, and the crank to aim.

INSTALL
  Sign in at play.date/account/sideload and upload Freedoom-Playdate.zip. Or reboot the Playdate to Data Disk
  (Settings, System, Reboot to Data Disk), copy Freedoom.pdx into the Games folder, and eject.
  The first start takes several seconds ("loading..."): the game data is 28 MB.

CONTROLS
  Crank        turn (like a mouse)
  A            fire
  B            a quick tap uses (doors, switches); HOLD B to walk forward
  D-pad        walk and strafe (optional)
  A + B        a quick tap shows the map; hold for the game's own menu (new game, save, load, options)
  Menu button  "weapon" (next weapon), "controls" (solo or classic), "turn" (crank sensitivity 1-5; 3 = normal)
  The default controls ("solo") are made for holding A/B with one thumb and the crank with the other hand.

HOW IT RUNS
  The Playdate is a small computer: expect about 13 to 25 frames a second depending on the scene.
  There is no music in this version, only sound effects.

YOUR OWN DOOM DATA
  If you own Doom, you can play its data instead of Freedoom's: in Data Disk mode, copy your own doom.wad into
  Data/com.braq.freedoom/ (open Freedoom once first, so the folder exists). Doom's data is not included and may not be shared.

LICENCES
  The engine is doomgeneric, based on Doom's source code released by id Software, under the GNU General Public
  Licence version 2 (LICENSE-GPL.txt inside Freedoom.pdx). The full source code of this game, including the
  Playdate parts, is in Freedoom-Playdate-source.zip, from the same place you got this.
  Freedoom's game data is free under a BSD-style licence (FREEDOOM-LICENSE.txt, credits in FREEDOOM-CREDITS.txt).
  Doom is a trademark of id Software. This project is not made or endorsed by id Software, Bethesda or Panic.
  Playdate is a trademark of Panic Inc.

Made by Boraq Abdulmajeed.
